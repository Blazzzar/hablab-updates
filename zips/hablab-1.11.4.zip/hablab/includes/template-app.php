<?php
/**
 * Full-page shell for /hablab.html (live) and /hablab-demo.html.
 * Keep the markup in sync with app/index.html (the local-dev copy).
 */
defined( 'ABSPATH' ) || exit;

$hablab_mode = ( 'demo' === get_query_var( 'hablab' ) ) ? 'demo' : 'live';
$hablab_app  = HABLAB_URL . 'app/';
$hablab_v    = HABLAB_VERSION;

header( 'Content-Type: text/html; charset=utf-8' );
?><!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<title>HAB•LAB<?php echo 'demo' === $hablab_mode ? ' — Demo' : ''; ?></title>

<link rel="manifest" href="<?php echo esc_url( home_url( '/hablab.webmanifest' ) ); ?>">
<meta name="theme-color" content="#6CC7E6">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-status-bar-style" content="default">
<meta name="apple-mobile-web-app-title" content="HAB•LAB">
<link rel="apple-touch-icon" href="<?php echo esc_url( $hablab_app . 'assets/icons/apple-touch-icon.png?v=' . $hablab_v ); ?>">
<link rel="icon" href="<?php echo esc_url( $hablab_app . 'assets/icons/icon-192.png?v=' . $hablab_v ); ?>">

<link rel="stylesheet" href="<?php echo esc_url( $hablab_app . 'styles.css?v=' . $hablab_v ); ?>">

<?php
// Version-stamp EVERY module (1.11.4), not just the entry point. Nested
// imports ("./views/habits.js") carry no ?v=, so the browser — or a host-side
// cache — could keep serving a previous release's body after an update (the
// "nothing changed" trap, visible as the gear menu's v<old> → v<new> chip).
// An import map matches on the RESOLVED absolute URL, so mapping each bare
// module URL to its ?v=<version> twin rewrites every nested import to a
// brand-new URL per release. Any cache keyed by URL is bypassed by design.
$hablab_imports = array(
	'preact'       => $hablab_app . 'vendor/preact.module.js?v=' . $hablab_v,
	'preact/hooks' => $hablab_app . 'vendor/hooks.module.js?v=' . $hablab_v,
	'htm'          => $hablab_app . 'vendor/htm.module.js?v=' . $hablab_v,
);
$hablab_src_dir = HABLAB_DIR . 'app/src';
if ( is_dir( $hablab_src_dir ) ) {
	$hablab_it = new RecursiveIteratorIterator( new RecursiveDirectoryIterator( $hablab_src_dir, FilesystemIterator::SKIP_DOTS ) );
	foreach ( $hablab_it as $hablab_file ) {
		if ( 'js' !== strtolower( $hablab_file->getExtension() ) ) {
			continue;
		}
		$hablab_rel = str_replace( '\\', '/', substr( $hablab_file->getPathname(), strlen( HABLAB_DIR ) ) );
		$hablab_url = HABLAB_URL . ltrim( $hablab_rel, '/' );
		$hablab_imports[ $hablab_url ] = $hablab_url . '?v=' . $hablab_v;
	}
}
?>
<script type="importmap"><?php echo wp_json_encode( array( 'imports' => $hablab_imports ), JSON_UNESCAPED_SLASHES ); ?></script>
<script>
window.HABLAB_CONFIG = {
	mode: <?php echo wp_json_encode( $hablab_mode ); ?>,
	api:  <?php echo wp_json_encode( esc_url_raw( rest_url( 'hablab/v1' ) ) ); ?>,
	base: <?php echo wp_json_encode( esc_url_raw( $hablab_app ) ); ?>,
	version: <?php echo wp_json_encode( $hablab_v ); ?>,
	swUrl: <?php echo wp_json_encode( esc_url_raw( home_url( '/hablab-sw.js' ) ) ); ?>
};
</script>
</head>
<body>
<div id="app"></div>
<script type="module" src="<?php echo esc_url( $hablab_app . 'src/main.js?v=' . $hablab_v ); ?>"></script>
</body>
</html>
