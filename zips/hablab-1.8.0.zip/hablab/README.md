# HAB•LAB

Personal habit / time-block / music-practice tracker PWA,
served by a self-contained WordPress plugin. Live app at **`/hablab.html`**
(passphrase + device tokens), public sandbox at **`/hablab-demo.html`**; the old
`/tracker` and `/tracker/demo` URLs 301-redirect to the new ones.

## Install / deploy

1. Copy this folder to `wp-content/plugins/hablab/` (the folder **must** be
   named `hablab` — the PWA manifest icon paths and WP's plugin identity
   depend on it; only the display name is HAB•LAB), or upload the release zip via
   Plugins → Add New → Upload.
2. Activate the plugin. Activation creates the `wp_hablab_*` tables, registers the
   `/hablab.html` routes (+ legacy `/tracker` redirects), and schedules the daily backup.
3. **Pretty permalinks are required** (Settings → Permalinks, any structure). The
   admin shows a warning if they're off.
4. Go to **Settings → HAB•LAB** and set the passphrase (min 8 chars). The same page
   lists devices (revoke buttons) and backup status.
5. Open `/hablab.html`, unlock with the passphrase, open the **gear → Import JSON**, and
   import `seed/july-2026-import.json` to load the July 2026 paper data
   (habits B1 B2 FL S1 S2 EX ME AM RE ♪, weights Jul 1–8, MALL/RET block fills).
   Importing **replaces all data** — it's meant for this one-time seeding and for
   restoring backups.

## iPhone install

Open `https://seejennings.com/hablab.html` in Safari → Share → **Add to Home Screen**.
Standalone display, theme-colored status bar, offline app shell via service worker.
(After the 1.6.0 URL move, delete any old home-screen app pointing at `/tracker`
and re-add from the new URL.)

## Backups

- WP-Cron writes a daily JSON export to `wp-content/uploads/hablab-backups/`
  (`.htaccess`-denied; on **nginx**, deny that path in the server config).
- Retention: newest 30 dailies + first-of-month keepers for 12 months.
- Manual Export/Import JSON lives in the app's gear menu. Import always writes a
  safety backup first and runs inside a transaction.

## Reminders

- Optional staleness nudges, configured under **Settings → HAB•LAB → Reminders**.
  A rule watches habits or time-block categories (one target = an individual
  reminder, several = a bundle) and a daily WP-Cron check emails **one plain-text
  digest per day** via `wp_mail()` when anything passes its threshold; a
  per-target cooldown stops repeat nagging.
- A target is only watched once it's been completed at least once; inactive or
  ended items are never nudged. Config (`reminders`) and send state
  (`reminders_state`) are settings rows, so they ride along in every backup.
- Use the **Send test email** / **Preview what's due now** buttons to verify
  delivery and evaluation; if digests land in spam, install WP Mail SMTP pointed
  at a transactional provider — no code change needed.
- WP-Cron only fires on site traffic, so on a quiet day the digest can be a few
  hours late (never early) — same trade-off as the daily backup. If exact timing
  ever matters, point a real server cron at `wp-cron.php`.

## Updates (GitHub pipeline — since 1.7.0)

- **Source of truth:** private repo `Blazzzar/hablab`. Public shelf
  `Blazzzar/hablab-updates` (GitHub Pages) serves `hablab.json`
  (channel manifest) + built zips — the plugin's self-updater
  (`includes/class-hablab-updater.php`) reads it and rides WordPress's native
  update flow. Plugin row gets **Check for updates / Switch channel /
  Roll back** links. Default channel: **stable**.
- **Per update Chris clicks "update now" in wp-admin — that's the whole job.**
  The one-time manual zip upload of 1.7.0 is the LAST manual install.
- **Session release ritual:** bump version in 3 places (plugin header /
  `HABLAB_VERSION` / readme.txt Stable tag) + a `## <version>` section in
  `CHANGELOG.md` → `bin/build-zip.sh` → `bin/publish-channel.sh stable` →
  commit + push → archive the zip to the ONLINE TRACKERS folder root.
  Plain English: `docs/PIPELINE.md`.
- **Auth:** Cowork sessions read the fine-grained PAT from
  `ONLINE TRACKERS/github-token.txt` (repo parent — gitignored; NEVER commit
  or print it). Repo-connected Claude Code sessions push natively.

## Architecture

- **No build step.** `app/` is plain ES modules with vendored Preact + htm (import
  map), Lucide sprite for the icon picker, latin-subset woff2 fonts. Deploying a
  front-end change = copying files; bump `Version:` in `hablab.php` — it cache-busts assets AND stamps the
  service-worker cache version (the plugin substitutes it into sw.js on serve).
- **PHP** (`includes/`): `class-hablab-db.php` schema + settings, `class-hablab-auth.php`
  passphrase → SHA-256'd device tokens (`X-Hablab-Token` header), `class-hablab-rest.php`
  REST under `hablab/v1`, `class-hablab-backups.php` cron/export/import,
  `class-hablab-admin.php` settings page, `template-app.php` the app shell
  (keep in sync with `app/index.html`, its local-dev mirror).
- **Modes**: WP injects `window.HABLAB_CONFIG` (`live` or `demo`); with no config the
  app runs in `dev` mode against a localStorage mock (`app/src/api.js`), seeded with
  the July paper transcription. `?mode=demo` previews the demo locally.

## Local development

```
python3 dev-server.py   # serves app/ at http://localhost:8642, mock data, no WP needed
```

Theme tokens are CSS variables set from server settings; the in-app color workbench
(palette FAB) live-previews and deploys them. Open circles keep a fixed outer
diameter — stroke grows inward (`r = R − stroke/2`).
