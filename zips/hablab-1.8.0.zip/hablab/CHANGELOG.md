# HAB•LAB changelog

## 1.8.0
Full identity rename: plugin slug/basename is now `hablab/hablab.php`, and every internal identifier moved off the old name — classes `Hablab_*`, constants `HABLAB_*`, `wp_hablab_*` tables, REST namespace `hablab/v1`, auth header `X-Hablab-Token`, options/hooks/nonces `hablab_*`, SW cache + backup format `hablab-*`, repos `Blazzzar/hablab` + `hablab-updates`. A guarded one-time migration renames the live site's old tables in place (data preserved), carries the passphrase hash over, moves the backups folder, clears old cron events, and deactivates the old plugin entry. Old-format backup files remain importable; device sessions and iPhone PWA installs need a one-time re-login/re-add.

## 1.7.0
Self-hosted GitHub update pipeline (STEMMAXXER/WeIdea recipe): `Hablab_Updater` + `Hablab_Updater_Admin` check the public channel manifest on GitHub Pages and ride WordPress's native update flow — one-click updates, stable/beta tracks (default stable), "Check for updates" / channel-switch / one-click rollback links in the plugin row, `Update URI` header. New `bin/build-zip.sh` (version + changelog gates, php -l) and `bin/publish-channel.sh stable|beta` (updates the `hablab-updates` shelf: manifest + zips, retains last 5, prunes, pushes). Added `readme.txt` + this changelog. This build is the LAST manual zip upload.

## 1.6.0
Renamed to HAB•LAB; app moved from `/tracker` to `/hablab.html` (demo `/hablab-demo.html`), 301 redirects from all legacy URLs. PWA manifest/scope/start_url updated, service worker served from root (`/hablab-sw.js`), admin + email strings renamed ("HAB•LAB nudge: …"), rewrite flush added to the version-bump self-heal.

## 1.5.0
Habit-staleness email reminders (feature 01): daily WP-Cron digest via `wp_mail()`, rules editor (individual or bundled targets, threshold + cooldown) with Send-test and Preview on Settings → Tracker; config + send state in settings rows so they ride along in backups. 45-assertion standalone test harness.

## 1.4.3
Workbench header shows the build number (from HABLAB_CONFIG.version; "dev build" locally).

## 1.4.2
Workbench: horizontal shadow offset slider (shadowX token, −40..+40px).

## 1.4.1
Category headers: badge and/or icon with three states; songs.created_at backfill for pre-1.1 songs.

## 1.4.0
Time-block circles 15% bigger with size slider; full-name + icon category labels; custom tooth/meditation icons; label-box background token; iOS burst/confetti fixes.
