<?php
defined( 'ABSPATH' ) || exit;

/**
 * Plugins-screen UI for the update channel: "Check for updates now",
 * the per-site stable/beta switch, and one-click version rollback.
 * Ported from the STEMMAXXER pipeline (SMX_Updater_Admin, itself from
 * WeIdea Studio's WI_Updater_Admin), HAB•LAB naming.
 *
 * Rollback rides WordPress's own upgrade flow: arming a rollback stores
 * a short-lived target version, then hands off to the native
 * update.php?action=upgrade-plugin screen, where Hablab_Updater presents
 * the older retained release as "the update". Same pipeline, same UI,
 * same safety — just pointed backwards.
 */
class Hablab_Updater_Admin {

	public static function init() {
		add_filter( 'plugin_action_links_' . Hablab_Updater::basename(), array( __CLASS__, 'action_links' ) );
		add_action( 'admin_post_hablab_check_updates', array( __CLASS__, 'handle_check_updates' ) );
		add_action( 'admin_post_hablab_switch_channel', array( __CLASS__, 'handle_switch_channel' ) );
		add_action( 'admin_post_hablab_rollback', array( __CLASS__, 'handle_rollback' ) );
		add_action( 'admin_notices', array( __CLASS__, 'notices' ) );
	}

	/**
	 * Add "Check for updates", "switch channel", and "roll back" to the
	 * plugin's row on the Plugins screen.
	 *
	 * @param string[] $links Existing action links.
	 * @return string[]
	 */
	public static function action_links( $links ) {
		if ( ! current_user_can( 'update_plugins' ) ) {
			return $links;
		}

		$updater = Hablab_Updater::instance();

		$check_url = wp_nonce_url(
			add_query_arg( array( 'action' => 'hablab_check_updates' ), admin_url( 'admin-post.php' ) ),
			'hablab_check_updates'
		);
		$links['hablab-check'] = sprintf(
			'<a href="%s">%s</a>',
			esc_url( $check_url ),
			esc_html( 'Check for updates' )
		);

		$other      = 'beta' === $updater->channel() ? 'stable' : 'beta';
		$switch_url = wp_nonce_url(
			add_query_arg(
				array(
					'action'  => 'hablab_switch_channel',
					'channel' => $other,
				),
				admin_url( 'admin-post.php' )
			),
			'hablab_switch_channel_' . $other
		);
		$links['hablab-channel'] = sprintf(
			'<a href="%s">%s</a>',
			esc_url( $switch_url ),
			'beta' === $other
				? esc_html( 'Switch to beta channel' )
				: esc_html( 'Switch to stable channel' )
		);

		$target = $updater->rollback_target();
		if ( $target ) {
			$rollback_url = wp_nonce_url(
				add_query_arg(
					array(
						'action'  => 'hablab_rollback',
						'version' => rawurlencode( (string) $target->version ),
					),
					admin_url( 'admin-post.php' )
				),
				'hablab_rollback_' . (string) $target->version
			);
			$links['hablab-rollback'] = sprintf(
				'<a href="%s">%s</a>',
				esc_url( $rollback_url ),
				sprintf( 'Roll back to %s', esc_html( (string) $target->version ) )
			);
		}

		return $links;
	}

	/**
	 * Re-fetch the manifest and recompute updates immediately, then say
	 * what was found.
	 */
	public static function handle_check_updates() {
		check_admin_referer( 'hablab_check_updates' );
		if ( ! current_user_can( 'update_plugins' ) ) {
			wp_die( 'You are not allowed to check for HAB•LAB updates.' );
		}

		$updater = Hablab_Updater::instance();
		$updater->flush_manifest_cache();
		delete_site_transient( 'update_plugins' );

		$release = $updater->channel_release();
		$newer   = $release && version_compare( (string) $release->version, HABLAB_VERSION, '>' );

		$args = array( 'hablab-checked' => $newer ? 'update' : 'uptodate' );
		if ( $newer ) {
			$args['hablab-new'] = rawurlencode( (string) $release->version );
		}
		wp_safe_redirect( add_query_arg( $args, admin_url( 'plugins.php' ) ) );
		exit;
	}

	/**
	 * Switch the site's release channel, drop caches, re-check.
	 */
	public static function handle_switch_channel() {
		$channel = isset( $_GET['channel'] ) ? sanitize_key( wp_unslash( $_GET['channel'] ) ) : '';
		check_admin_referer( 'hablab_switch_channel_' . $channel );
		if ( ! current_user_can( 'update_plugins' ) ) {
			wp_die( 'You are not allowed to change the HAB•LAB release channel.' );
		}

		update_option( Hablab_Updater::CHANNEL_OPTION, 'beta' === $channel ? 'beta' : 'stable' );

		// A channel change must be visible immediately, not after cache expiry.
		Hablab_Updater::instance()->flush_manifest_cache();
		delete_site_transient( 'update_plugins' );

		wp_safe_redirect(
			add_query_arg( 'hablab-channel', rawurlencode( $channel ), admin_url( 'plugins.php' ) )
		);
		exit;
	}

	/**
	 * Arm a rollback and hand off to the native upgrade screen.
	 */
	public static function handle_rollback() {
		$version = isset( $_GET['version'] ) ? sanitize_text_field( wp_unslash( $_GET['version'] ) ) : '';
		check_admin_referer( 'hablab_rollback_' . $version );
		if ( ! current_user_can( 'update_plugins' ) ) {
			wp_die( 'You are not allowed to roll HAB•LAB back.' );
		}

		if ( ! Hablab_Updater::instance()->find_release( $version ) ) {
			wp_die( 'That version is not retained on the update channel.' );
		}

		set_site_transient( Hablab_Updater::ROLLBACK_TARGET, $version, 5 * MINUTE_IN_SECONDS );

		// Built by hand, NOT with wp_nonce_url(): that helper HTML-escapes
		// its output (for use in href attributes), which corrupts the
		// query string when sent as a Location header.
		$upgrade_url = add_query_arg(
			array(
				'action'   => 'upgrade-plugin',
				'plugin'   => rawurlencode( Hablab_Updater::basename() ),
				'_wpnonce' => wp_create_nonce( 'upgrade-plugin_' . Hablab_Updater::basename() ),
			),
			self_admin_url( 'update.php' )
		);
		wp_safe_redirect( $upgrade_url );
		exit;
	}

	/**
	 * Confirmations after a channel switch or a manual check.
	 */
	public static function notices() {
		if ( ! current_user_can( 'update_plugins' ) ) {
			return;
		}

		if ( ! empty( $_GET['hablab-channel'] ) ) {
			$channel = sanitize_key( wp_unslash( $_GET['hablab-channel'] ) );
			printf(
				'<div class="notice notice-success is-dismissible"><p>%s</p></div>',
				'beta' === $channel
					? 'HAB•LAB is now on the beta channel — this site receives every new build.'
					: 'HAB•LAB is now on the stable channel — this site receives promoted releases only.'
			);
		}

		if ( ! empty( $_GET['hablab-checked'] ) ) {
			$state = sanitize_key( wp_unslash( $_GET['hablab-checked'] ) );
			if ( 'update' === $state ) {
				$new = isset( $_GET['hablab-new'] ) ? sanitize_text_field( wp_unslash( $_GET['hablab-new'] ) ) : '';
				printf(
					'<div class="notice notice-success is-dismissible"><p>%s</p></div>',
					esc_html( sprintf( 'HAB•LAB %s is available — the update link now appears in the plugin row below.', $new ) )
				);
			} else {
				printf(
					'<div class="notice notice-info is-dismissible"><p>%s</p></div>',
					esc_html( sprintf( 'Checked the HAB•LAB release channel — v%s is the newest build for this site\'s channel.', HABLAB_VERSION ) )
				);
			}
		}
	}
}
