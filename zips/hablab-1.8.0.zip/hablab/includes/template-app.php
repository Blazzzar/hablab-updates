<?php
/**
 * Full-page shell for /hablab.html (live) and /hablab-demo.html.
 * Keep the markup in sync with app/index.html (the local-dev copy).
 */
defined( 'ABSPATH' ) || exit;

$hablab_mode = ( 'demo' === get_query_var( 'hablab' ) ) ? 'demo' : 'live';
$hablab_app  = HABLAB_URL . 'app/';
$hablab_v    = HABLAB_VERSION;

header( 'Content-Type: text/html; charset=utf-8' );
?><!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<title>HAB•LAB<?php echo 'demo' === $hablab_mode ? ' — Demo' : ''; ?></title>

<link rel="manifest" href="<?php echo esc_url( home_url( '/hablab.webmanifest' ) ); ?>">
<meta name="theme-color" content="#6CC7E6">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-status-bar-style" content="default">
<meta name="apple-mobile-web-app-title" content="HAB•LAB">
<link rel="apple-touch-icon" href="<?php echo esc_url( $hablab_app . 'assets/icons/apple-touch-icon.png?v=' . $hablab_v ); ?>">
<link rel="icon" href="<?php echo esc_url( $hablab_app . 'assets/icons/icon-192.png?v=' . $hablab_v ); ?>">

<link rel="stylesheet" href="<?php echo esc_url( $hablab_app . 'styles.css?v=' . $hablab_v ); ?>">

<script type="importmap">
{ "imports": {
	"preact":       "<?php echo esc_url( $hablab_app . 'vendor/preact.module.js?v=' . $hablab_v ); ?>",
	"preact/hooks": "<?php echo esc_url( $hablab_app . 'vendor/hooks.module.js?v=' . $hablab_v ); ?>",
	"htm":          "<?php echo esc_url( $hablab_app . 'vendor/htm.module.js?v=' . $hablab_v ); ?>"
} }
</script>
<script>
window.HABLAB_CONFIG = {
	mode: <?php echo wp_json_encode( $hablab_mode ); ?>,
	api:  <?php echo wp_json_encode( esc_url_raw( rest_url( 'hablab/v1' ) ) ); ?>,
	base: <?php echo wp_json_encode( esc_url_raw( $hablab_app ) ); ?>,
	version: <?php echo wp_json_encode( $hablab_v ); ?>,
	swUrl: <?php echo wp_json_encode( esc_url_raw( home_url( '/hablab-sw.js' ) ) ); ?>
};
</script>
</head>
<body>
<div id="app"></div>
<script type="module" src="<?php echo esc_url( $hablab_app . 'src/main.js?v=' . $hablab_v ); ?>"></script>
</body>
</html>
