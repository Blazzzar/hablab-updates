<?php
defined( 'ABSPATH' ) || exit;

/**
 * Automated + manual backups (§8).
 *
 * WP-Cron runs a daily JSON export into wp-content/uploads/hablab-backups/
 * (blocked from direct web access via .htaccess + a blank index.html; on
 * nginx the directory should be denied in the server config, noted on the
 * admin page). Retention: the 30 most recent dailies, plus the first backup
 * of each month for the last 12 months.
 */
class Hablab_Backups {

	const CRON_HOOK = 'hablab_daily_backup';
	const KEEP_DAILY = 30;
	const KEEP_MONTHLY = 12;

	public static function init() {
		add_action( self::CRON_HOOK, array( __CLASS__, 'run_backup' ) );
	}

	public static function schedule() {
		if ( ! wp_next_scheduled( self::CRON_HOOK ) ) {
			wp_schedule_event( time() + HOUR_IN_SECONDS, 'daily', self::CRON_HOOK );
		}
	}

	public static function unschedule() {
		wp_clear_scheduled_hook( self::CRON_HOOK );
	}

	public static function backup_dir() {
		$uploads = wp_upload_dir();
		return trailingslashit( $uploads['basedir'] ) . 'hablab-backups';
	}

	/** Full data export as an associative array (also used by GET /export). */
	public static function export_data() {
		global $wpdb;
		$tables = array(
			'habits', 'habit_entries', 'weight_entries',
			'timeblock_categories', 'timeblock_entries',
			'instruments', 'songs', 'song_trackers', 'playthrough_events',
			'exercises', 'workout_rows',
		);
		$out = array(
			'format'      => 'hablab-backup',
			'version'     => 1,
			'exported_at' => current_time( 'mysql', true ),
			'settings'    => Hablab_DB::all_settings(),
		);
		foreach ( $tables as $t ) {
			$out[ $t ] = $wpdb->get_results( 'SELECT * FROM ' . Hablab_DB::table( $t ), ARRAY_A );
		}
		return $out;
	}

	/** @return string|false Written file path, or false on failure. */
	public static function run_backup() {
		$uploads = wp_upload_dir();
		if ( ! empty( $uploads['error'] ) ) {
			return false;
		}
		$dir = self::backup_dir();
		if ( ! wp_mkdir_p( $dir ) ) {
			return false;
		}
		// Deny direct web access (Apache; harmless elsewhere).
		if ( ! file_exists( $dir . '/.htaccess' ) ) {
			file_put_contents( $dir . '/.htaccess', "Require all denied\n" );
		}
		if ( ! file_exists( $dir . '/index.html' ) ) {
			file_put_contents( $dir . '/index.html', '' );
		}
		$file = $dir . '/backup-' . gmdate( 'Ymd-His' ) . '.json';
		if ( false === file_put_contents( $file, wp_json_encode( self::export_data() ) ) ) {
			return false;
		}
		self::prune();
		return $file;
	}

	/** Keep the newest KEEP_DAILY files + the oldest file of each of the last KEEP_MONTHLY months. */
	private static function prune() {
		$files = glob( self::backup_dir() . '/backup-*.json' ) ?: array();
		if ( ! $files ) {
			return;
		}
		sort( $files ); // filenames sort chronologically
		$keep = array();
		// newest N dailies
		foreach ( array_slice( $files, -self::KEEP_DAILY ) as $f ) {
			$keep[ $f ] = true;
		}
		// first backup of each month, newest 12 distinct months
		$monthly = array();
		foreach ( $files as $f ) {
			if ( preg_match( '/backup-(\d{6})/', basename( $f ), $m ) && ! isset( $monthly[ $m[1] ] ) ) {
				$monthly[ $m[1] ] = $f;
			}
		}
		krsort( $monthly );
		foreach ( array_slice( $monthly, 0, self::KEEP_MONTHLY, true ) as $f ) {
			$keep[ $f ] = true;
		}
		foreach ( $files as $f ) {
			if ( ! isset( $keep[ $f ] ) ) {
				unlink( $f );
			}
		}
	}

	public static function list_backups() {
		$files = glob( self::backup_dir() . '/backup-*.json' ) ?: array();
		$out   = array();
		foreach ( $files as $f ) {
			$out[] = array(
				'file'  => basename( $f ),
				'bytes' => filesize( $f ),
				'time'  => gmdate( 'Y-m-d H:i', filemtime( $f ) ) . ' UTC',
			);
		}
		usort( $out, function ( $a, $b ) {
			return strcmp( $b['file'], $a['file'] );
		} );
		return $out;
	}

	/**
	 * Replace-all import from an export payload. Runs a safety backup first.
	 * Returns true or WP_Error.
	 */
	public static function import_data( $data ) {
		// 'seej-tracker-backup' is the pre-1.8.0 marker — backups written on
		// the server before the identity change must stay importable.
		$formats = array( 'hablab-backup', 'seej-tracker-backup' );
		if ( ! is_array( $data ) || ! isset( $data['format'] ) || ! in_array( $data['format'], $formats, true ) ) {
			return new WP_Error( 'hablab_bad_import', 'Not a hablab backup file.', array( 'status' => 400 ) );
		}
		$tables = array(
			'habits', 'habit_entries', 'weight_entries',
			'timeblock_categories', 'timeblock_entries',
			'instruments', 'songs', 'song_trackers', 'playthrough_events',
			'exercises', 'workout_rows',
		);
		foreach ( $tables as $t ) {
			if ( isset( $data[ $t ] ) && ! is_array( $data[ $t ] ) ) {
				return new WP_Error( 'hablab_bad_import', "Malformed table: $t", array( 'status' => 400 ) );
			}
		}

		// Safety net before the destructive replace — refuse to proceed without it.
		if ( ! self::run_backup() ) {
			return new WP_Error( 'hablab_backup_failed', 'Could not write a safety backup; import aborted.', array( 'status' => 500 ) );
		}

		global $wpdb;
		$wpdb->query( 'START TRANSACTION' );
		foreach ( $tables as $t ) {
			if ( ! isset( $data[ $t ] ) ) {
				continue;
			}
			$table   = Hablab_DB::table( $t );
			$columns = array_flip( (array) $wpdb->get_col( "DESCRIBE $table", 0 ) );
			$wpdb->query( "DELETE FROM $table" );
			foreach ( $data[ $t ] as $row ) {
				if ( ! is_array( $row ) ) {
					continue;
				}
				// Only known columns; serialize any non-scalar leftovers.
				$clean = array_intersect_key( array_map( function ( $v ) {
					return is_scalar( $v ) || null === $v ? $v : wp_json_encode( $v );
				}, $row ), $columns );
				if ( $clean && false === $wpdb->insert( $table, $clean ) ) {
					$wpdb->query( 'ROLLBACK' );
					return new WP_Error( 'hablab_db', "Import failed on $t: " . $wpdb->last_error, array( 'status' => 500 ) );
				}
			}
		}
		// Backups from before independent dots carry only cumulative counts.
		Hablab_DB::backfill_timeblock_masks();
		if ( isset( $data['settings'] ) && is_array( $data['settings'] ) ) {
			foreach ( $data['settings'] as $key => $value ) {
				Hablab_DB::put_setting( $key, $value );
			}
		}
		$wpdb->query( 'COMMIT' );
		return true;
	}
}
