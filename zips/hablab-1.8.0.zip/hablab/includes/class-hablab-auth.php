<?php
defined( 'ABSPATH' ) || exit;

/**
 * Passphrase login + long-lived device tokens.
 * The passphrase hash lives in wp_options (set from the admin page).
 * Tokens are 32 random bytes (hex); only their SHA-256 hash is stored.
 */
class Hablab_Auth {

	const OPTION_HASH   = 'hablab_passphrase_hash';
	const MAX_ATTEMPTS  = 10;
	const WINDOW_SECS   = 600;

	public static function set_passphrase( $passphrase ) {
		update_option( self::OPTION_HASH, wp_hash_password( $passphrase ), false );
	}

	public static function has_passphrase() {
		return (bool) get_option( self::OPTION_HASH );
	}

	/** Attempt a login; returns raw token string or WP_Error. */
	public static function login( $passphrase, $label = '' ) {
		$ip  = isset( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) ) : 'unknown';
		$key = 'hablab_login_' . md5( $ip );
		// Fixed window: {count, first-attempt time}; expiry never slides on retries.
		$bucket = get_transient( $key );
		if ( ! is_array( $bucket ) || ( time() - (int) $bucket['first'] ) > self::WINDOW_SECS ) {
			$bucket = array( 'count' => 0, 'first' => time() );
		}
		if ( $bucket['count'] >= self::MAX_ATTEMPTS ) {
			return new WP_Error( 'hablab_locked', 'Too many attempts. Try again later.', array( 'status' => 429 ) );
		}

		$hash = get_option( self::OPTION_HASH );
		if ( ! $hash || ! wp_check_password( (string) $passphrase, $hash ) ) {
			$bucket['count']++;
			$remaining = max( 1, self::WINDOW_SECS - ( time() - (int) $bucket['first'] ) );
			set_transient( $key, $bucket, $remaining );
			return new WP_Error( 'hablab_bad_pass', 'Wrong passphrase.', array( 'status' => 401 ) );
		}
		delete_transient( $key );

		$token = bin2hex( random_bytes( 32 ) );
		global $wpdb;
		$wpdb->insert( Hablab_DB::table( 'devices' ), array(
			'token_hash' => hash( 'sha256', $token ),
			'label'      => sanitize_text_field( $label ?: self::guess_label() ),
			'created_at' => current_time( 'mysql', true ),
			'last_seen'  => current_time( 'mysql', true ),
		) );
		return $token;
	}

	/** Validate a raw token; touches last_seen. Returns device row or false. */
	public static function check_token( $token ) {
		if ( ! is_string( $token ) || strlen( $token ) !== 64 || ! ctype_xdigit( $token ) ) {
			return false;
		}
		global $wpdb;
		$table  = Hablab_DB::table( 'devices' );
		$device = $wpdb->get_row( $wpdb->prepare(
			"SELECT * FROM $table WHERE token_hash = %s AND revoked = 0", hash( 'sha256', $token )
		), ARRAY_A );
		if ( ! $device ) {
			return false;
		}
		// Touch last_seen at most once a minute to keep writes cheap.
		if ( empty( $device['last_seen'] ) || strtotime( $device['last_seen'] . ' UTC' ) < time() - 60 ) {
			$wpdb->update( $table, array( 'last_seen' => current_time( 'mysql', true ) ), array( 'id' => $device['id'] ) );
		}
		return $device;
	}

	public static function list_devices() {
		global $wpdb;
		$table = Hablab_DB::table( 'devices' );
		return $wpdb->get_results( "SELECT id, label, created_at, last_seen, revoked FROM $table ORDER BY last_seen DESC", ARRAY_A );
	}

	public static function revoke_device( $id ) {
		global $wpdb;
		return false !== $wpdb->update( Hablab_DB::table( 'devices' ), array( 'revoked' => 1 ), array( 'id' => (int) $id ) );
	}

	private static function guess_label() {
		$ua = isset( $_SERVER['HTTP_USER_AGENT'] ) ? $_SERVER['HTTP_USER_AGENT'] : '';
		if ( false !== stripos( $ua, 'iPhone' ) ) return 'iPhone';
		if ( false !== stripos( $ua, 'iPad' ) ) return 'iPad';
		if ( false !== stripos( $ua, 'Android' ) ) return 'Android';
		if ( false !== stripos( $ua, 'Macintosh' ) ) return 'Mac';
		if ( false !== stripos( $ua, 'Windows' ) ) return 'Windows PC';
		return 'Device';
	}
}
