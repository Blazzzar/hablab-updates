<?php
defined( 'ABSPATH' ) || exit;

class Hablab_REST {

	const NS = 'hablab/v1';

	public function register_routes() {
		register_rest_route( self::NS, '/auth/login', array(
			'methods'             => 'POST',
			'callback'            => array( $this, 'login' ),
			'permission_callback' => '__return_true',
		) );
		register_rest_route( self::NS, '/devices', array(
			'methods'             => 'GET',
			'callback'            => array( $this, 'devices' ),
			'permission_callback' => array( $this, 'auth' ),
		) );
		register_rest_route( self::NS, '/devices/(?P<id>\d+)', array(
			'methods'             => 'DELETE',
			'callback'            => array( $this, 'revoke_device' ),
			'permission_callback' => array( $this, 'auth' ),
		) );
		register_rest_route( self::NS, '/bootstrap', array(
			'methods'             => 'GET',
			'callback'            => array( $this, 'bootstrap' ),
			'permission_callback' => array( $this, 'auth' ),
		) );
		register_rest_route( self::NS, '/month', array(
			'methods'             => 'GET',
			'callback'            => array( $this, 'month' ),
			'permission_callback' => array( $this, 'auth' ),
		) );
		register_rest_route( self::NS, '/habits', array(
			'methods'             => 'POST',
			'callback'            => array( $this, 'create_habit' ),
			'permission_callback' => array( $this, 'auth' ),
		) );
		register_rest_route( self::NS, '/habits/(?P<id>\d+)', array(
			array(
				'methods'             => 'PUT',
				'callback'            => array( $this, 'update_habit' ),
				'permission_callback' => array( $this, 'auth' ),
			),
			array(
				'methods'             => 'DELETE',
				'callback'            => array( $this, 'delete_habit' ),
				'permission_callback' => array( $this, 'auth' ),
			),
		) );
		register_rest_route( self::NS, '/habit-entries', array(
			'methods'             => 'PUT',
			'callback'            => array( $this, 'put_habit_entry' ),
			'permission_callback' => array( $this, 'auth' ),
		) );
		register_rest_route( self::NS, '/weight', array(
			'methods'             => 'PUT',
			'callback'            => array( $this, 'put_weight' ),
			'permission_callback' => array( $this, 'auth' ),
		) );
		register_rest_route( self::NS, '/categories', array(
			'methods'             => 'POST',
			'callback'            => array( $this, 'create_category' ),
			'permission_callback' => array( $this, 'auth' ),
		) );
		register_rest_route( self::NS, '/categories/(?P<id>\d+)', array(
			array(
				'methods'             => 'PUT',
				'callback'            => array( $this, 'update_category' ),
				'permission_callback' => array( $this, 'auth' ),
			),
			array(
				'methods'             => 'DELETE',
				'callback'            => array( $this, 'delete_category' ),
				'permission_callback' => array( $this, 'auth' ),
			),
		) );
		register_rest_route( self::NS, '/timeblock-entries', array(
			'methods'             => 'PUT',
			'callback'            => array( $this, 'put_timeblock_entry' ),
			'permission_callback' => array( $this, 'auth' ),
		) );
		register_rest_route( self::NS, '/songs', array(
			'methods'             => 'POST',
			'callback'            => array( $this, 'create_song' ),
			'permission_callback' => array( $this, 'auth' ),
		) );
		register_rest_route( self::NS, '/songs/(?P<id>\d+)', array(
			array(
				'methods'             => 'PUT',
				'callback'            => array( $this, 'update_song' ),
				'permission_callback' => array( $this, 'auth' ),
			),
			array(
				'methods'             => 'DELETE',
				'callback'            => array( $this, 'delete_song' ),
				'permission_callback' => array( $this, 'auth' ),
			),
		) );
		register_rest_route( self::NS, '/songs/(?P<id>\d+)/trackers', array(
			'methods'             => 'POST',
			'callback'            => array( $this, 'create_tracker' ),
			'permission_callback' => array( $this, 'auth' ),
		) );
		register_rest_route( self::NS, '/trackers/(?P<id>\d+)', array(
			array(
				'methods'             => 'PUT',
				'callback'            => array( $this, 'update_tracker' ),
				'permission_callback' => array( $this, 'auth' ),
			),
			array(
				'methods'             => 'DELETE',
				'callback'            => array( $this, 'delete_tracker' ),
				'permission_callback' => array( $this, 'auth' ),
			),
		) );
		register_rest_route( self::NS, '/trackers/(?P<id>\d+)/playthroughs', array(
			array(
				'methods'             => 'POST',
				'callback'            => array( $this, 'add_playthrough' ),
				'permission_callback' => array( $this, 'auth' ),
			),
			array(
				'methods'             => 'DELETE',
				'callback'            => array( $this, 'remove_playthrough' ),
				'permission_callback' => array( $this, 'auth' ),
			),
		) );
		register_rest_route( self::NS, '/instruments', array(
			'methods'             => 'POST',
			'callback'            => array( $this, 'create_instrument' ),
			'permission_callback' => array( $this, 'auth' ),
		) );
		register_rest_route( self::NS, '/exercises', array(
			'methods'             => 'POST',
			'callback'            => array( $this, 'create_exercise' ),
			'permission_callback' => array( $this, 'auth' ),
		) );
		register_rest_route( self::NS, '/exercises/(?P<id>\d+)', array(
			'methods'             => 'PUT',
			'callback'            => array( $this, 'update_exercise' ),
			'permission_callback' => array( $this, 'auth' ),
		) );
		register_rest_route( self::NS, '/workout-rows', array(
			'methods'             => 'PUT',
			'callback'            => array( $this, 'put_workout_row' ),
			'permission_callback' => array( $this, 'auth' ),
		) );
		register_rest_route( self::NS, '/workout-rows/(?P<id>\d+)', array(
			'methods'             => 'DELETE',
			'callback'            => array( $this, 'delete_workout_row' ),
			'permission_callback' => array( $this, 'auth' ),
		) );
		register_rest_route( self::NS, '/export', array(
			'methods'             => 'GET',
			'callback'            => array( $this, 'export' ),
			'permission_callback' => array( $this, 'auth' ),
		) );
		register_rest_route( self::NS, '/import', array(
			'methods'             => 'POST',
			'callback'            => array( $this, 'import' ),
			'permission_callback' => array( $this, 'auth' ),
		) );
		register_rest_route( self::NS, '/backups', array(
			'methods'             => 'GET',
			'callback'            => array( $this, 'backups' ),
			'permission_callback' => array( $this, 'auth' ),
		) );
		register_rest_route( self::NS, '/analytics', array(
			'methods'             => 'GET',
			'callback'            => array( $this, 'analytics' ),
			'permission_callback' => array( $this, 'auth' ),
		) );
		register_rest_route( self::NS, '/settings', array(
			array(
				'methods'             => 'GET',
				'callback'            => array( $this, 'get_settings' ),
				'permission_callback' => array( $this, 'auth' ),
			),
			array(
				'methods'             => 'PUT',
				'callback'            => array( $this, 'put_settings' ),
				'permission_callback' => array( $this, 'auth' ),
			),
		) );
	}

	/** Permission callback: X-Hablab-Token header must match an active device. */
	public function auth( WP_REST_Request $req ) {
		$token = $req->get_header( 'X-Hablab-Token' );
		if ( $token && Hablab_Auth::check_token( $token ) ) {
			return true;
		}
		return new WP_Error( 'hablab_unauthorized', 'Missing or invalid device token.', array( 'status' => 401 ) );
	}

	public function login( WP_REST_Request $req ) {
		$pass  = (string) $req->get_param( 'passphrase' );
		$label = (string) $req->get_param( 'label' );
		$token = Hablab_Auth::login( $pass, $label );
		if ( is_wp_error( $token ) ) {
			return $token;
		}
		return array( 'token' => $token );
	}

	public function devices() {
		return array( 'devices' => Hablab_Auth::list_devices() );
	}

	public function revoke_device( WP_REST_Request $req ) {
		Hablab_Auth::revoke_device( $req['id'] );
		return array( 'ok' => true );
	}

	public function get_settings() {
		return Hablab_DB::all_settings();
	}

	/** Body: {"key": <settings key>, "value": <json>} or a flat object of keys. */
	public function put_settings( WP_REST_Request $req ) {
		$body = $req->get_json_params();
		if ( ! is_array( $body ) ) {
			return new WP_Error( 'hablab_bad_request', 'Expected a JSON object.', array( 'status' => 400 ) );
		}
		$allowed = array( 'theme_tokens', 'line_weights', 'last_view', 'habit_max' );
		foreach ( $body as $key => $value ) {
			if ( in_array( $key, $allowed, true ) ) {
				Hablab_DB::put_setting( $key, $value );
			}
		}
		return Hablab_DB::all_settings();
	}

	/* ---- Habits (P2) ---- */

	private function habit_fields( WP_REST_Request $req, $for_update = false ) {
		$out = array();
		$map = array( 'full_name' => 'sanitize_text_field', 'badge' => 'sanitize_text_field', 'icon' => 'sanitize_text_field' );
		foreach ( $map as $field => $fn ) {
			$val = $req->get_param( $field );
			if ( null !== $val || ( $for_update && $req->has_param( $field ) ) ) {
				$out[ $field ] = ( 'icon' === $field && ( null === $val || '' === $val ) ) ? null : call_user_func( $fn, (string) $val );
			}
		}
		if ( null !== $req->get_param( 'sort' ) ) {
			$out['sort'] = (int) $req->get_param( 'sort' );
		}
		if ( null !== $req->get_param( 'active' ) ) {
			$out['active'] = (int) (bool) $req->get_param( 'active' );
		}
		if ( isset( $out['badge'] ) ) {
			$out['badge'] = mb_substr( $out['badge'], 0, 12 );
		}
		return $out;
	}

	public function create_habit( WP_REST_Request $req ) {
		global $wpdb;
		$table  = Hablab_DB::table( 'habits' );
		$fields = $this->habit_fields( $req );
		if ( empty( $fields['full_name'] ) && empty( $fields['icon'] ) ) {
			return new WP_Error( 'hablab_bad_request', 'A habit needs a name or an icon.', array( 'status' => 400 ) );
		}
		$max = (int) Hablab_DB::get_setting( 'habit_max' );
		$n   = (int) $wpdb->get_var( "SELECT COUNT(*) FROM $table WHERE active = 1 AND ends_on IS NULL" );
		if ( $max && $n >= $max ) {
			return new WP_Error( 'hablab_full', 'Habit column limit reached.', array( 'status' => 409 ) );
		}
		if ( ! isset( $fields['sort'] ) ) {
			$fields['sort'] = 1 + (int) $wpdb->get_var( "SELECT COALESCE(MAX(sort), -1) FROM $table WHERE active = 1 AND ends_on IS NULL" );
		}
		if ( ! isset( $fields['full_name'] ) ) {
			$fields['full_name'] = ''; // schema requires it; icon-only habits have no name
		}
		// A habit exists from the day it was added — never in earlier months,
		// and stats only score it from this date (§ user feedback).
		$fields['starts_on']  = current_time( 'Y-m-d' );
		$fields['updated_at'] = current_time( 'mysql', true );
		if ( false === $wpdb->insert( $table, $fields ) || ! $wpdb->insert_id ) {
			return new WP_Error( 'hablab_db', 'Insert failed: ' . $wpdb->last_error, array( 'status' => 500 ) );
		}
		return $wpdb->get_row( $wpdb->prepare( "SELECT * FROM $table WHERE id = %d", $wpdb->insert_id ), ARRAY_A );
	}

	public function update_habit( WP_REST_Request $req ) {
		global $wpdb;
		$table  = Hablab_DB::table( 'habits' );
		$fields = $this->habit_fields( $req, true );
		if ( $fields ) {
			$fields['updated_at'] = current_time( 'mysql', true );
			$wpdb->update( $table, $fields, array( 'id' => (int) $req['id'] ) );
		}
		return $wpdb->get_row( $wpdb->prepare( "SELECT * FROM $table WHERE id = %d", (int) $req['id'] ), ARRAY_A );
	}

	/** Removal = end date, not deletion: gone from future months, past months
	 *  (including the rest of the current one) keep their history. */
	public function delete_habit( WP_REST_Request $req ) {
		global $wpdb;
		$wpdb->update( Hablab_DB::table( 'habits' ), array(
			'ends_on'    => current_time( 'Y-m-d' ),
			'updated_at' => current_time( 'mysql', true ),
		), array( 'id' => (int) $req['id'] ) );
		return array( 'ok' => true );
	}

	public function put_habit_entry( WP_REST_Request $req ) {
		$date     = $this->sanitize_date( $req->get_param( 'date' ) );
		$habit_id = (int) $req->get_param( 'habit_id' );
		if ( ! $date || ! $habit_id ) {
			return new WP_Error( 'hablab_bad_request', 'date (YYYY-MM-DD) and habit_id are required.', array( 'status' => 400 ) );
		}
		global $wpdb;
		$exists = $wpdb->get_var( $wpdb->prepare(
			'SELECT id FROM ' . Hablab_DB::table( 'habits' ) . ' WHERE id = %d', $habit_id
		) );
		if ( ! $exists ) {
			return new WP_Error( 'hablab_not_found', 'Unknown habit.', array( 'status' => 404 ) );
		}
		$ok = $wpdb->query( $wpdb->prepare(
			'INSERT INTO ' . Hablab_DB::table( 'habit_entries' ) . ' (entry_date, habit_id, done, updated_at) VALUES (%s, %d, %d, %s)
			 ON DUPLICATE KEY UPDATE done = VALUES(done), updated_at = VALUES(updated_at)',
			$date, $habit_id, (int) (bool) $req->get_param( 'done' ), current_time( 'mysql', true )
		) );
		if ( false === $ok ) {
			return new WP_Error( 'hablab_db', 'Write failed: ' . $wpdb->last_error, array( 'status' => 500 ) );
		}
		return array( 'ok' => true );
	}

	public function put_weight( WP_REST_Request $req ) {
		$date = $this->sanitize_date( $req->get_param( 'date' ) );
		if ( ! $date ) {
			return new WP_Error( 'hablab_bad_request', 'date (YYYY-MM-DD) is required.', array( 'status' => 400 ) );
		}
		global $wpdb;
		$table = Hablab_DB::table( 'weight_entries' );
		$lbs   = $req->get_param( 'lbs' );
		if ( null === $lbs || '' === $lbs ) {
			$wpdb->delete( $table, array( 'entry_date' => $date ) );
			return array( 'ok' => true, 'deleted' => true );
		}
		if ( ! is_numeric( $lbs ) ) {
			return new WP_Error( 'hablab_bad_request', 'lbs must be a number.', array( 'status' => 400 ) );
		}
		$ok = $wpdb->query( $wpdb->prepare(
			"INSERT INTO $table (entry_date, lbs, updated_at) VALUES (%s, %f, %s)
			 ON DUPLICATE KEY UPDATE lbs = VALUES(lbs), updated_at = VALUES(updated_at)",
			$date, (float) $lbs, current_time( 'mysql', true )
		) );
		if ( false === $ok ) {
			return new WP_Error( 'hablab_db', 'Write failed: ' . $wpdb->last_error, array( 'status' => 500 ) );
		}
		return array( 'ok' => true );
	}

	private function sanitize_date( $date ) {
		$date = (string) $date;
		if ( ! preg_match( '/^\d{4}-\d{2}-\d{2}$/', $date ) ) {
			return null;
		}
		return wp_checkdate( (int) substr( $date, 5, 2 ), (int) substr( $date, 8, 2 ), (int) substr( $date, 0, 4 ), $date ) ? $date : null;
	}

	/* ---- Time-block categories + entries (P3) ---- */

	private function category_fields( WP_REST_Request $req, $for_update = false ) {
		$out = array();
		foreach ( array( 'label', 'badge', 'icon' ) as $field ) {
			$val = $req->get_param( $field );
			if ( null !== $val || ( $for_update && $req->has_param( $field ) ) ) {
				$clean = sanitize_text_field( (string) $val );
				$out[ $field ] = ( 'icon' === $field && '' === $clean ) ? null : $clean;
			}
		}
		if ( isset( $out['badge'] ) ) {
			$out['badge'] = mb_substr( $out['badge'], 0, 12 );
		}
		if ( null !== $req->get_param( 'capacity' ) ) {
			$out['capacity'] = max( 1, min( 48, (int) $req->get_param( 'capacity' ) ) );
		}
		if ( null !== $req->get_param( 'sort' ) ) {
			$out['sort'] = (int) $req->get_param( 'sort' );
		}
		if ( null !== $req->get_param( 'active' ) ) {
			$out['active'] = (int) (bool) $req->get_param( 'active' );
		}
		return $out;
	}

	public function create_category( WP_REST_Request $req ) {
		global $wpdb;
		$table  = Hablab_DB::table( 'timeblock_categories' );
		$fields = $this->category_fields( $req );
		if ( ! isset( $fields['sort'] ) ) {
			$fields['sort'] = 1 + (int) $wpdb->get_var( "SELECT COALESCE(MAX(sort), -1) FROM $table WHERE active = 1" );
		}
		$fields += array( 'label' => '', 'badge' => '', 'capacity' => 6 );
		$fields['updated_at'] = current_time( 'mysql', true );
		if ( false === $wpdb->insert( $table, $fields ) || ! $wpdb->insert_id ) {
			return new WP_Error( 'hablab_db', 'Insert failed: ' . $wpdb->last_error, array( 'status' => 500 ) );
		}
		return $wpdb->get_row( $wpdb->prepare( "SELECT * FROM $table WHERE id = %d", $wpdb->insert_id ), ARRAY_A );
	}

	public function update_category( WP_REST_Request $req ) {
		global $wpdb;
		$table  = Hablab_DB::table( 'timeblock_categories' );
		$fields = $this->category_fields( $req, true );
		if ( $fields ) {
			$fields['updated_at'] = current_time( 'mysql', true );
			$wpdb->update( $table, $fields, array( 'id' => (int) $req['id'] ) );
		}
		return $wpdb->get_row( $wpdb->prepare( "SELECT * FROM $table WHERE id = %d", (int) $req['id'] ), ARRAY_A );
	}

	public function delete_category( WP_REST_Request $req ) {
		global $wpdb;
		$wpdb->update( Hablab_DB::table( 'timeblock_categories' ), array( 'active' => 0, 'updated_at' => current_time( 'mysql', true ) ), array( 'id' => (int) $req['id'] ) );
		return array( 'ok' => true );
	}

	public function put_timeblock_entry( WP_REST_Request $req ) {
		$date   = $this->sanitize_date( $req->get_param( 'date' ) );
		$cat_id = (int) $req->get_param( 'category_id' );
		if ( ! $date || ! $cat_id ) {
			return new WP_Error( 'hablab_bad_request', 'date (YYYY-MM-DD) and category_id are required.', array( 'status' => 400 ) );
		}
		global $wpdb;
		$capacity = $wpdb->get_var( $wpdb->prepare(
			'SELECT capacity FROM ' . Hablab_DB::table( 'timeblock_categories' ) . ' WHERE id = %d', $cat_id
		) );
		if ( null === $capacity ) {
			return new WP_Error( 'hablab_not_found', 'Unknown category.', array( 'status' => 404 ) );
		}
		// blocks_mask = which dots are filled (bit i = dot i+1); dots toggle
		// independently. blocks_filled is kept as the set-bit count so totals
		// and stats stay a plain SUM. Legacy clients sending only a cumulative
		// count get the equivalent "first n dots" mask.
		$mask = $req->get_param( 'blocks_mask' );
		if ( null === $mask ) {
			$mask = ( 1 << max( 0, min( (int) $capacity, (int) $req->get_param( 'blocks_filled' ) ) ) ) - 1;
		}
		$mask   = max( 0, (int) $mask ) & ( ( 1 << (int) $capacity ) - 1 );
		$blocks = 0;
		for ( $m = $mask; $m > 0; $m >>= 1 ) {
			$blocks += $m & 1;
		}
		$ok = $wpdb->query( $wpdb->prepare(
			'INSERT INTO ' . Hablab_DB::table( 'timeblock_entries' ) . ' (entry_date, category_id, blocks_filled, blocks_mask, updated_at) VALUES (%s, %d, %d, %d, %s)
			 ON DUPLICATE KEY UPDATE blocks_filled = VALUES(blocks_filled), blocks_mask = VALUES(blocks_mask), updated_at = VALUES(updated_at)',
			$date, $cat_id, $blocks, $mask, current_time( 'mysql', true )
		) );
		if ( false === $ok ) {
			return new WP_Error( 'hablab_db', 'Write failed: ' . $wpdb->last_error, array( 'status' => 500 ) );
		}
		return array( 'ok' => true, 'blocks_filled' => $blocks, 'blocks_mask' => $mask );
	}

	/* ---- Music: songs, run-through trackers, playthrough events (P4) ---- */

	public function create_song( WP_REST_Request $req ) {
		$title = sanitize_text_field( (string) $req->get_param( 'title' ) );
		if ( '' === $title ) {
			return new WP_Error( 'hablab_bad_request', 'A song needs a title.', array( 'status' => 400 ) );
		}
		global $wpdb;
		$table = Hablab_DB::table( 'songs' );
		$sort  = 1 + (int) $wpdb->get_var( "SELECT COALESCE(MAX(sort), -1) FROM $table" );
		if ( false === $wpdb->insert( $table, array( 'title' => $title, 'sort' => $sort, 'created_at' => current_time( 'Y-m-d' ), 'updated_at' => current_time( 'mysql', true ) ) ) || ! $wpdb->insert_id ) {
			return new WP_Error( 'hablab_db', 'Insert failed: ' . $wpdb->last_error, array( 'status' => 500 ) );
		}
		return $wpdb->get_row( $wpdb->prepare( "SELECT * FROM $table WHERE id = %d", $wpdb->insert_id ), ARRAY_A );
	}

	public function update_song( WP_REST_Request $req ) {
		global $wpdb;
		$table  = Hablab_DB::table( 'songs' );
		$fields = array();
		if ( null !== $req->get_param( 'title' ) ) {
			$title = sanitize_text_field( (string) $req->get_param( 'title' ) );
			if ( '' === $title ) {
				return new WP_Error( 'hablab_bad_request', 'A song needs a title.', array( 'status' => 400 ) );
			}
			$fields['title'] = $title;
		}
		if ( null !== $req->get_param( 'sort' ) ) {
			$fields['sort'] = (int) $req->get_param( 'sort' );
		}
		if ( $fields ) {
			$fields['updated_at'] = current_time( 'mysql', true );
			$wpdb->update( $table, $fields, array( 'id' => (int) $req['id'] ) );
		}
		return $wpdb->get_row( $wpdb->prepare( "SELECT * FROM $table WHERE id = %d", (int) $req['id'] ), ARRAY_A );
	}

	/** Hard delete, cascading to trackers and their events. */
	public function delete_song( WP_REST_Request $req ) {
		global $wpdb;
		$song_id  = (int) $req['id'];
		$trackers = Hablab_DB::table( 'song_trackers' );
		$events   = Hablab_DB::table( 'playthrough_events' );
		$ids      = $wpdb->get_col( $wpdb->prepare( "SELECT id FROM $trackers WHERE song_id = %d", $song_id ) );
		if ( $ids ) {
			$in = implode( ',', array_map( 'intval', $ids ) );
			if ( false === $wpdb->query( "DELETE FROM $events WHERE tracker_id IN ($in)" )
				|| false === $wpdb->query( "DELETE FROM $trackers WHERE song_id = " . $song_id ) ) {
				return new WP_Error( 'hablab_db', 'Delete failed: ' . $wpdb->last_error, array( 'status' => 500 ) );
			}
		}
		if ( false === $wpdb->delete( Hablab_DB::table( 'songs' ), array( 'id' => $song_id ) ) ) {
			return new WP_Error( 'hablab_db', 'Delete failed: ' . $wpdb->last_error, array( 'status' => 500 ) );
		}
		return array( 'ok' => true );
	}

	public function create_tracker( WP_REST_Request $req ) {
		global $wpdb;
		$song_id = (int) $req['id'];
		if ( ! $wpdb->get_var( $wpdb->prepare( 'SELECT id FROM ' . Hablab_DB::table( 'songs' ) . ' WHERE id = %d', $song_id ) ) ) {
			return new WP_Error( 'hablab_not_found', 'Unknown song.', array( 'status' => 404 ) );
		}
		$instrument_id = (int) $req->get_param( 'instrument_id' ) ?: null;
		if ( $instrument_id && ! $wpdb->get_var( $wpdb->prepare( 'SELECT id FROM ' . Hablab_DB::table( 'instruments' ) . ' WHERE id = %d', $instrument_id ) ) ) {
			return new WP_Error( 'hablab_not_found', 'Unknown instrument.', array( 'status' => 404 ) );
		}
		$table = Hablab_DB::table( 'song_trackers' );
		$sort  = 1 + (int) $wpdb->get_var( $wpdb->prepare( "SELECT COALESCE(MAX(sort), -1) FROM $table WHERE song_id = %d", $song_id ) );
		$row   = array(
			'song_id'       => $song_id,
			'instrument_id' => $instrument_id,
			'descriptor'    => sanitize_text_field( (string) $req->get_param( 'descriptor' ) ),
			'sort'          => $sort,
			'updated_at'    => current_time( 'mysql', true ),
		);
		if ( false === $wpdb->insert( $table, $row ) || ! $wpdb->insert_id ) {
			return new WP_Error( 'hablab_db', 'Insert failed: ' . $wpdb->last_error, array( 'status' => 500 ) );
		}
		$out          = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM $table WHERE id = %d", $wpdb->insert_id ), ARRAY_A );
		$out['count'] = 0;
		return $out;
	}

	public function update_tracker( WP_REST_Request $req ) {
		global $wpdb;
		$table  = Hablab_DB::table( 'song_trackers' );
		$fields = array();
		if ( null !== $req->get_param( 'descriptor' ) ) {
			$fields['descriptor'] = sanitize_text_field( (string) $req->get_param( 'descriptor' ) );
		}
		if ( $req->has_param( 'instrument_id' ) ) {
			$instrument_id = (int) $req->get_param( 'instrument_id' ) ?: null;
			if ( $instrument_id && ! $wpdb->get_var( $wpdb->prepare( 'SELECT id FROM ' . Hablab_DB::table( 'instruments' ) . ' WHERE id = %d', $instrument_id ) ) ) {
				return new WP_Error( 'hablab_not_found', 'Unknown instrument.', array( 'status' => 404 ) );
			}
			$fields['instrument_id'] = $instrument_id;
		}
		if ( $fields ) {
			$fields['updated_at'] = current_time( 'mysql', true );
			$wpdb->update( $table, $fields, array( 'id' => (int) $req['id'] ) );
		}
		return $wpdb->get_row( $wpdb->prepare( "SELECT * FROM $table WHERE id = %d", (int) $req['id'] ), ARRAY_A );
	}

	public function delete_tracker( WP_REST_Request $req ) {
		global $wpdb;
		if ( false === $wpdb->delete( Hablab_DB::table( 'playthrough_events' ), array( 'tracker_id' => (int) $req['id'] ) )
			|| false === $wpdb->delete( Hablab_DB::table( 'song_trackers' ), array( 'id' => (int) $req['id'] ) ) ) {
			return new WP_Error( 'hablab_db', 'Delete failed: ' . $wpdb->last_error, array( 'status' => 500 ) );
		}
		return array( 'ok' => true );
	}

	private function tracker_count( $tracker_id ) {
		global $wpdb;
		return (int) $wpdb->get_var( $wpdb->prepare(
			'SELECT COUNT(*) FROM ' . Hablab_DB::table( 'playthrough_events' ) . ' WHERE tracker_id = %d', $tracker_id
		) );
	}

	/** +1: one timestamped event per play-through (§6.2). */
	public function add_playthrough( WP_REST_Request $req ) {
		global $wpdb;
		$tracker_id = (int) $req['id'];
		if ( ! $wpdb->get_var( $wpdb->prepare( 'SELECT id FROM ' . Hablab_DB::table( 'song_trackers' ) . ' WHERE id = %d', $tracker_id ) ) ) {
			return new WP_Error( 'hablab_not_found', 'Unknown tracker.', array( 'status' => 404 ) );
		}
		if ( false === $wpdb->insert( Hablab_DB::table( 'playthrough_events' ), array(
			'tracker_id' => $tracker_id,
			'created_at' => current_time( 'mysql', true ),
		) ) ) {
			return new WP_Error( 'hablab_db', 'Write failed: ' . $wpdb->last_error, array( 'status' => 500 ) );
		}
		return array( 'ok' => true, 'count' => $this->tracker_count( $tracker_id ) );
	}

	/** −1: correction only — removes the most recent event. */
	public function remove_playthrough( WP_REST_Request $req ) {
		global $wpdb;
		$tracker_id = (int) $req['id'];
		$events     = Hablab_DB::table( 'playthrough_events' );
		$latest     = $wpdb->get_var( $wpdb->prepare(
			"SELECT id FROM $events WHERE tracker_id = %d ORDER BY id DESC LIMIT 1", $tracker_id
		) );
		if ( $latest ) {
			$wpdb->delete( $events, array( 'id' => (int) $latest ) );
		}
		return array( 'ok' => true, 'count' => $this->tracker_count( $tracker_id ) );
	}

	/** "Other" instruments are permanent additions (§6.1). Idempotent by name. */
	public function create_instrument( WP_REST_Request $req ) {
		$name = sanitize_text_field( (string) $req->get_param( 'name' ) );
		if ( '' === $name ) {
			return new WP_Error( 'hablab_bad_request', 'An instrument needs a name.', array( 'status' => 400 ) );
		}
		global $wpdb;
		$table    = Hablab_DB::table( 'instruments' );
		$existing = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM $table WHERE name = %s", $name ), ARRAY_A );
		if ( $existing ) {
			return $existing;
		}
		$sort = 1 + (int) $wpdb->get_var( "SELECT COALESCE(MAX(sort), -1) FROM $table" );
		if ( false === $wpdb->insert( $table, array( 'name' => $name, 'sort' => $sort ) ) || ! $wpdb->insert_id ) {
			// Lost a same-name race against the UNIQUE key? Idempotent: return the winner.
			$racer = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM $table WHERE name = %s", $name ), ARRAY_A );
			if ( $racer ) {
				return $racer;
			}
			return new WP_Error( 'hablab_db', 'Insert failed: ' . $wpdb->last_error, array( 'status' => 500 ) );
		}
		return $wpdb->get_row( $wpdb->prepare( "SELECT * FROM $table WHERE id = %d", $wpdb->insert_id ), ARRAY_A );
	}

	/* ---- Exercise log ---- */

	/** Master exercise list additions are permanent; idempotent by name. */
	public function create_exercise( WP_REST_Request $req ) {
		$name = sanitize_text_field( (string) $req->get_param( 'name' ) );
		if ( '' === $name ) {
			return new WP_Error( 'hablab_bad_request', 'An exercise needs a name.', array( 'status' => 400 ) );
		}
		global $wpdb;
		$table    = Hablab_DB::table( 'exercises' );
		$existing = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM $table WHERE name = %s", $name ), ARRAY_A );
		if ( $existing ) {
			if ( ! (int) $existing['active'] ) {
				$wpdb->update( $table, array( 'active' => 1 ), array( 'id' => $existing['id'] ) );
				$existing['active'] = 1;
			}
			return $existing;
		}
		$sort = 1 + (int) $wpdb->get_var( "SELECT COALESCE(MAX(sort), -1) FROM $table" );
		if ( false === $wpdb->insert( $table, array( 'name' => $name, 'sort' => $sort ) ) || ! $wpdb->insert_id ) {
			$racer = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM $table WHERE name = %s", $name ), ARRAY_A );
			if ( $racer ) {
				return $racer;
			}
			return new WP_Error( 'hablab_db', 'Insert failed: ' . $wpdb->last_error, array( 'status' => 500 ) );
		}
		return $wpdb->get_row( $wpdb->prepare( "SELECT * FROM $table WHERE id = %d", $wpdb->insert_id ), ARRAY_A );
	}

	public function update_exercise( WP_REST_Request $req ) {
		global $wpdb;
		$table  = Hablab_DB::table( 'exercises' );
		$fields = array();
		if ( null !== $req->get_param( 'name' ) ) {
			$name = sanitize_text_field( (string) $req->get_param( 'name' ) );
			if ( '' === $name ) {
				return new WP_Error( 'hablab_bad_request', 'An exercise needs a name.', array( 'status' => 400 ) );
			}
			$fields['name'] = $name;
		}
		if ( null !== $req->get_param( 'active' ) ) {
			$fields['active'] = (int) (bool) $req->get_param( 'active' );
		}
		if ( null !== $req->get_param( 'sort' ) ) {
			$fields['sort'] = (int) $req->get_param( 'sort' );
		}
		if ( $fields ) {
			$wpdb->update( $table, $fields, array( 'id' => (int) $req['id'] ) );
		}
		return $wpdb->get_row( $wpdb->prepare( "SELECT * FROM $table WHERE id = %d", (int) $req['id'] ), ARRAY_A );
	}

	/** Upsert one workout row: insert without id, update with id. */
	public function put_workout_row( WP_REST_Request $req ) {
		$date = $this->sanitize_date( $req->get_param( 'date' ) );
		if ( ! $date ) {
			return new WP_Error( 'hablab_bad_request', 'date (YYYY-MM-DD) is required.', array( 'status' => 400 ) );
		}
		global $wpdb;
		$table       = Hablab_DB::table( 'workout_rows' );
		$exercise_id = (int) $req->get_param( 'exercise_id' ) ?: null;
		if ( $exercise_id && ! $wpdb->get_var( $wpdb->prepare( 'SELECT id FROM ' . Hablab_DB::table( 'exercises' ) . ' WHERE id = %d', $exercise_id ) ) ) {
			return new WP_Error( 'hablab_not_found', 'Unknown exercise.', array( 'status' => 404 ) );
		}
		$data = $req->get_param( 'data' );
		$row  = array(
			'entry_date'  => $date,
			'sort'        => (int) $req->get_param( 'sort' ),
			'exercise_id' => $exercise_id,
			'data'        => wp_json_encode( is_array( $data ) ? $data : array() ),
			'updated_at'  => current_time( 'mysql', true ),
		);
		$id = (int) $req->get_param( 'id' );
		if ( $id ) {
			if ( false === $wpdb->update( $table, $row, array( 'id' => $id ) ) ) {
				return new WP_Error( 'hablab_db', 'Write failed: ' . $wpdb->last_error, array( 'status' => 500 ) );
			}
		} else {
			if ( false === $wpdb->insert( $table, $row ) || ! $wpdb->insert_id ) {
				return new WP_Error( 'hablab_db', 'Insert failed: ' . $wpdb->last_error, array( 'status' => 500 ) );
			}
			$id = $wpdb->insert_id;
		}
		return $wpdb->get_row( $wpdb->prepare( "SELECT * FROM $table WHERE id = %d", $id ), ARRAY_A );
	}

	public function delete_workout_row( WP_REST_Request $req ) {
		global $wpdb;
		if ( false === $wpdb->delete( Hablab_DB::table( 'workout_rows' ), array( 'id' => (int) $req['id'] ) ) ) {
			return new WP_Error( 'hablab_db', 'Delete failed: ' . $wpdb->last_error, array( 'status' => 500 ) );
		}
		return array( 'ok' => true );
	}

	/* ---- Backups (P7) ---- */

	public function export() {
		return Hablab_Backups::export_data();
	}

	public function import( WP_REST_Request $req ) {
		$result = Hablab_Backups::import_data( $req->get_json_params() );
		if ( is_wp_error( $result ) ) {
			return $result;
		}
		return array( 'ok' => true );
	}

	public function backups() {
		return array(
			'dir'     => 'wp-content/uploads/hablab-backups/',
			'backups' => Hablab_Backups::list_backups(),
		);
	}

	/* ---- Analytics (P5): the bits that need history beyond one month ---- */

	public function analytics() {
		global $wpdb;
		$weights = $wpdb->get_results(
			'SELECT entry_date, lbs FROM ' . Hablab_DB::table( 'weight_entries' ) . ' ORDER BY entry_date', ARRAY_A
		);
		$events = $wpdb->get_results(
			'SELECT tracker_id, created_at FROM ' . Hablab_DB::table( 'playthrough_events' ) . ' ORDER BY created_at', ARRAY_A
		);

		// Streaks per habit across all history (consecutive done-days).
		$streaks = array();
		$today   = current_time( 'Y-m-d' );
		$rows    = $wpdb->get_results(
			'SELECT habit_id, entry_date FROM ' . Hablab_DB::table( 'habit_entries' ) . ' WHERE done = 1 ORDER BY habit_id, entry_date', ARRAY_A
		);
		$by_habit = array();
		foreach ( (array) $rows as $r ) {
			$by_habit[ (int) $r['habit_id'] ][] = $r['entry_date'];
		}
		foreach ( $by_habit as $habit_id => $dates ) {
			$longest = 0;
			$run     = 0;
			$prev    = null;
			foreach ( $dates as $d ) {
				$run  = ( $prev && gmdate( 'Y-m-d', strtotime( $prev . ' +1 day' ) ) === $d ) ? $run + 1 : 1;
				$prev = $d;
				if ( $run > $longest ) {
					$longest = $run;
				}
			}
			// Current streak only counts if the run reaches today or yesterday.
			$last    = end( $dates );
			$current = ( $last === $today || gmdate( 'Y-m-d', strtotime( $last . ' +1 day' ) ) === $today ) ? $run : 0;
			$streaks[ $habit_id ] = array( 'current' => $current, 'longest' => $longest );
		}

		// Daily habit completion across all history — powers the perfect-day
		// streak and the weight↔habit correlation.
		$habs = $wpdb->get_results(
			'SELECT id, starts_on, ends_on FROM ' . Hablab_DB::table( 'habits' ) . ' WHERE active = 1', ARRAY_A
		);
		$done_by_date = array();
		foreach ( (array) $rows as $r ) { // $rows = done entries from the streak pass above
			$done_by_date[ $r['entry_date'] ][ (int) $r['habit_id'] ] = true;
		}
		$daily = array();
		if ( $done_by_date ) {
			$dates = array_keys( $done_by_date );
			sort( $dates );
			$d = $dates[0];
			// Cap the walk at ~3 years so a stray ancient row can't loop forever.
			$guard = 1100;
			while ( $d <= $today && $guard-- > 0 ) {
				$active = 0;
				$done   = 0;
				foreach ( $habs as $h ) {
					$starts = $h['starts_on'];
					$ends   = $h['ends_on'];
					if ( ( ! $starts || $starts <= $d ) && ( ! $ends || $ends >= $d ) ) {
						$active++;
						if ( isset( $done_by_date[ $d ][ (int) $h['id'] ] ) ) {
							$done++;
						}
					}
				}
				if ( $active > 0 ) {
					$daily[] = array( 'date' => $d, 'done' => $done, 'active' => $active );
				}
				$d = gmdate( 'Y-m-d', strtotime( $d . ' +1 day' ) );
			}
		}

		// All time-block entries — powers records + week-over-week trend.
		$tb_all = $wpdb->get_results(
			'SELECT entry_date, category_id, blocks_filled FROM ' . Hablab_DB::table( 'timeblock_entries' ) . ' WHERE blocks_filled > 0 ORDER BY entry_date', ARRAY_A
		);

		return array(
			'weights'          => $weights,
			'playthroughs'     => $events,
			'streaks'          => (object) $streaks,
			'daily_completion' => $daily,
			'tb_all'           => $tb_all,
			'today'            => $today,
		);
	}

	/** Everything the app needs on open, in one round trip. */
	public function bootstrap( WP_REST_Request $req ) {
		$settings = Hablab_DB::all_settings();
		$month    = $req->get_param( 'month' );
		if ( ! $month && ! empty( $settings['last_view']['month'] ) ) {
			$month = $settings['last_view']['month'];
		}
		$month = $this->sanitize_month( $month );

		global $wpdb;
		$songs       = $wpdb->get_results( 'SELECT * FROM ' . Hablab_DB::table( 'songs' ) . ' ORDER BY sort, id', ARRAY_A );
		$instruments = $wpdb->get_results( 'SELECT * FROM ' . Hablab_DB::table( 'instruments' ) . ' ORDER BY sort, id', ARRAY_A );
		$exercises   = $wpdb->get_results( 'SELECT * FROM ' . Hablab_DB::table( 'exercises' ) . ' WHERE active = 1 ORDER BY sort, id', ARRAY_A );
		$trackers    = $wpdb->get_results(
			'SELECT t.*, CAST(COUNT(e.id) AS UNSIGNED) AS count FROM ' . Hablab_DB::table( 'song_trackers' ) . ' t
			 LEFT JOIN ' . Hablab_DB::table( 'playthrough_events' ) . ' e ON e.tracker_id = t.id
			 GROUP BY t.id ORDER BY t.sort, t.id', ARRAY_A );

		return array(
			'settings'      => $settings,
			'month'         => $this->month_payload( $month ),
			'songs'         => $songs,
			'instruments'   => $instruments,
			'exercises'     => $exercises,
			'song_trackers' => $trackers,
		);
	}

	public function month( WP_REST_Request $req ) {
		return $this->month_payload( $this->sanitize_month( $req->get_param( 'month' ) ) );
	}

	private function sanitize_month( $month ) {
		return preg_match( '/^\d{4}-\d{2}$/', (string) $month ) ? $month : gmdate( 'Y-m' );
	}

	private function month_payload( $month ) {
		global $wpdb;
		// Half-open date range [first of month, first of next month) — index-friendly.
		$start = $month . '-01';
		$end   = gmdate( 'Y-m-01', strtotime( $start . ' +1 month' ) );

		// Habits are month-scoped: born on starts_on, retired on ends_on.
		$habits = $wpdb->get_results( $wpdb->prepare(
			'SELECT * FROM ' . Hablab_DB::table( 'habits' ) . '
			 WHERE active = 1
			   AND (starts_on IS NULL OR starts_on < %s)
			   AND (ends_on IS NULL OR ends_on >= %s)
			 ORDER BY sort, id', $end, $start
		), ARRAY_A );
		$categories = $wpdb->get_results( 'SELECT * FROM ' . Hablab_DB::table( 'timeblock_categories' ) . ' WHERE active = 1 ORDER BY sort, id', ARRAY_A );
		$workouts   = $wpdb->get_results( $wpdb->prepare(
			'SELECT * FROM ' . Hablab_DB::table( 'workout_rows' ) . ' WHERE entry_date >= %s AND entry_date < %s ORDER BY entry_date, sort, id', $start, $end
		), ARRAY_A );

		$habit_entries = $wpdb->get_results( $wpdb->prepare(
			'SELECT entry_date, habit_id, done FROM ' . Hablab_DB::table( 'habit_entries' ) . ' WHERE entry_date >= %s AND entry_date < %s', $start, $end
		), ARRAY_A );
		$tb_entries = $wpdb->get_results( $wpdb->prepare(
			'SELECT entry_date, category_id, blocks_filled, blocks_mask FROM ' . Hablab_DB::table( 'timeblock_entries' ) . ' WHERE entry_date >= %s AND entry_date < %s', $start, $end
		), ARRAY_A );
		// Weight needs the last entry before the month too, so day 1's trend arrow can compute.
		$weights = $wpdb->get_results( $wpdb->prepare(
			'SELECT entry_date, lbs FROM ' . Hablab_DB::table( 'weight_entries' ) . ' WHERE entry_date >= %s AND entry_date < %s ORDER BY entry_date', $start, $end
		), ARRAY_A );
		$prev_weight = $wpdb->get_row( $wpdb->prepare(
			'SELECT entry_date, lbs FROM ' . Hablab_DB::table( 'weight_entries' ) . ' WHERE entry_date < %s ORDER BY entry_date DESC LIMIT 1', $month . '-01'
		), ARRAY_A );

		return array(
			'month'         => $month,
			'habits'        => $habits,
			'habit_entries' => $habit_entries,
			'categories'    => $categories,
			'tb_entries'    => $tb_entries,
			'weights'       => $weights,
			'prev_weight'   => $prev_weight,
			'workouts'      => $workouts,
		);
	}
}
