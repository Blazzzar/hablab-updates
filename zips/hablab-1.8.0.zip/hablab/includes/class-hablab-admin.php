<?php
defined( 'ABSPATH' ) || exit;

/**
 * Settings → HAB•LAB: set the passphrase, see and revoke devices,
 * configure staleness reminder emails.
 */
class Hablab_Admin {

	public static function init() {
		add_action( 'admin_menu', function () {
			add_options_page( 'HAB•LAB', 'HAB•LAB', 'manage_options', 'hablab', array( __CLASS__, 'render' ) );
		} );
		add_action( 'admin_post_hablab_passphrase', array( __CLASS__, 'save_passphrase' ) );
		add_action( 'admin_post_hablab_revoke', array( __CLASS__, 'revoke' ) );
		add_action( 'admin_post_hablab_reminders', array( __CLASS__, 'save_reminders' ) );
		add_action( 'admin_post_hablab_reminders_test', array( __CLASS__, 'send_reminder_test' ) );
		add_action( 'admin_post_hablab_reminders_preview', array( __CLASS__, 'preview_reminders' ) );
		add_action( 'admin_notices', function () {
			if ( current_user_can( 'manage_options' ) && ! get_option( 'permalink_structure' ) ) {
				echo '<div class="notice notice-error"><p><strong>HAB•LAB:</strong> pretty permalinks are required for the /hablab.html routes. Set any structure under Settings → Permalinks.</p></div>';
			}
		} );
	}

	public static function save_passphrase() {
		if ( ! current_user_can( 'manage_options' ) || ! check_admin_referer( 'hablab_passphrase' ) ) {
			wp_die( 'Not allowed' );
		}
		$pass = isset( $_POST['passphrase'] ) ? (string) wp_unslash( $_POST['passphrase'] ) : '';
		if ( strlen( $pass ) >= 8 ) {
			Hablab_Auth::set_passphrase( $pass );
			$msg = 'saved';
		} else {
			$msg = 'tooshort';
		}
		wp_safe_redirect( admin_url( 'options-general.php?page=hablab&msg=' . $msg ) );
		exit;
	}

	public static function revoke() {
		if ( ! current_user_can( 'manage_options' ) || ! check_admin_referer( 'hablab_revoke' ) ) {
			wp_die( 'Not allowed' );
		}
		Hablab_Auth::revoke_device( isset( $_POST['device_id'] ) ? (int) $_POST['device_id'] : 0 );
		wp_safe_redirect( admin_url( 'options-general.php?page=hablab&msg=revoked' ) );
		exit;
	}

	/** Sanitize + persist the whole reminders config from the settings form. */
	public static function save_reminders() {
		if ( ! current_user_can( 'manage_options' ) || ! check_admin_referer( 'hablab_reminders' ) ) {
			wp_die( 'Not allowed' );
		}
		$habits = Hablab_Reminders::habit_catalog();
		$blocks = Hablab_Reminders::timeblock_catalog();

		$recipient = isset( $_POST['reminders_recipient'] ) ? sanitize_email( wp_unslash( $_POST['reminders_recipient'] ) ) : '';
		if ( $recipient && ! is_email( $recipient ) ) {
			$recipient = '';
		}

		// Pass 1: sanitize rows (dropping rows that are entirely empty) and
		// claim every explicitly posted id, so generated ids can't collide.
		$raw   = ( isset( $_POST['rules'] ) && is_array( $_POST['rules'] ) ) ? wp_unslash( $_POST['rules'] ) : array();
		$rules = array();
		$used  = array();
		foreach ( $raw as $r ) {
			if ( ! is_array( $r ) ) {
				continue;
			}
			$type    = ( isset( $r['type'] ) && 'timeblock' === $r['type'] ) ? 'timeblock' : 'habit';
			$label   = isset( $r['label'] ) ? sanitize_text_field( $r['label'] ) : '';
			$src     = 'timeblock' === $type ? 'targets_timeblock' : 'targets_habit';
			$catalog = 'timeblock' === $type ? $blocks : $habits;
			$targets = array();
			if ( isset( $r[ $src ] ) && is_array( $r[ $src ] ) ) {
				foreach ( $r[ $src ] as $tid ) {
					$tid = (int) $tid;
					if ( $tid > 0 && isset( $catalog[ $tid ] ) && ! in_array( $tid, $targets, true ) ) {
						$targets[] = $tid;
					}
				}
			}
			if ( ! $targets && '' === $label ) {
				continue; // an untouched blank row
			}
			$id = isset( $r['id'] ) ? substr( preg_replace( '/[^a-z0-9_-]/', '', strtolower( (string) $r['id'] ) ), 0, 32 ) : '';
			if ( '' !== $id && ! isset( $used[ $id ] ) ) {
				$used[ $id ] = true;
			} else {
				$id = null; // assigned in pass 2
			}
			$rules[] = array(
				'id'             => $id,
				'label'          => $label,
				'type'           => $type,
				'targets'        => $targets,
				'threshold_days' => min( 365, max( 1, isset( $r['threshold_days'] ) ? (int) $r['threshold_days'] : 5 ) ),
				'cooldown_days'  => min( 365, max( 1, isset( $r['cooldown_days'] ) ? (int) $r['cooldown_days'] : 3 ) ),
				'enabled'        => ! empty( $r['enabled'] ),
			);
		}
		// Pass 2: give new rows the first free rN.
		foreach ( $rules as &$rule ) {
			if ( null === $rule['id'] ) {
				$n = 1;
				while ( isset( $used[ 'r' . $n ] ) ) {
					$n++;
				}
				$rule['id']          = 'r' . $n;
				$used[ $rule['id'] ] = true;
			}
		}
		unset( $rule );

		Hablab_DB::put_setting( Hablab_Reminders::SETTING_KEY, array(
			'enabled'   => ! empty( $_POST['reminders_enabled'] ),
			'recipient' => $recipient,
			'rules'     => $rules,
		) );

		// Drop send-state for rules that no longer exist, so a future rule
		// reusing the id doesn't inherit a stale cooldown.
		$state = Hablab_DB::get_setting( Hablab_Reminders::STATE_KEY );
		if ( is_array( $state ) ) {
			Hablab_DB::put_setting( Hablab_Reminders::STATE_KEY, array_intersect_key( $state, $used ) );
		}

		wp_safe_redirect( admin_url( 'options-general.php?page=hablab&msg=reminders_saved' ) );
		exit;
	}

	public static function send_reminder_test() {
		if ( ! current_user_can( 'manage_options' ) || ! check_admin_referer( 'hablab_reminders_test' ) ) {
			wp_die( 'Not allowed' );
		}
		$msg = Hablab_Reminders::send_test() ? 'testsent' : 'testfail';
		wp_safe_redirect( admin_url( 'options-general.php?page=hablab&msg=' . $msg ) );
		exit;
	}

	/** Dry-run via evaluate(); the result renders once in the Reminders section. */
	public static function preview_reminders() {
		if ( ! current_user_can( 'manage_options' ) || ! check_admin_referer( 'hablab_reminders_preview' ) ) {
			wp_die( 'Not allowed' );
		}
		set_transient( 'hablab_reminders_preview', Hablab_Reminders::evaluate(), MINUTE_IN_SECONDS );
		wp_safe_redirect( admin_url( 'options-general.php?page=hablab&msg=preview' ) );
		exit;
	}

	public static function render() {
		$msg = isset( $_GET['msg'] ) ? sanitize_key( $_GET['msg'] ) : '';
		?>
		<div class="wrap">
			<h1>HAB•LAB</h1>
			<?php if ( 'saved' === $msg ) : ?><div class="notice notice-success"><p>Passphrase saved.</p></div><?php endif; ?>
			<?php if ( 'tooshort' === $msg ) : ?><div class="notice notice-error"><p>Passphrase must be at least 8 characters.</p></div><?php endif; ?>
			<?php if ( 'revoked' === $msg ) : ?><div class="notice notice-success"><p>Device revoked.</p></div><?php endif; ?>
			<?php if ( 'reminders_saved' === $msg ) : ?><div class="notice notice-success"><p>Reminder settings saved.</p></div><?php endif; ?>
			<?php if ( 'testsent' === $msg ) : ?><div class="notice notice-success"><p>Test email sent to <?php echo esc_html( Hablab_Reminders::recipient() ); ?> — check the inbox (and spam).</p></div><?php endif; ?>
			<?php if ( 'testfail' === $msg ) : ?><div class="notice notice-error"><p><code>wp_mail()</code> reported a failure — check the server’s mail setup (WP Mail SMTP pointed at a transactional provider usually fixes this).</p></div><?php endif; ?>

			<p>
				App: <a href="<?php echo esc_url( home_url( '/hablab.html' ) ); ?>"><?php echo esc_html( home_url( '/hablab.html' ) ); ?></a>
				&nbsp;·&nbsp; Demo: <a href="<?php echo esc_url( home_url( '/hablab-demo.html' ) ); ?>"><?php echo esc_html( home_url( '/hablab-demo.html' ) ); ?></a>
			</p>

			<h2>Passphrase</h2>
			<p><?php echo Hablab_Auth::has_passphrase() ? 'A passphrase is set. Enter a new one to replace it.' : '<strong>No passphrase set yet — the app cannot be unlocked until you set one.</strong>'; ?></p>
			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
				<?php wp_nonce_field( 'hablab_passphrase' ); ?>
				<input type="hidden" name="action" value="hablab_passphrase">
				<input type="password" name="passphrase" minlength="8" required placeholder="New passphrase (min 8 chars)" style="min-width:280px">
				<button class="button button-primary">Save passphrase</button>
			</form>

			<h2>Backups</h2>
			<p>A JSON backup runs daily via WP-Cron into <code>wp-content/uploads/hablab-backups/</code>
			(direct web access blocked via .htaccess — on nginx, deny that path in the server config).
			Retention: newest <?php echo (int) Hablab_Backups::KEEP_DAILY; ?> dailies + first-of-month keepers for
			<?php echo (int) Hablab_Backups::KEEP_MONTHLY; ?> months. Manual export/import lives in the app’s settings sheet.</p>
			<?php $hablab_backups = Hablab_Backups::list_backups(); ?>
			<p><?php echo $hablab_backups ? esc_html( count( $hablab_backups ) . ' backup(s); latest: ' . $hablab_backups[0]['file'] ) : 'No backups yet (first run happens within a day of activation).'; ?></p>

			<h2>Devices</h2>
			<table class="widefat striped" style="max-width:700px">
				<thead><tr><th>Device</th><th>First login</th><th>Last seen</th><th></th></tr></thead>
				<tbody>
				<?php foreach ( Hablab_Auth::list_devices() as $d ) : ?>
					<tr>
						<td><?php echo esc_html( $d['label'] ); ?><?php echo $d['revoked'] ? ' <em>(revoked)</em>' : ''; ?></td>
						<td><?php echo esc_html( $d['created_at'] ); ?></td>
						<td><?php echo esc_html( $d['last_seen'] ); ?></td>
						<td>
							<?php if ( ! $d['revoked'] ) : ?>
							<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
								<?php wp_nonce_field( 'hablab_revoke' ); ?>
								<input type="hidden" name="action" value="hablab_revoke">
								<input type="hidden" name="device_id" value="<?php echo (int) $d['id']; ?>">
								<button class="button">Revoke</button>
							</form>
							<?php endif; ?>
						</td>
					</tr>
				<?php endforeach; ?>
				</tbody>
			</table>

			<h2>Reminders</h2>
			<p>Email a nudge when a watched habit or time-block hasn’t been checked off in a while —
			one plain-text digest per day at most, via <code>wp_mail()</code> (if nudges land in spam,
			install WP Mail SMTP pointed at a transactional provider; no code change needed).
			A target is only watched once it’s been completed at least once; inactive or ended
			items are never nudged. A rule with one target is an individual reminder; give it
			several targets to bundle them under one label.</p>

			<?php
			$hablab_rem      = Hablab_Reminders::get_config();
			$hablab_r_habits = array_filter( Hablab_Reminders::habit_catalog(), function ( $h ) {
				return ! empty( $h['active'] );
			} );
			$hablab_r_blocks = array_filter( Hablab_Reminders::timeblock_catalog(), function ( $b ) {
				return ! empty( $b['active'] );
			} );
			if ( 'preview' === $msg ) :
				$hablab_r_items = get_transient( 'hablab_reminders_preview' );
				delete_transient( 'hablab_reminders_preview' );
				?>
				<div class="notice notice-info inline" style="margin:0 0 12px;max-width:860px">
					<p><strong>Preview — what the next daily run would send:</strong></p>
					<?php if ( empty( $hablab_rem['enabled'] ) ) : ?>
						<p><em>Reminders are switched off, so no email would actually go out until you enable them below.</em></p>
					<?php endif; ?>
					<?php
					$hablab_r_due     = array();
					$hablab_r_cooling = array();
					foreach ( is_array( $hablab_r_items ) ? $hablab_r_items : array() as $it ) {
						if ( 'due' === $it['status'] ) {
							$hablab_r_due[] = $it;
						} else {
							$hablab_r_cooling[] = $it;
						}
					}
					if ( ! $hablab_r_due && ! $hablab_r_cooling ) : ?>
						<p>Nothing is stale right now.</p>
					<?php else : ?>
						<?php if ( $hablab_r_due ) : ?>
							<pre style="margin:0 0 8px;white-space:pre-wrap"><?php echo esc_html( Hablab_Reminders::digest_body( $hablab_r_due ) ); ?></pre>
						<?php else : ?>
							<p>Nothing due — everything stale is inside its cooldown.</p>
						<?php endif; ?>
						<?php if ( $hablab_r_cooling ) : ?>
							<p style="color:#646970"><em>Suppressed by cooldown:
							<?php
							$hablab_r_bits = array();
							foreach ( $hablab_r_cooling as $it ) {
								$hablab_r_bits[] = $it['name'] . ' (' . (int) $it['days_since'] . ' days stale)';
							}
							echo esc_html( implode( ', ', $hablab_r_bits ) );
							?></em></p>
						<?php endif; ?>
					<?php endif; ?>
				</div>
			<?php endif; ?>

			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
				<?php wp_nonce_field( 'hablab_reminders' ); ?>
				<input type="hidden" name="action" value="hablab_reminders">
				<p><label><input type="checkbox" name="reminders_enabled" <?php checked( ! empty( $hablab_rem['enabled'] ) ); ?>>
					<strong>Send daily reminder digests</strong></label></p>
				<p><label>Recipient:
					<input type="email" name="reminders_recipient" value="<?php echo esc_attr( $hablab_rem['recipient'] ); ?>"
						placeholder="<?php echo esc_attr( get_option( 'admin_email' ) ); ?>" style="min-width:280px"></label>
					<span class="description">Blank = the admin email above.</span></p>

				<table class="widefat striped" style="max-width:1000px">
					<thead><tr>
						<th style="width:32px">On</th><th>Label</th><th style="width:110px">Type</th><th>Targets</th>
						<th style="width:100px">Nudge after<br>(days stale)</th><th style="width:100px">Cooldown<br>(days)</th><th style="width:60px"></th>
					</tr></thead>
					<tbody id="hablab-rules-body">
					<?php foreach ( array_values( $hablab_rem['rules'] ) as $hablab_r_i => $hablab_r_rule ) : ?>
						<?php self::reminder_rule_row( $hablab_r_i, $hablab_r_rule, $hablab_r_habits, $hablab_r_blocks ); ?>
					<?php endforeach; ?>
					</tbody>
				</table>
				<p>
					<button type="button" class="button" id="hablab-add-rule">Add rule</button>
					<button class="button button-primary">Save reminders</button>
				</p>
			</form>
			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="display:inline-block;margin-right:8px">
				<?php wp_nonce_field( 'hablab_reminders_test' ); ?>
				<input type="hidden" name="action" value="hablab_reminders_test">
				<button class="button">Send test email</button>
			</form>
			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="display:inline-block">
				<?php wp_nonce_field( 'hablab_reminders_preview' ); ?>
				<input type="hidden" name="action" value="hablab_reminders_preview">
				<button class="button">Preview what’s due now</button>
			</form>

			<template id="hablab-rule-template">
				<?php self::reminder_rule_row( '__INDEX__', array(), $hablab_r_habits, $hablab_r_blocks ); ?>
			</template>
			<script>
			( function () {
				var body = document.getElementById( 'hablab-rules-body' );
				var tpl  = document.getElementById( 'hablab-rule-template' );
				var add  = document.getElementById( 'hablab-add-rule' );
				if ( ! body || ! tpl || ! add ) {
					return;
				}
				var next = <?php echo (int) count( $hablab_rem['rules'] ); ?>;
				add.addEventListener( 'click', function () {
					var holder = document.createElement( 'tbody' );
					holder.innerHTML = tpl.innerHTML.replace( /__INDEX__/g, 'new' + ( next++ ) );
					while ( holder.firstElementChild ) {
						body.appendChild( holder.firstElementChild );
					}
				} );
				body.addEventListener( 'click', function ( e ) {
					var btn = e.target.closest( '.hablab-remove-rule' );
					if ( btn ) {
						btn.closest( 'tr' ).remove();
					}
				} );
				body.addEventListener( 'change', function ( e ) {
					if ( ! e.target.classList.contains( 'hablab-rule-type' ) ) {
						return;
					}
					var tr = e.target.closest( 'tr' );
					var tb = 'timeblock' === e.target.value;
					tr.querySelector( '.hablab-targets-habit' ).style.display    = tb ? 'none' : '';
					tr.querySelector( '.hablab-targets-timeblock' ).style.display = tb ? '' : 'none';
				} );
			} )();
			</script>
		</div>
		<?php
	}

	/** One <tr> of the reminder-rules editor ($i = '__INDEX__' inside the add-rule template). */
	private static function reminder_rule_row( $i, $rule, $habits, $blocks ) {
		$rule += array(
			'id'             => '',
			'label'          => '',
			'type'           => 'habit',
			'targets'        => array(),
			'threshold_days' => 5,
			'cooldown_days'  => 3,
			'enabled'        => true,
		);
		$type    = 'timeblock' === $rule['type'] ? 'timeblock' : 'habit';
		$targets = array_map( 'intval', (array) $rule['targets'] );
		$name    = 'rules[' . $i . ']';
		?>
		<tr>
			<td><input type="checkbox" name="<?php echo esc_attr( $name ); ?>[enabled]" <?php checked( ! empty( $rule['enabled'] ) ); ?>>
				<input type="hidden" name="<?php echo esc_attr( $name ); ?>[id]" value="<?php echo esc_attr( $rule['id'] ); ?>"></td>
			<td><input type="text" name="<?php echo esc_attr( $name ); ?>[label]" value="<?php echo esc_attr( $rule['label'] ); ?>"
				placeholder="e.g. Core morning habits" style="width:100%"></td>
			<td><select name="<?php echo esc_attr( $name ); ?>[type]" class="hablab-rule-type">
				<option value="habit" <?php selected( 'habit' === $type ); ?>>Habit</option>
				<option value="timeblock" <?php selected( 'timeblock' === $type ); ?>>Time-block</option>
			</select></td>
			<td>
				<select name="<?php echo esc_attr( $name ); ?>[targets_habit][]" multiple size="4"
					class="hablab-targets-habit" style="width:100%;<?php echo 'habit' === $type ? '' : 'display:none'; ?>">
					<?php foreach ( $habits as $h ) : ?>
						<option value="<?php echo (int) $h['id']; ?>" <?php selected( 'habit' === $type && in_array( (int) $h['id'], $targets, true ) ); ?>>
							<?php echo esc_html( Hablab_Reminders::target_name( 'habit', $h ) ); ?>
						</option>
					<?php endforeach; ?>
				</select>
				<select name="<?php echo esc_attr( $name ); ?>[targets_timeblock][]" multiple size="4"
					class="hablab-targets-timeblock" style="width:100%;<?php echo 'timeblock' === $type ? '' : 'display:none'; ?>">
					<?php foreach ( $blocks as $b ) : ?>
						<option value="<?php echo (int) $b['id']; ?>" <?php selected( 'timeblock' === $type && in_array( (int) $b['id'], $targets, true ) ); ?>>
							<?php echo esc_html( Hablab_Reminders::target_name( 'timeblock', $b ) ); ?>
						</option>
					<?php endforeach; ?>
				</select>
			</td>
			<td><input type="number" name="<?php echo esc_attr( $name ); ?>[threshold_days]" min="1" max="365"
				value="<?php echo (int) $rule['threshold_days']; ?>" style="width:70px"></td>
			<td><input type="number" name="<?php echo esc_attr( $name ); ?>[cooldown_days]" min="1" max="365"
				value="<?php echo (int) $rule['cooldown_days']; ?>" style="width:70px"></td>
			<td><button type="button" class="button-link button-link-delete hablab-remove-rule">Remove</button></td>
		</tr>
		<?php
	}
}

Hablab_Admin::init();
