<?php
defined( 'ABSPATH' ) || exit;

/**
 * Self-hosted update channel client — two-track (stable + beta) with
 * version rollback. Ported from the STEMMAXXER pipeline (SMX_Updater,
 * itself ported from WeIdea Studio's WI_Updater), HAB•LAB naming.
 *
 * The updater's ONLY outbound call: a version check against the public
 * channel manifest (JSON on GitHub Pages), cached for 12 hours. No
 * telemetry, no phoning home, no third-party services.
 *
 * The manifest carries a `channels` map (stable/beta) and a `releases`
 * list of retained versions. Each site picks its channel (option
 * `hablab_update_channel`); beta sites receive whichever of the
 * two tracks is newest, so a stable promotion never strands them.
 * Rollback works by pointing WordPress's native upgrade flow at an older
 * retained release (see Hablab_Updater_Admin).
 *
 * DEFAULT CHANNEL: 'stable' (WeIdea's default; unlike STEMMAXXER's
 * beta-cycle default). seejennings.com is a single production install
 * with stable version numbering — every publish goes to the stable
 * track unless Chris deliberately runs a beta.
 */
class Hablab_Updater {

	const TRANSIENT       = 'hablab_update_manifest';
	const CHANNEL_OPTION  = 'hablab_update_channel';
	const ROLLBACK_TARGET = 'hablab_rollback_target';
	const SLUG            = 'hablab';

	/** @var Hablab_Updater|null */
	private static $instance = null;

	/** @var string */
	private $manifest_url;

	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	private function __construct() {
		$default = defined( 'HABLAB_UPDATE_MANIFEST_URL' )
			? HABLAB_UPDATE_MANIFEST_URL
			: 'https://blazzzar.github.io/hablab-updates/hablab.json';

		/**
		 * Filter the update-manifest URL (also used by test harnesses).
		 *
		 * @param string $url Manifest URL.
		 */
		$this->manifest_url = apply_filters( 'hablab_update_manifest_url', $default );

		add_filter( 'pre_set_site_transient_update_plugins', array( $this, 'inject_update' ) );
		add_filter( 'site_transient_update_plugins', array( $this, 'apply_rollback_target' ) );
		add_action( 'upgrader_process_complete', array( $this, 'clear_rollback_target' ), 10, 2 );
		add_filter( 'plugins_api', array( $this, 'plugin_info' ), 10, 3 );
	}

	/**
	 * The plugin basename ("hablab/hablab.php").
	 *
	 * @return string
	 */
	public static function basename() {
		return plugin_basename( HABLAB_PLUGIN_FILE );
	}

	/**
	 * The channel this site rides: 'stable' or 'beta'. Default 'stable'.
	 *
	 * @return string
	 */
	public function channel() {
		$channel = get_option( self::CHANNEL_OPTION, 'stable' );

		/**
		 * Filter the site's release channel.
		 *
		 * @param string $channel 'stable' or 'beta'.
		 */
		$channel = apply_filters( 'hablab_update_channel', $channel );
		return 'beta' === $channel ? 'beta' : 'stable';
	}

	/**
	 * Drop the cached manifest so the next check re-fetches immediately.
	 */
	public function flush_manifest_cache() {
		delete_site_transient( self::TRANSIENT );
	}

	/**
	 * Fetch (or reuse) the channel manifest.
	 *
	 * @return object|null
	 */
	private function manifest() {
		$cached = get_site_transient( self::TRANSIENT );
		if ( is_object( $cached ) ) {
			return $cached;
		}

		$response = wp_remote_get( $this->manifest_url, array( 'timeout' => 10 ) );
		if ( is_wp_error( $response ) || 200 !== wp_remote_retrieve_response_code( $response ) ) {
			return null;
		}

		$data = json_decode( wp_remote_retrieve_body( $response ) );
		if ( ! is_object( $data ) ) {
			return null;
		}

		set_site_transient( self::TRANSIENT, $data, 12 * HOUR_IN_SECONDS );
		return $data;
	}

	/**
	 * The release this site's channel is currently offered.
	 *
	 * Stable rides the stable track. Beta rides whichever track is newest
	 * (a promoted stable release must reach beta sites too).
	 *
	 * @return object|null Release object with at least version + download_url.
	 */
	public function channel_release() {
		$manifest = $this->manifest();
		if ( ! $manifest ) {
			return null;
		}

		if ( isset( $manifest->channels ) && is_object( $manifest->channels ) ) {
			$stable = isset( $manifest->channels->stable ) ? $manifest->channels->stable : null;
			$beta   = isset( $manifest->channels->beta ) ? $manifest->channels->beta : null;

			if ( 'beta' === $this->channel() && is_object( $beta ) && ! empty( $beta->version ) ) {
				if ( ! is_object( $stable ) || empty( $stable->version )
					|| version_compare( (string) $beta->version, (string) $stable->version, '>' ) ) {
					return $beta;
				}
			}
			return ( is_object( $stable ) && ! empty( $stable->version ) ) ? $stable : null;
		}

		// Legacy flat manifest: a bare version at the top level is stable.
		return empty( $manifest->version ) ? null : $manifest;
	}

	/**
	 * Find a retained release by exact version.
	 *
	 * @param string $version Version string.
	 * @return object|null
	 */
	public function find_release( $version ) {
		$manifest = $this->manifest();
		if ( ! $manifest ) {
			return null;
		}
		$candidates = isset( $manifest->releases ) && is_array( $manifest->releases )
			? $manifest->releases
			: array();
		if ( isset( $manifest->channels ) && is_object( $manifest->channels ) ) {
			foreach ( (array) $manifest->channels as $entry ) {
				if ( is_object( $entry ) ) {
					$candidates[] = $entry;
				}
			}
		}
		foreach ( $candidates as $release ) {
			if ( is_object( $release ) && isset( $release->version )
				&& 0 === version_compare( (string) $release->version, (string) $version )
				&& ! empty( $release->download_url ) ) {
				return $release;
			}
		}
		return null;
	}

	/**
	 * The newest retained release older than the installed version — the
	 * one-click rollback target.
	 *
	 * @return object|null
	 */
	public function rollback_target() {
		$manifest = $this->manifest();
		if ( ! $manifest || ! isset( $manifest->releases ) || ! is_array( $manifest->releases ) ) {
			return null;
		}
		$best = null;
		foreach ( $manifest->releases as $release ) {
			if ( ! is_object( $release ) || empty( $release->version ) || empty( $release->download_url ) ) {
				continue;
			}
			if ( version_compare( (string) $release->version, HABLAB_VERSION, '>=' ) ) {
				continue;
			}
			if ( null === $best || version_compare( (string) $release->version, (string) $best->version, '>' ) ) {
				$best = $release;
			}
		}
		return $best;
	}

	/**
	 * Build the update-transient entry for a release.
	 *
	 * @param object $release Release object from the manifest.
	 * @return object
	 */
	private function transient_entry( $release ) {
		$manifest = $this->manifest();
		return (object) array(
			'id'           => self::basename(),
			'slug'         => self::SLUG,
			'plugin'       => self::basename(),
			'new_version'  => (string) $release->version,
			'url'          => isset( $manifest->homepage ) ? (string) $manifest->homepage : '',
			'package'      => (string) $release->download_url,
			'requires'     => isset( $release->requires ) ? (string) $release->requires : '',
			'tested'       => isset( $release->tested ) ? (string) $release->tested : '',
			'requires_php' => isset( $release->requires_php ) ? (string) $release->requires_php : '',
		);
	}

	/**
	 * Add the channel's newer version (if any) to the update transient.
	 *
	 * @param object|false $transient Update transient being saved.
	 * @return object
	 */
	public function inject_update( $transient ) {
		if ( ! is_object( $transient ) ) {
			$transient = new stdClass();
		}

		$release = $this->channel_release();
		if ( $release && version_compare( (string) $release->version, HABLAB_VERSION, '>' ) ) {
			if ( ! isset( $transient->response ) || ! is_array( $transient->response ) ) {
				$transient->response = array();
			}
			$transient->response[ self::basename() ] = $this->transient_entry( $release );
		}
		return $transient;
	}

	/**
	 * While a rollback is armed (Hablab_Updater_Admin sets a short-lived
	 * target), WordPress's native upgrade flow must see the older release
	 * as "the update" — same pipeline, different direction.
	 *
	 * @param object|false $transient Update transient being read.
	 * @return object|false
	 */
	public function apply_rollback_target( $transient ) {
		$version = get_site_transient( self::ROLLBACK_TARGET );
		if ( empty( $version ) || ! is_string( $version ) ) {
			return $transient;
		}
		$release = $this->find_release( $version );
		if ( ! $release ) {
			return $transient;
		}
		if ( ! is_object( $transient ) ) {
			$transient = new stdClass();
		}
		if ( ! isset( $transient->response ) || ! is_array( $transient->response ) ) {
			$transient->response = array();
		}
		$transient->response[ self::basename() ] = $this->transient_entry( $release );
		return $transient;
	}

	/**
	 * Disarm the rollback once this plugin has been (re)installed.
	 *
	 * @param WP_Upgrader $upgrader Upgrader instance.
	 * @param array       $extra    Process details.
	 */
	public function clear_rollback_target( $upgrader, $extra ) {
		if ( isset( $extra['type'] ) && 'plugin' !== $extra['type'] ) {
			return;
		}
		$plugins = array();
		if ( isset( $extra['plugins'] ) && is_array( $extra['plugins'] ) ) {
			$plugins = $extra['plugins'];
		} elseif ( isset( $extra['plugin'] ) ) {
			$plugins = array( $extra['plugin'] );
		}
		if ( in_array( self::basename(), $plugins, true ) ) {
			delete_site_transient( self::ROLLBACK_TARGET );
		}
	}

	/**
	 * Serve the "View details" screen from the manifest.
	 *
	 * @param mixed  $result Default result.
	 * @param string $action API action.
	 * @param object $args   API args.
	 * @return mixed
	 */
	public function plugin_info( $result, $action, $args ) {
		if ( 'plugin_information' !== $action || empty( $args->slug ) || self::SLUG !== $args->slug ) {
			return $result;
		}
		$manifest = $this->manifest();
		$release  = $this->channel_release();
		if ( ! $manifest || ! $release ) {
			return $result;
		}

		$sections = array( 'description' => 'HAB•LAB — personal habit / time-block / music-practice tracker at seejennings.com/hablab.html.' );
		if ( isset( $release->sections ) ) {
			$sections = (array) $release->sections;
		} elseif ( isset( $manifest->sections ) ) {
			$sections = (array) $manifest->sections;
		}

		return (object) array(
			'name'          => isset( $manifest->name ) ? (string) $manifest->name : 'HAB•LAB',
			'slug'          => self::SLUG,
			'version'       => (string) $release->version,
			'author'        => 'Chris Jennings',
			'homepage'      => isset( $manifest->homepage ) ? (string) $manifest->homepage : '',
			'requires'      => isset( $release->requires ) ? (string) $release->requires : '',
			'tested'        => isset( $release->tested ) ? (string) $release->tested : '',
			'requires_php'  => isset( $release->requires_php ) ? (string) $release->requires_php : '',
			'download_link' => (string) $release->download_url,
			'sections'      => $sections,
		);
	}
}
