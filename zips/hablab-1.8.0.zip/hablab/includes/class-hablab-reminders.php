<?php
defined( 'ABSPATH' ) || exit;

/**
 * Habit-staleness email reminders.
 *
 * A daily WP-Cron job (mirroring Hablab_Backups) checks every enabled reminder
 * rule and, when watched habits/time-blocks have gone stale, sends ONE
 * plain-text digest for the day via wp_mail(). Config is a single settings
 * row ('reminders', edited on Settings → HAB•LAB); per-target send state
 * lives separately ('reminders_state') so the cron never rewrites the
 * user-editable config and cooldowns survive across runs. Targets that have
 * never been completed are skipped — a habit is only watched once it's been
 * done at least once. Config + state ride along in the daily JSON backups
 * automatically (Hablab_Backups exports all settings rows).
 */
class Hablab_Reminders {

	const CRON_HOOK   = 'hablab_daily_reminders';
	const SETTING_KEY = 'reminders';
	const STATE_KEY   = 'reminders_state';

	public static function init() {
		add_action( self::CRON_HOOK, array( __CLASS__, 'run_checks' ) );
	}

	public static function schedule() {
		if ( ! wp_next_scheduled( self::CRON_HOOK ) ) {
			wp_schedule_event( time() + HOUR_IN_SECONDS, 'daily', self::CRON_HOOK );
		}
	}

	public static function unschedule() {
		wp_clear_scheduled_hook( self::CRON_HOOK );
	}

	/** Stored config merged over defaults (missing keys can't error out). */
	public static function get_config() {
		$config = Hablab_DB::get_setting( self::SETTING_KEY );
		if ( ! is_array( $config ) ) {
			$config = array();
		}
		$config += array(
			'enabled'   => false,
			'recipient' => '',
			'rules'     => array(),
		);
		if ( ! is_array( $config['rules'] ) ) {
			$config['rules'] = array();
		}
		return $config;
	}

	/** rule_id → target_id → last-sent Y-m-d. */
	public static function get_state() {
		$state = Hablab_DB::get_setting( self::STATE_KEY );
		return is_array( $state ) ? $state : array();
	}

	/** Configured recipient, falling back to the site admin email. */
	public static function recipient() {
		$config = self::get_config();
		$to     = is_string( $config['recipient'] ) ? sanitize_email( $config['recipient'] ) : '';
		if ( $to && is_email( $to ) ) {
			return $to;
		}
		return get_option( 'admin_email' );
	}

	/** All habits keyed by id (id, full_name, badge, active, ends_on). */
	public static function habit_catalog() {
		global $wpdb;
		$table = Hablab_DB::table( 'habits' );
		$rows  = $wpdb->get_results( "SELECT id, full_name, badge, active, ends_on FROM $table ORDER BY sort, id", ARRAY_A );
		$out   = array();
		foreach ( (array) $rows as $r ) {
			$out[ (int) $r['id'] ] = $r;
		}
		return $out;
	}

	/** All time-block categories keyed by id (id, label, badge, active). */
	public static function timeblock_catalog() {
		global $wpdb;
		$table = Hablab_DB::table( 'timeblock_categories' );
		$rows  = $wpdb->get_results( "SELECT id, label, badge, active FROM $table ORDER BY sort, id", ARRAY_A );
		$out   = array();
		foreach ( (array) $rows as $r ) {
			$out[ (int) $r['id'] ] = $r;
		}
		return $out;
	}

	/** Display name for a catalog row. */
	public static function target_name( $type, $row ) {
		if ( 'timeblock' === $type ) {
			if ( isset( $row['label'] ) && '' !== (string) $row['label'] ) {
				return (string) $row['label'];
			}
			if ( isset( $row['badge'] ) && '' !== (string) $row['badge'] ) {
				return (string) $row['badge'];
			}
			return 'Category #' . ( isset( $row['id'] ) ? (int) $row['id'] : 0 );
		}
		return isset( $row['full_name'] ) ? (string) $row['full_name'] : '';
	}

	/** Y-m-d of the most recent completion, or null if never completed. */
	public static function last_completion( $type, $target_id ) {
		global $wpdb;
		if ( 'timeblock' === $type ) {
			$table = Hablab_DB::table( 'timeblock_entries' );
			return $wpdb->get_var( $wpdb->prepare(
				"SELECT MAX(entry_date) FROM $table WHERE category_id = %d AND blocks_filled > 0", $target_id
			) );
		}
		$table = Hablab_DB::table( 'habit_entries' );
		return $wpdb->get_var( $wpdb->prepare(
			"SELECT MAX(entry_date) FROM $table WHERE habit_id = %d AND done = 1", $target_id
		) );
	}

	/** Whole days from $date to $today; 0 when $date is in the future; null on garbage. */
	private static function days_since( $date, $today ) {
		try {
			$from = new DateTimeImmutable( (string) $date );
			$to   = new DateTimeImmutable( (string) $today );
		} catch ( Exception $e ) {
			return null;
		}
		$diff = $from->diff( $to );
		return $diff->invert ? 0 : (int) $diff->days;
	}

	/**
	 * Dry-run: every stale item across all enabled rules, no side effects.
	 * Each item carries status 'due' (would be emailed by the next run) or
	 * 'cooling' (stale, but nudged less than cooldown_days ago). Skipped
	 * entirely: never-completed, inactive, and ended targets. Also reused by
	 * the admin "Preview what's due now" button.
	 *
	 * @param string|null $today Y-m-d in the site timezone (defaults to now).
	 * @return array[] { rule_id, rule_label, type, target_id, name, last_done, days_since, status }
	 */
	public static function evaluate( $today = null ) {
		$today  = $today ? $today : current_time( 'Y-m-d' );
		$config = self::get_config();
		$state  = self::get_state();
		$habits = self::habit_catalog();
		$blocks = self::timeblock_catalog();
		$items  = array();

		foreach ( $config['rules'] as $rule ) {
			if ( ! is_array( $rule ) || empty( $rule['enabled'] ) || empty( $rule['targets'] ) || ! is_array( $rule['targets'] ) ) {
				continue;
			}
			$type      = ( isset( $rule['type'] ) && 'timeblock' === $rule['type'] ) ? 'timeblock' : 'habit';
			$threshold = max( 1, isset( $rule['threshold_days'] ) ? (int) $rule['threshold_days'] : 5 );
			$cooldown  = max( 1, isset( $rule['cooldown_days'] ) ? (int) $rule['cooldown_days'] : 3 );
			$rule_id   = isset( $rule['id'] ) ? (string) $rule['id'] : '';
			$label     = ( isset( $rule['label'] ) && '' !== (string) $rule['label'] ) ? (string) $rule['label'] : 'Reminders';

			foreach ( $rule['targets'] as $target_id ) {
				$target_id = (int) $target_id;
				$row       = 'timeblock' === $type
					? ( isset( $blocks[ $target_id ] ) ? $blocks[ $target_id ] : null )
					: ( isset( $habits[ $target_id ] ) ? $habits[ $target_id ] : null );
				if ( ! $row || empty( $row['active'] ) ) {
					continue; // deleted or deactivated — never nudge
				}
				if ( 'habit' === $type && ! empty( $row['ends_on'] ) && $row['ends_on'] < $today ) {
					continue; // habit's scheduled run is over
				}
				$last = self::last_completion( $type, $target_id );
				if ( ! $last ) {
					continue; // never completed — not watched until the first completion
				}
				$days = self::days_since( $last, $today );
				if ( null === $days || $days < $threshold ) {
					continue;
				}
				// Cooldown: at most one nudge per target per max(1, cooldown_days)
				// days — the floor of 1 also stops double-sends if the cron fires
				// twice in a day.
				$sent_on    = isset( $state[ $rule_id ][ $target_id ] ) ? (string) $state[ $rule_id ][ $target_id ] : '';
				$since_sent = '' !== $sent_on ? self::days_since( $sent_on, $today ) : null;
				$cooling    = ( null !== $since_sent && $since_sent < $cooldown );

				$items[] = array(
					'rule_id'    => $rule_id,
					'rule_label' => $label,
					'type'       => $type,
					'target_id'  => $target_id,
					'name'       => self::target_name( $type, $row ),
					'last_done'  => (string) $last,
					'days_since' => $days,
					'status'     => $cooling ? 'cooling' : 'due',
				);
			}
		}
		return $items;
	}

	/** Plain-text digest body: items grouped by rule, footer link to /hablab.html. */
	public static function digest_body( $due ) {
		$groups = array();
		foreach ( $due as $item ) {
			$key = $item['rule_id'] . '|' . $item['rule_label'];
			if ( ! isset( $groups[ $key ] ) ) {
				$groups[ $key ] = array(
					'label' => $item['rule_label'],
					'lines' => array(),
				);
			}
			$groups[ $key ]['lines'][] = sprintf( '• %s — last done %d days ago', $item['name'], $item['days_since'] );
		}
		$out = '';
		foreach ( $groups as $group ) {
			$out .= $group['label'] . "\n" . implode( "\n", $group['lines'] ) . "\n\n";
		}
		$out .= 'Check things off: ' . home_url( '/hablab.html' ) . "\n";
		return $out;
	}

	/**
	 * The daily cron callback. Sends at most one digest covering everything
	 * due, then records today against each included rule/target so cooldowns
	 * hold across runs. Nothing due (or reminders disabled) → no email.
	 *
	 * @return int|false Number of items emailed (0 = nothing due), false when wp_mail failed.
	 */
	public static function run_checks() {
		$config = self::get_config();
		if ( empty( $config['enabled'] ) ) {
			return 0;
		}
		$to = self::recipient();
		if ( ! $to ) {
			return 0;
		}
		$today = current_time( 'Y-m-d' );
		$due   = array();
		foreach ( self::evaluate( $today ) as $item ) {
			if ( 'due' === $item['status'] ) {
				$due[] = $item;
			}
		}
		if ( ! $due ) {
			return 0;
		}
		$subject = sprintf( 'HAB•LAB nudge: %d habit(s) need attention', count( $due ) );
		if ( ! wp_mail( $to, $subject, self::digest_body( $due ) ) ) {
			return false; // leave state untouched — everything re-qualifies tomorrow
		}
		$state = self::get_state();
		foreach ( $due as $item ) {
			if ( ! isset( $state[ $item['rule_id'] ] ) || ! is_array( $state[ $item['rule_id'] ] ) ) {
				$state[ $item['rule_id'] ] = array();
			}
			$state[ $item['rule_id'] ][ $item['target_id'] ] = $today;
		}
		Hablab_DB::put_setting( self::STATE_KEY, $state );
		return count( $due );
	}

	/** Sample digest to the configured recipient, so delivery can be confirmed. */
	public static function send_test() {
		$to = self::recipient();
		if ( ! $to ) {
			return false;
		}
		$body = "This is a test of HAB•LAB's reminder emails — delivery works.\n\n"
			. "When a watched habit or time-block goes stale you'll get one digest per day, like:\n\n"
			. "Core morning habits\n"
			. "• Meditate — last done 6 days ago\n\n"
			. 'Check things off: ' . home_url( '/hablab.html' ) . "\n";
		return wp_mail( $to, 'HAB•LAB nudge: test email', $body );
	}
}
