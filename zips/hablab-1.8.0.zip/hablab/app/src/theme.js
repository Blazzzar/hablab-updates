// Applies theme tokens from settings to the CSS custom properties.
const MAP = {
	stroke: '--box',   // box outlines / grid strokes
	text: '--ink',     // text, icons, tallies
	trend: '--trend',  // the ↑ ↓ │ marks
	paper: '--paper',
	cellBg: '--cell-bg',
	mondayBg: '--monday-bg',
	navBg: '--nav-bg',
	navActive: '--nav-active',
	labelBg: '--label-bg',
	circleOutline: '--circle-outline',
	circleFill: '--circle-fill',
	circleOpen: '--circle-open',
	page: '--page',
};

export function applyTheme(tokens) {
	if (!tokens) return;
	const root = document.documentElement.style;
	for (const [key, cssVar] of Object.entries(MAP)) {
		if (tokens[key]) root.setProperty(cssVar, tokens[key]);
	}
	if (tokens.tbDotSize != null) {
		const d = Math.min(Math.max(Number(tokens.tbDotSize) || 13.8, 8), 24);
		root.setProperty('--tb-dot', d + 'px');
	}
	if (tokens.shadow != null || tokens.shadowX != null) {
		const s = Math.max(0, Number(tokens.shadow ?? 24) || 0);
		const x = Math.max(-60, Math.min(60, Number(tokens.shadowX) || 0));
		root.setProperty('--sheet-shadow', s > 0 ? `${x}px ${Math.round(s / 3)}px ${s}px rgba(23, 38, 63, 0.32)` : 'none');
	}
	const meta = document.querySelector('meta[name="theme-color"]');
	if (meta && tokens.paper) meta.setAttribute('content', tokens.paper);
}

/**
 * Circle stroke width for one section. circleStroke is per-section (keyed by
 * view id, e.g. {default: 2, habits: 2, blocks: 3}) so tuning Time Blocks
 * never touches Habits; `default` covers sections without their own value.
 * A bare number (pre-1.2.1 deploys) still means "every section".
 */
export function strokeFor(tokens, section) {
	const cs = tokens ? tokens.circleStroke : null;
	const v = cs != null && typeof cs === 'object' ? (cs[section] ?? cs.default) : cs;
	const n = Number(v);
	return isFinite(n) && n > 0 ? n : 2;
}
