import { render } from 'preact';
import { html } from './h.js';
import { App } from './app.js';

// Local dev has no HABLAB_CONFIG (WP injects it); ?mode=demo previews the demo.
const config = window.HABLAB_CONFIG
	|| { mode: new URLSearchParams(location.search).get('mode') === 'demo' ? 'demo' : 'dev' };

render(html`<${App} config=${config} />`, document.getElementById('app'));

// Service worker only in live mode — dev and demo stay uncached.
// Scope matches the manifest's /hablab.html start_url exactly.
if (config.mode === 'live' && 'serviceWorker' in navigator && config.swUrl) {
	window.addEventListener('load', () => {
		navigator.serviceWorker.register(config.swUrl, { scope: '/hablab.html' }).catch(() => {});
	});
}
