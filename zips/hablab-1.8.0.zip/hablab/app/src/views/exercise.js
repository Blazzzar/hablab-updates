import { html } from '../h.js';
import { useState, useMemo, useEffect, useRef } from 'preact/hooks';
import { todayYMD } from '../lib/dates.js';
import { notifyFailure } from '../lib/notify.js';

/* Workout log (§ user feedback, modeled on the paper Workout Log sheet but
   vertical): one sheet per day, rows = exercise + 5 sets (weight/reps) +
   cardio time/dist. Only rows with content are persisted, so days you skip
   never appear in the archive. */

const SETS = 5;
const MIN_ROWS = 10;

const emptyData = () => ({ sets: Array.from({ length: SETS }, () => ['', '']), time: '', dist: '' });

function rowHasContent(row) {
	if (row.exercise_id) return true;
	const d = row.data || {};
	if ((d.time || '') !== '' || (d.dist || '') !== '') return true;
	return (d.sets || []).some(([w, r]) => (w || '') !== '' || (r || '') !== '');
}

function fmtDay(ymd) {
	const d = new Date(ymd + 'T12:00:00');
	return d.toLocaleDateString('en-US', { weekday: 'short', month: 'short', day: 'numeric' });
}

export function ExerciseView({ boot, setBoot, api }) {
	const data = boot.month;
	const exercises = boot.exercises || [];
	const today = todayYMD();
	const isCurrentMonth = data.month === today.slice(0, 7);
	// Default to today's sheet; in an archived month, to its latest logged day.
	const loggedDates = useMemo(() => {
		const set = new Set((data.workouts || []).map((r) => r.entry_date));
		return [...set].sort();
	}, [data.workouts]);
	const [selDate, setSelDate] = useState(null);
	const date = selDate && selDate.slice(0, 7) === data.month ? selDate
		: isCurrentMonth ? today
		: (loggedDates[loggedDates.length - 1] || data.month + '-01');

	// Local editable rows for the selected date: saved rows + blank padding.
	const [rows, setRows] = useState([]);
	const savedFor = useMemo(() => (data.workouts || []).filter((r) => r.entry_date === date).sort((a, b) => a.sort - b.sort), [data.workouts, date]);
	useEffect(() => {
		const base = savedFor.map((r) => ({ id: r.id, sort: r.sort, exercise_id: r.exercise_id || null, data: { ...emptyData(), ...(r.data || {}) } }));
		while (base.length < MIN_ROWS) base.push({ id: null, sort: base.length, exercise_id: null, data: emptyData() });
		setRows(base);
	}, [date, data.month]); // eslint-disable-line

	const [picker, setPicker] = useState(null); // row index choosing an exercise
	const [managing, setManaging] = useState(false);
	const rowsRef = useRef(rows);
	rowsRef.current = rows;

	function patchWorkouts(updater) {
		setBoot((b) => ({ ...b, month: { ...b.month, workouts: updater(b.month.workouts || []) } }));
	}

	/** Persist one row if it has content (or already exists server-side). */
	function persistRow(idx, nextRows) {
		const row = nextRows[idx];
		if (!row.id && !rowHasContent(row)) return; // empty + never saved → nothing to do
		api.putWorkoutRow({ id: row.id || undefined, date, sort: idx, exercise_id: row.exercise_id, data: row.data })
			.then((saved) => {
				if (!row.id && saved && saved.id) {
					setRows((rs) => rs.map((r, i) => (i === idx ? { ...r, id: saved.id } : r)));
					patchWorkouts((w) => [...w, saved]);
				} else if (saved && saved.id) {
					patchWorkouts((w) => w.map((r) => (r.id === saved.id ? saved : r)));
				}
			})
			.catch(notifyFailure);
	}

	function setCell(idx, mutate) {
		setRows((rs) => {
			const next = rs.map((r, i) => (i === idx ? { ...r, data: { ...r.data, sets: r.data.sets.map((s) => [...s]) } } : r));
			mutate(next[idx]);
			return next;
		});
	}

	function onCellBlur(idx) {
		// Defer past the pending state commit so a blur immediately after a
		// keystroke persists the keystroke, not the state before it.
		setTimeout(() => persistRow(idx, rowsRef.current), 0);
	}

	function chooseExercise(idx, exerciseId) {
		setPicker(null);
		setRows((rs) => {
			const next = rs.map((r, i) => (i === idx ? { ...r, exercise_id: exerciseId } : r));
			// persist with the updated value (state not yet committed)
			const row = next[idx];
			if (row.id || rowHasContent(row)) {
				api.putWorkoutRow({ id: row.id || undefined, date, sort: idx, exercise_id: row.exercise_id, data: row.data })
					.then((saved) => {
						if (saved && saved.id) {
							if (!row.id) setRows((rs2) => rs2.map((r, i) => (i === idx ? { ...r, id: saved.id } : r)));
							patchWorkouts((w) => (w.some((x) => x.id === saved.id) ? w.map((x) => (x.id === saved.id ? saved : x)) : [...w, saved]));
						}
					})
					.catch(notifyFailure);
			}
			return next;
		});
	}

	async function removeRow(idx) {
		const row = rows[idx];
		if (row.id) {
			try { await api.deleteWorkoutRow(row.id); } catch (e) { notifyFailure(); return; }
			patchWorkouts((w) => w.filter((r) => r.id !== row.id));
		}
		setRows((rs) => {
			const next = rs.filter((_, i) => i !== idx);
			while (next.length < MIN_ROWS) next.push({ id: null, sort: next.length, exercise_id: null, data: emptyData() });
			return next;
		});
	}

	async function addExercise(name) {
		const row = await api.createExercise(name);
		setBoot((b) => ({
			...b,
			exercises: (b.exercises || []).some((x) => x.id === row.id)
				? b.exercises.map((x) => (x.id === row.id ? row : x))
				: [...(b.exercises || []), row],
		}));
		return row;
	}

	async function retireExercise(id) {
		if (!confirm('Remove this exercise from the master list? Logged workouts keep it.')) return;
		await api.updateExercise(id, { active: 0 }).catch(notifyFailure);
		setBoot((b) => ({ ...b, exercises: (b.exercises || []).filter((x) => x.id !== id) }));
	}

	const exName = (id) => exercises.find((x) => x.id === Number(id))?.name || '—';

	return html`
		<div class="ex">
			<div class="ex-head">
				<div>
					<div class="ex-date">${fmtDay(date)}</div>
					<div class="ex-sub">${date === today ? 'today’s sheet' : 'archived sheet'}</div>
				</div>
				<button class="music-add" onClick=${() => setManaging(true)}>exercises…</button>
			</div>

			${loggedDates.length > 0 && html`
				<div class="ex-archive">
					${isCurrentMonth && !loggedDates.includes(today) && html`
						<button class=${'ex-chip' + (date === today ? ' sel' : '')} onClick=${() => setSelDate(today)}>today</button>`}
					${[...loggedDates].reverse().map((d) => html`
						<button key=${d} class=${'ex-chip' + (d === date ? ' sel' : '')} onClick=${() => setSelDate(d)}>
							${fmtDay(d)}
						</button>`)}
				</div>`}

			${rows.map((row, idx) => html`
				<div key=${idx} class="ex-row">
					<div class="ex-row-head">
						<button class="ex-pick" onClick=${() => setPicker(idx)}>
							${row.exercise_id ? exName(row.exercise_id) : html`<span class="ex-ghost">choose exercise…</span>`}
						</button>
						${(row.id || rowHasContent(row)) && html`
							<button class="rt-del" title="Delete row" onClick=${() => removeRow(idx)}>✕</button>`}
					</div>
					<div class="ex-sets">
						${row.data.sets.map(([w, r], si) => html`
							<div key=${si} class="ex-set">
								<div class="ex-set-label">set ${si + 1}</div>
								<input inputmode="decimal" placeholder="wt" value=${w}
									onInput=${(e) => setCell(idx, (rw) => { rw.data.sets[si][0] = e.target.value; })}
									onBlur=${() => onCellBlur(idx)} />
								<input inputmode="numeric" placeholder="rep" value=${r}
									onInput=${(e) => setCell(idx, (rw) => { rw.data.sets[si][1] = e.target.value; })}
									onBlur=${() => onCellBlur(idx)} />
							</div>`)}
						<div class="ex-set ex-cardio">
							<div class="ex-set-label">cardio</div>
							<input inputmode="decimal" placeholder="time" value=${row.data.time}
								onInput=${(e) => setCell(idx, (rw) => { rw.data.time = e.target.value; })}
								onBlur=${() => onCellBlur(idx)} />
							<input inputmode="decimal" placeholder="dist" value=${row.data.dist}
								onInput=${(e) => setCell(idx, (rw) => { rw.data.dist = e.target.value; })}
								onBlur=${() => onCellBlur(idx)} />
						</div>
					</div>
				</div>`)}

			<button class="music-add rt-add" onClick=${() => setRows((rs) => [...rs, { id: null, sort: rs.length, exercise_id: null, data: emptyData() }])}>
				+ row
			</button>

			${picker != null && html`<${ExercisePicker}
				exercises=${exercises}
				onPick=${(id) => chooseExercise(picker, id)}
				onAdd=${async (name) => { const row = await addExercise(name); chooseExercise(picker, row.id); }}
				onClose=${() => setPicker(null)} />`}

			${managing && html`<${ExerciseManager}
				exercises=${exercises}
				onAdd=${addExercise}
				onRetire=${retireExercise}
				onClose=${() => setManaging(false)} />`}
		</div>`;
}

function ExercisePicker({ exercises, onPick, onAdd, onClose }) {
	const [adding, setAdding] = useState('');
	return html`
		<div class="sheet-overlay" onClick=${onClose}>
			<div class="editor" onClick=${(e) => e.stopPropagation()}>
				<div class="editor-title">Pick exercise</div>
				<div class="ex-list">
					${exercises.map((x) => html`
						<button key=${x.id} class="ex-option" onClick=${() => onPick(x.id)}>${x.name}</button>`)}
				</div>
				<form class="ex-add-form" onSubmit=${(e) => { e.preventDefault(); if (adding.trim()) { onAdd(adding.trim()); setAdding(''); } }}>
					<input placeholder="New exercise (added to master list)" value=${adding} onInput=${(e) => setAdding(e.target.value)} />
					<button type="submit">Add</button>
				</form>
				<div class="editor-actions"><span class="spacer"></span><button type="button" onClick=${onClose}>Cancel</button></div>
			</div>
		</div>`;
}

function ExerciseManager({ exercises, onAdd, onRetire, onClose }) {
	const [adding, setAdding] = useState('');
	return html`
		<div class="sheet-overlay" onClick=${onClose}>
			<div class="editor" onClick=${(e) => e.stopPropagation()}>
				<div class="editor-title">Master exercise list</div>
				${exercises.map((x) => html`
					<div key=${x.id} class="set-device">
						<span>${x.name}</span>
						<button class="set-revoke" onClick=${() => onRetire(x.id)}>remove</button>
					</div>`)}
				<form class="ex-add-form" onSubmit=${(e) => { e.preventDefault(); if (adding.trim()) { onAdd(adding.trim()); setAdding(''); } }}>
					<input placeholder="New exercise" value=${adding} onInput=${(e) => setAdding(e.target.value)} />
					<button type="submit">Add</button>
				</form>
				<div class="editor-actions"><span class="spacer"></span><button type="button" onClick=${onClose}>Done</button></div>
			</div>
		</div>`;
}
