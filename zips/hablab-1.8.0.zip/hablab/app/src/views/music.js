import { html } from '../h.js';
import { useState, useMemo } from 'preact/hooks';
import { TallyMarks } from '../lib/tally.js';
import { notifyFailure } from '../lib/notify.js';
import { burstFrom } from '../lib/burst.js';

const GHOST_SONG = 'Seek and Destroy (Metallica)';
const GHOST_TRACKER = 'Rhythm Guitar Run Through';
const OTHER = '__other__';

/** Band convention: shown in parentheses at the end of the title. */
export function parseBand(title) {
	const m = /\(([^)]+)\)\s*$/.exec(title || '');
	return m ? m[1].trim() : '';
}

/** Alphabetical by song, grouped by band (bands alphabetical too). */
export function sortSongs(songs) {
	return [...songs].sort((a, b) => {
		const ba = parseBand(a.title).toLowerCase(), bb = parseBand(b.title).toLowerCase();
		const ta = a.title.toLowerCase(), tb = b.title.toLowerCase();
		const ka = ba || ta, kb = bb || tb;
		if (ka !== kb) return ka < kb ? -1 : 1;
		return ta < tb ? -1 : ta > tb ? 1 : 0;
	});
}

function fmtAdded(ymd) {
	if (!ymd) return null;
	const d = new Date(ymd + 'T12:00:00');
	return isNaN(d) ? null : d.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });
}

export function MusicView({ boot, setBoot, api }) {
	const songs = boot.songs;
	const trackers = boot.song_trackers || [];
	// IDs are normalized to numbers at the API boundary; coerce last_view too
	// (older saved settings may hold strings).
	const lastId = Number(boot.settings.last_view.songId) || null;
	const sorted = useMemo(() => sortSongs(songs), [songs]);
	const songId = sorted.some((s) => s.id === lastId) ? lastId : (sorted[0]?.id ?? null);
	const song = songs.find((s) => s.id === songId) || null;
	const [addingSong, setAddingSong] = useState(false);
	const [addingTracker, setAddingTracker] = useState(false);

	// Group for the dropdown: bandless songs first, then one optgroup per band.
	const grouped = useMemo(() => {
		const loose = sorted.filter((s) => !parseBand(s.title));
		const bands = new Map();
		for (const s of sorted) {
			const band = parseBand(s.title);
			if (!band) continue;
			if (!bands.has(band)) bands.set(band, []);
			bands.get(band).push(s);
		}
		return { loose, bands };
	}, [sorted]);

	function patchBoot(patch) {
		setBoot((b) => ({ ...b, ...patch }));
	}

	function selectSong(id) {
		// Build last_view from the freshest state so a recent tab/month change
		// inside the same tick isn't clobbered.
		setBoot((b) => {
			const last = { ...b.settings.last_view, songId: id };
			api.putSettings({ last_view: last }).catch(() => {});
			return { ...b, settings: { ...b.settings, last_view: last } };
		});
	}

	async function addSong(title) {
		const row = await api.createSong(title);
		// idempotent append — a double-submit can never duplicate a row
		setBoot((b) => ({ ...b, songs: b.songs.some((s) => s.id === row.id) ? b.songs : [...b.songs, row] }));
		setAddingSong(false);
		selectSong(row.id);
	}

	async function removeSong(id) {
		if (!confirm('Delete this song and all its tallies?')) return;
		try {
			await api.deleteSong(id);
		} catch (e) {
			notifyFailure();
			return;
		}
		patchBoot({
			songs: songs.filter((s) => s.id !== id),
			song_trackers: trackers.filter((t) => t.song_id !== id),
		});
		const rest = songs.filter((s) => s.id !== id);
		selectSong(rest[0]?.id ?? null);
	}

	async function addTracker(form) {
		let instrumentId = form.instrument_id;
		if (form.newInstrument) {
			const inst = await api.createInstrument(form.newInstrument);
			if (!boot.instruments.some((i) => i.id === inst.id)) {
				patchBoot({ instruments: [...boot.instruments, inst] });
			}
			instrumentId = inst.id;
		}
		const row = await api.createTracker(songId, { descriptor: form.descriptor, instrument_id: instrumentId });
		setBoot((b) => ({
			...b,
			song_trackers: (b.song_trackers || []).some((t) => t.id === row.id) ? b.song_trackers : [...(b.song_trackers || []), row],
		}));
		setAddingTracker(false);
	}

	async function removeTracker(id) {
		if (!confirm('Delete this run-through tracker and its tally?')) return;
		try {
			await api.deleteTracker(id);
		} catch (e) {
			notifyFailure();
			return;
		}
		patchBoot({ song_trackers: trackers.filter((t) => t.id !== id) });
	}

	function bump(tracker, dir) {
		// optimistic; server count reconciles on response
		patchBoot({
			song_trackers: trackers.map((t) => (t.id === tracker.id ? { ...t, count: Math.max(0, Number(t.count) + dir) } : t)),
		});
		const call = dir > 0 ? api.addPlaythrough(tracker.id) : api.removePlaythrough(tracker.id);
		call.then((res) => {
			if (res && res.count != null) {
				setBoot((b) => ({
					...b,
					song_trackers: b.song_trackers.map((t) => (t.id === tracker.id ? { ...t, count: Number(res.count) } : t)),
				}));
			}
		}).catch(notifyFailure);
	}

	if (!songs.length) {
		return html`
			<div class="music-empty">
				<div class="music-empty-title">No songs yet</div>
				<p>Track full play-throughs per song, per instrument — tally marks, just like paper.</p>
				${addingSong
					? html`<${SongForm} onSave=${addSong} onCancel=${() => setAddingSong(false)} />`
					: html`<button class="music-add" onClick=${() => setAddingSong(true)}>+ Add a song</button>`}
			</div>`;
	}

	const mine = trackers.filter((t) => t.song_id === songId);

	return html`
		<div class="music">
			<div class="music-switch">
				<span class=${'music-select-wrap' + (songs.length > 1 ? ' has-arrow' : '')}>
					<select value=${songId} onChange=${(e) => selectSong(Number(e.target.value))}>
						${grouped.loose.map((s) => html`<option key=${s.id} value=${s.id}>${s.title}</option>`)}
						${[...grouped.bands.entries()].map(([band, list]) => html`
							<optgroup key=${band} label=${band}>
								${list.map((s) => html`<option key=${s.id} value=${s.id}>${s.title}</option>`)}
							</optgroup>`)}
					</select>
					${songs.length > 1 && html`
						<svg class="select-arrow" viewBox="0 0 24 24" width="16" height="16" fill="none"
							stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
							<path d="m6 9 6 6 6-6" />
						</svg>`}
				</span>
				<button class="music-add" onClick=${() => setAddingSong(true)}>+ song</button>
			</div>
			${addingSong && html`<${SongForm} onSave=${addSong} onCancel=${() => setAddingSong(false)} />`}

			${song && html`
				<div class="song-head">
					<div class="song-head-main">
						<h2>${song.title}</h2>
						${fmtAdded(song.created_at) && html`<div class="song-added">added ${fmtAdded(song.created_at)}</div>`}
					</div>
					<button class="song-del" title="Delete song" onClick=${() => removeSong(song.id)}>✕</button>
				</div>`}

			${mine.map((t) => html`
				<div key=${t.id} class="rt-card">
					<div class="rt-head">
						<div>
							<div class="rt-desc">${t.descriptor || 'Run through'}</div>
							<div class="rt-inst">${boot.instruments.find((i) => i.id === Number(t.instrument_id))?.name || '—'}</div>
						</div>
						<div class="rt-count">${t.count}</div>
						<button class="rt-del" title="Delete tracker" onClick=${() => removeTracker(t.id)}>✕</button>
					</div>
					<div class="rt-body">
						<div class="rt-tallies"><${TallyMarks} count=${Number(t.count)} /></div>
						<div class="rt-side">
							<button class="rt-plus" title="+1 play-through" aria-label="+1 play-through"
								onClick=${(e) => { burstFrom(e.currentTarget); bump(t, +1); }}>+1</button>
							<button class="rt-minus" title="Undo one" onClick=${() => bump(t, -1)} disabled=${!Number(t.count)}>−1</button>
						</div>
					</div>
				</div>`)}

			${addingTracker
				? html`<${TrackerForm} instruments=${boot.instruments} onSave=${addTracker} onCancel=${() => setAddingTracker(false)} />`
				: html`<button class="music-add rt-add" onClick=${() => setAddingTracker(true)}>+ run-through tracker</button>`}
		</div>`;
}

function SongForm({ onSave, onCancel }) {
	const [title, setTitle] = useState('');
	const [busy, setBusy] = useState(false);
	return html`
		<form class="music-form" onSubmit=${(e) => {
			e.preventDefault();
			if (!title.trim() || busy) return;
			setBusy(true);
			Promise.resolve(onSave(title.trim()))
				.catch(() => notifyFailure())
				.finally(() => setBusy(false)); // re-enables the form if the save failed
		}}>
			<input placeholder=${GHOST_SONG} value=${title} onInput=${(e) => setTitle(e.target.value)} autofocus />
			<div class="music-form-actions">
				<button type="button" onClick=${onCancel}>Cancel</button>
				<button type="submit" class="primary" disabled=${busy}>Add song</button>
			</div>
		</form>`;
}

function TrackerForm({ instruments, onSave, onCancel }) {
	const [descriptor, setDescriptor] = useState('');
	const [instrument, setInstrument] = useState(instruments[0]?.id ?? OTHER);
	const [other, setOther] = useState('');
	const [busy, setBusy] = useState(false);

	function submit(e) {
		e.preventDefault();
		if (busy) return;
		const isOther = String(instrument) === OTHER;
		if (isOther && !other.trim()) return;
		setBusy(true);
		Promise.resolve(onSave({
			descriptor: descriptor.trim() || GHOST_TRACKER,
			instrument_id: isOther ? null : Number(instrument),
			newInstrument: isOther ? other.trim() : null,
		}))
			.catch(() => notifyFailure())
			.finally(() => setBusy(false));
	}

	return html`
		<form class="music-form" onSubmit=${submit}>
			<input placeholder=${GHOST_TRACKER} value=${descriptor} onInput=${(e) => setDescriptor(e.target.value)} autofocus />
			<select value=${instrument} onChange=${(e) => setInstrument(e.target.value)}>
				${instruments.map((i) => html`<option key=${i.id} value=${i.id}>${i.name}</option>`)}
				<option value=${OTHER}>Other…</option>
			</select>
			${String(instrument) === OTHER && html`
				<input placeholder="New instrument (added permanently)" value=${other}
					onInput=${(e) => setOther(e.target.value)} />`}
			<div class="music-form-actions">
				<button type="button" onClick=${onCancel}>Cancel</button>
				<button type="submit" class="primary" disabled=${busy}>Add tracker</button>
			</div>
		</form>`;
}
