// Color workbench (§3.4): floating pop-over, NOVASCOPE-style — every edit
// previews live across the whole app; Deploy persists to the backend so all
// devices pick it up on next load. Colors are global; the inward-stroke
// slider is PER-SECTION — it edits only the tab you're viewing (user request:
// thicker Time Blocks circles must not thicken Habits).
import { html } from './h.js';
import { useState, useRef } from 'preact/hooks';
import { applyTheme, strokeFor } from './theme.js';

// Sections that render circles; add future circle-bearing tabs here and the
// slider (and per-section stroke storage) picks them up automatically.
const CIRCLE_SECTIONS = { habits: 'Habits', blocks: 'Time Blocks' };

export const FACTORY_TOKENS = {
	stroke: '#17263F',
	text: '#17263F',
	trend: '#17263F',
	paper: '#6CC7E6',
	cellBg: '#6CC7E6',
	mondayBg: '#57B8DA',
	navBg: '#6CC7E6',
	navActive: '#FFF3B0',
	labelBg: '#6CC7E6',
	tbDotSize: 13.8,
	circleOutline: '#17263F',
	circleFill: '#17263F',
	circleOpen: '#FFFFFF',
	circleStroke: 2,
	shadow: 24,
	shadowX: 0,
	page: '#FFFFFF',
};

const COLOR_FIELDS = [
	{ key: 'stroke', label: 'Box outlines' },
	{ key: 'text', label: 'Text' },
	{ key: 'trend', label: 'Trend arrows' },
	{ key: 'paper', label: 'Tracker background' },
	{ key: 'cellBg', label: 'Circle-box background' },
	{ key: 'mondayBg', label: 'Monday/date box background' },
	{ key: 'navBg', label: 'Nav bar background' },
	{ key: 'navActive', label: 'Active tab background' },
	{ key: 'labelBg', label: 'Label box background' },
	{ key: 'circleOutline', label: 'Circle outline' },
	{ key: 'circleFill', label: 'Circle fill (done)' },
	{ key: 'circleOpen', label: 'Circle interior (not done)' },
];

export function Workbench({ boot, setBoot, api, view }) {
	const [open, setOpen] = useState(false);
	const [saving, setSaving] = useState(false);
	const snapshot = useRef(null);
	const panelRef = useRef(null);
	const drag = useRef(null);
	const tokens = boot.settings.theme_tokens;

	function setToken(key, value) {
		const next = { ...tokens, [key]: value };
		applyTheme(next);
		setBoot((b) => ({ ...b, settings: { ...b.settings, theme_tokens: next } }));
	}

	// Stroke edits apply only to the section on screen. A legacy bare-number
	// token is promoted to a per-section map on first edit; `default` keeps
	// the old value for sections that haven't been tuned individually.
	function setStroke(value) {
		const cur = tokens.circleStroke;
		const per = cur != null && typeof cur === 'object'
			? { ...cur, [view]: value }
			: { default: Number(cur) || 2, [view]: value };
		setToken('circleStroke', per);
	}

	function openPanel() {
		snapshot.current = { ...tokens };
		setOpen(true);
	}

	function revert(to) {
		const next = { ...to };
		applyTheme(next);
		setBoot((b) => ({ ...b, settings: { ...b.settings, theme_tokens: next } }));
	}

	function close() {
		if (snapshot.current) revert(snapshot.current);
		setOpen(false);
	}

	async function deploy() {
		setSaving(true);
		try {
			await api.putSettings({ theme_tokens: tokens });
			snapshot.current = { ...tokens };
			setOpen(false);
		} catch (e) {
			alert('Deploy failed — check your connection and try again.');
		}
		setSaving(false);
	}

	function onDragStart(e) {
		const panel = panelRef.current;
		if (!panel) return;
		const rect = panel.getBoundingClientRect();
		drag.current = { dx: e.clientX - rect.left, dy: e.clientY - rect.top };
		const move = (ev) => {
			panel.style.left = Math.max(4, Math.min(window.innerWidth - rect.width - 4, ev.clientX - drag.current.dx)) + 'px';
			panel.style.top = Math.max(4, Math.min(window.innerHeight - 80, ev.clientY - drag.current.dy)) + 'px';
			panel.style.right = 'auto';
			panel.style.bottom = 'auto';
		};
		const up = () => {
			window.removeEventListener('pointermove', move);
			window.removeEventListener('pointerup', up);
		};
		window.addEventListener('pointermove', move);
		window.addEventListener('pointerup', up);
	}

	if (!open) {
		return html`
			<button class="wb-fab" title="Color workbench" onClick=${openPanel}>
				<svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
					<circle cx="13.5" cy="6.5" r=".5" fill="currentColor"/><circle cx="17.5" cy="10.5" r=".5" fill="currentColor"/>
					<circle cx="8.5" cy="7.5" r=".5" fill="currentColor"/><circle cx="6.5" cy="12.5" r=".5" fill="currentColor"/>
					<path d="M12 2C6.5 2 2 6.5 2 12s4.5 10 10 10c.926 0 1.648-.746 1.648-1.688 0-.437-.18-.835-.437-1.125-.29-.289-.438-.652-.438-1.125a1.64 1.64 0 0 1 1.668-1.668h1.996c3.051 0 5.555-2.503 5.555-5.554C21.965 6.012 17.461 2 12 2z"/>
				</svg>
			</button>`;
	}

	return html`
		<div class="wb-panel" ref=${panelRef}>
			<div class="wb-head" onPointerDown=${onDragStart}>
				<span>Color workbench
					<span class="wb-build">${window.HABLAB_CONFIG && window.HABLAB_CONFIG.version ? 'v' + window.HABLAB_CONFIG.version : 'dev build'}</span>
				</span>
				<button class="wb-close" onClick=${close} title="Close (reverts un-deployed changes)">✕</button>
			</div>
			${COLOR_FIELDS.map((f) => html`
				<label class="wb-row" key=${f.key}>
					<span class="wb-label">${f.label}</span>
					<input type="color" value=${tokens[f.key] ?? FACTORY_TOKENS[f.key]} onInput=${(e) => setToken(f.key, e.target.value)} />
					<input class="wb-hex" value=${tokens[f.key] ?? FACTORY_TOKENS[f.key]} maxlength="7"
						onChange=${(e) => { const v = e.target.value.trim(); if (/^#[0-9a-fA-F]{6}$/.test(v)) setToken(f.key, v); else e.target.value = tokens[f.key] ?? FACTORY_TOKENS[f.key]; }} />
				</label>`)}
			<label class="wb-row wb-slider-row">
				<span class="wb-label">Drop shadow (desktop/tablet)</span>
				<input type="range" min="0" max="60" step="2" value=${tokens.shadow ?? FACTORY_TOKENS.shadow}
					onInput=${(e) => setToken('shadow', Number(e.target.value))} />
				<span class="wb-val">${tokens.shadow ?? FACTORY_TOKENS.shadow}</span>
			</label>
			<label class="wb-row wb-slider-row">
				<span class="wb-label">Shadow offset (left ↔ right)</span>
				<input type="range" min="-40" max="40" step="2" value=${tokens.shadowX ?? FACTORY_TOKENS.shadowX}
					onInput=${(e) => setToken('shadowX', Number(e.target.value))} />
				<span class="wb-val">${tokens.shadowX ?? FACTORY_TOKENS.shadowX}px</span>
			</label>
			${view === 'blocks' && html`
				<label class="wb-row wb-slider-row">
					<span class="wb-label">Circle size — Time Blocks only</span>
					<input type="range" min="9" max="22" step="0.5" value=${tokens.tbDotSize ?? FACTORY_TOKENS.tbDotSize}
						onInput=${(e) => setToken('tbDotSize', Number(e.target.value))} />
					<span class="wb-val">${(tokens.tbDotSize ?? FACTORY_TOKENS.tbDotSize).toFixed(1).replace(/\.0$/, '')}px</span>
				</label>`}
			${CIRCLE_SECTIONS[view] ? html`
				<label class="wb-row wb-slider-row">
					<span class="wb-label">Circle stroke — ${CIRCLE_SECTIONS[view]} only (grows inward)</span>
					<input type="range" min="0.5" max="8" step="0.25" value=${strokeFor(tokens, view)}
						onInput=${(e) => setStroke(Number(e.target.value))} />
					<span class="wb-val">${strokeFor(tokens, view).toFixed(2).replace(/\.?0+$/, '')}px</span>
				</label>` : html`
				<div class="wb-note">Circle stroke is set per section — open this panel on Habits or Time Blocks to adjust that section's circles.</div>`}
			<div class="wb-preview">
				<svg viewBox="0 0 24 24" width="26" height="26">
					<rect x="0" y="0" width="24" height="24" fill="var(--cell-bg)" />
					<circle cx="12" cy="12" r=${9 - Math.min(Math.max(strokeFor(tokens, view), 0.5), 9) / 2}
						fill="var(--circle-open)" stroke="var(--circle-outline)" stroke-width=${Math.min(Math.max(strokeFor(tokens, view), 0.5), 9)} />
				</svg>
				<svg viewBox="0 0 24 24" width="26" height="26">
					<rect x="0" y="0" width="24" height="24" fill="var(--cell-bg)" />
					<circle cx="12" cy="12" r="9" fill="var(--circle-fill)" />
				</svg>
				<span>live preview — the whole app updates as you edit</span>
			</div>
			<div class="wb-actions">
				<button class="wb-factory" title="Discard edits — back to the last deployed colors"
					onClick=${() => revert(snapshot.current)}>Reset</button>
				<span class="spacer"></span>
				<button class="wb-deploy" disabled=${saving} onClick=${deploy}>${saving ? 'Deploying…' : 'Deploy'}</button>
			</div>
		</div>`;
}
