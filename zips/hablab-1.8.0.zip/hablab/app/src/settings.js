// Settings sheet (§8): device recognition list + revoke, manual Export/Import
// JSON, and the automated-backup listing. Opened from the gear FAB.
import { html } from './h.js';
import { useState, useEffect } from 'preact/hooks';

export function SettingsSheet({ api, config, onClose }) {
	const [devices, setDevices] = useState(null);
	const [backups, setBackups] = useState(null);
	const [busy, setBusy] = useState('');

	useEffect(() => {
		api.listDevices().then((r) => setDevices(r.devices || [])).catch(() => setDevices([]));
		api.listBackups().then(setBackups).catch(() => setBackups({ backups: [] }));
	}, [api]);

	async function exportJSON() {
		setBusy('export');
		try {
			const data = await api.getExport();
			const blob = new Blob([JSON.stringify(data, null, 1)], { type: 'application/json' });
			const a = document.createElement('a');
			a.href = URL.createObjectURL(blob);
			a.download = 'hablab-export-' + new Date().toISOString().slice(0, 10) + '.json';
			a.click();
			URL.revokeObjectURL(a.href);
		} catch (e) {
			alert('Export failed.');
		}
		setBusy('');
	}

	function importJSON(e) {
		const file = e.target.files && e.target.files[0];
		e.target.value = '';
		if (!file) return;
		if (!confirm('Importing REPLACES all tracker data with the file contents (a safety backup is taken first on the live server). Continue?')) return;
		const reader = new FileReader();
		reader.onload = async () => {
			setBusy('import');
			try {
				await api.postImport(JSON.parse(reader.result));
				alert('Import complete — reloading.');
				location.reload();
			} catch (err) {
				alert('Import failed: ' + (err.message || 'invalid file'));
				setBusy('');
			}
		};
		reader.readAsText(file);
	}

	async function revoke(id) {
		if (!confirm('Revoke this device? It will need the passphrase again.')) return;
		await api.revokeDevice(id).catch(() => {});
		setDevices((list) => list.map((d) => (d.id === id ? { ...d, revoked: 1 } : d)));
	}

	return html`
		<div class="sheet-overlay" onClick=${onClose}>
			<div class="editor settings-sheet" onClick=${(e) => e.stopPropagation()}>
				<div class="editor-title">Settings ${config.mode !== 'live' ? `(${config.mode} mode)` : ''}</div>

				<h4 class="set-h">Data</h4>
				<div class="set-row">
					<button onClick=${exportJSON} disabled=${busy === 'export'}>${busy === 'export' ? 'Exporting…' : 'Export JSON'}</button>
					<label class="set-import ${busy === 'import' ? 'disabled' : ''}">
						${busy === 'import' ? 'Importing…' : 'Import JSON'}
						<input type="file" accept="application/json,.json" onChange=${importJSON} disabled=${busy === 'import'} />
					</label>
				</div>

				<h4 class="set-h">Automated backups</h4>
				${backups == null ? html`<div class="set-note">loading…</div>` : html`
					<div class="set-note">${backups.dir}</div>
					${(backups.backups || []).slice(0, 8).map((b) => html`
						<div class="set-backup" key=${b.file}>${b.file} · ${(b.bytes / 1024).toFixed(1)} kB · ${b.time}</div>`)}
					${!(backups.backups || []).length && config.mode === 'live' && html`<div class="set-note">none yet — first run within a day</div>`}
				`}

				<h4 class="set-h">Devices</h4>
				${devices == null ? html`<div class="set-note">loading…</div>` : devices.map((d) => html`
					<div class="set-device" key=${d.id}>
						<span>${d.label}${Number(d.revoked) ? ' (revoked)' : ''}</span>
						<span class="set-seen">${(d.last_seen || '').slice(0, 16)}</span>
						${!Number(d.revoked) && html`<button class="set-revoke" onClick=${() => revoke(d.id)}>revoke</button>`}
					</div>`)}

				<div class="editor-actions">
					<span class="spacer"></span>
					<button type="button" onClick=${onClose}>Close</button>
				</div>
			</div>
		</div>`;
}
