// Single place that binds htm to Preact, so every module imports the same `html`.
import { h } from 'preact';
import htm from 'htm';

export const html = htm.bind(h);
