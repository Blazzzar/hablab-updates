// Offline app shell. __HABLAB_VERSION__ is substituted by the plugin when it
// serves this file, so the cache version always tracks the plugin version.
// Strategy: network-first for EVERYTHING app-related (shell + modules +
// assets), falling back to cache offline. Cache-first would risk mixing old
// and new modules in one graph right after a deploy.
const CACHE_VERSION = 'hablab-__HABLAB_VERSION__';

self.addEventListener('install', () => {
	self.skipWaiting();
});

self.addEventListener('activate', (event) => {
	event.waitUntil(
		caches.keys().then((keys) =>
			Promise.all(keys.filter((k) => k !== CACHE_VERSION).map((k) => caches.delete(k)))
		).then(() => self.clients.claim())
	);
});

self.addEventListener('fetch', (event) => {
	if (event.request.method !== 'GET') return;
	const url = new URL(event.request.url);
	// Never cache the API.
	if (url.pathname.includes('/wp-json/')) return;

	const isShell = url.pathname.replace(/\/$/, '') === '/hablab.html';
	const isAsset = url.pathname.includes('/plugins/hablab/app/');
	if (!isShell && !isAsset) return;

	event.respondWith(
		fetch(event.request)
			.then((res) => {
				if (res.ok) {
					const copy = res.clone();
					caches.open(CACHE_VERSION).then((c) => c.put(event.request, copy));
				}
				return res;
			})
			// Offline: serve the cached copy; ignoreSearch lets an offline
			// launch survive a version-query mismatch.
			.catch(() => caches.match(event.request, { ignoreSearch: true })
				.then((hit) => hit || caches.match(event.request)))
	);
});
