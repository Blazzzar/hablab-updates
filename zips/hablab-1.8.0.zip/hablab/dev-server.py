#!/usr/bin/env python3
"""Local dev server for the tracker app (no WordPress needed — the app
boots in mock mode when HABLAB_CONFIG is absent). Usage: python3 dev-server.py [port]"""
import os, sys
from http.server import HTTPServer, SimpleHTTPRequestHandler

APP_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'app')
os.chdir(APP_DIR)

class Handler(SimpleHTTPRequestHandler):
    extensions_map = {
        **SimpleHTTPRequestHandler.extensions_map,
        '.js': 'text/javascript',
        '.mjs': 'text/javascript',
        '.webmanifest': 'application/manifest+json',
        '.woff2': 'font/woff2',
    }
    def end_headers(self):
        self.send_header('Cache-Control', 'no-store')
        super().end_headers()

port = int(sys.argv[1]) if len(sys.argv) > 1 else 8642
print(f'serving {APP_DIR} on http://localhost:{port}')
HTTPServer(('127.0.0.1', port), Handler).serve_forever()
