import { html } from '../h.js';
import { useState, useMemo, useEffect, useRef } from 'preact/hooks';
import { todayYMD } from '../lib/dates.js';
import { notifyFailure } from '../lib/notify.js';
import {
	MAX_SETS, WEEK_LETTERS, monthWeeks, weekIndexOf, clampWeek,
	rowHasContent, workoutDays, lastSession, ghostValues,
} from '../lib/workout.js';

/* Workout log (§ user feedback, modeled on the paper Workout Log sheet but
   vertical): one sheet per day, rows = exercise + 5 sets (weight/reps) +
   cardio time/dist. Only rows with content are persisted, so days you skip
   never appear in the archive.

   1.11.0 (exercise nav, prototype 2): a Monday-start week strip replaces the
   date chips and unfolds in place into the whole month; the sheet renders
   only rows with content plus ONE blank row ("+ EXERCISE" adds more); empty
   inputs ghost last session's numbers as placeholders. */

// The stored shape always keeps all 5 sets; the sheet just shows fewer by
// default and reveals the rest with "+ SET" (§ exercise trim).
const DEFAULT_SETS = 3;

const emptyData = () => ({ sets: Array.from({ length: MAX_SETS }, () => ['', '']), time: '', dist: '' });
const blankRow = (sort) => ({ id: null, sort, exercise_id: null, data: emptyData() });
const isBlank = (row) => !row.id && !rowHasContent(row);

/** Content rows plus exactly one blank row (1.11.0 — no more six-row padding). */
function withOneBlank(rows) {
	return rows.some(isBlank) ? rows : [...rows, blankRow(rows.length)];
}

/** Highest set index (1-based) that holds data across rows, so a day logged
 *  with 4–5 sets still shows them all even though the default is 3. */
function neededSets(rows) {
	let n = 0;
	for (const r of rows) {
		const sets = (r.data && r.data.sets) || [];
		for (let si = 0; si < sets.length; si++) {
			if ((sets[si][0] || '') !== '' || (sets[si][1] || '') !== '') n = Math.max(n, si + 1);
		}
	}
	return n;
}

function fmtDay(ymd) {
	const d = new Date(ymd + 'T12:00:00');
	return d.toLocaleDateString('en-US', { weekday: 'short', month: 'short', day: 'numeric' });
}

export function ExerciseView({ boot, setBoot, api, locked }) {
	const data = boot.month;
	const exercises = boot.exercises || [];
	const today = todayYMD();
	const isCurrentMonth = data.month === today.slice(0, 7);
	// Default to today's sheet; in an archived month, to its latest logged day.
	const loggedDates = useMemo(() => [...workoutDays(data.workouts)].sort(), [data.workouts]);
	const [selDate, setSelDate] = useState(null);
	const date = selDate && selDate.slice(0, 7) === data.month ? selDate
		: isCurrentMonth ? today
		: (loggedDates[loggedDates.length - 1] || data.month + '-01');
	// You can't log a future workout: archive lock OR a day after today
	// (e.g. the staged next month) leaves the sheet read-only.
	const readOnly = locked || date > today;

	// ---- Week strip / month grid (§1–2) ----
	const weeks = useMemo(() => monthWeeks(data.month), [data.month]);
	const [weekIdx, setWeekIdx] = useState(() => weekIndexOf(weeks, date));
	const [expanded, setExpanded] = useState(false);
	// A new day (tap, month change) brings its week into the strip.
	useEffect(() => { setWeekIdx(weekIndexOf(weeks, date)); }, [date, data.month]); // eslint-disable-line
	const wi = clampWeek(weekIdx, weeks);
	const logged = useMemo(() => workoutDays(data.workouts), [data.workouts]);

	function pickDay(d) {
		if (d > today) return; // future days are inert
		setSelDate(d);
		setWeekIdx(weekIndexOf(weeks, d));
		setExpanded(false); // picking from the month folds back to that day's week
	}

	// Local editable rows for the selected date: saved rows + one blank.
	const [rows, setRows] = useState([]);
	// How many set columns are on screen (3 by default; "+ SET" reveals up to 5;
	// a day that already has data in sets 4/5 auto-expands to show them).
	const [visibleSets, setVisibleSets] = useState(DEFAULT_SETS);
	const savedFor = useMemo(() => (data.workouts || []).filter((r) => r.entry_date === date).sort((a, b) => a.sort - b.sort), [data.workouts, date]);
	useEffect(() => {
		const base = withOneBlank(savedFor.map((r) => ({ id: r.id, sort: r.sort, exercise_id: r.exercise_id || null, data: { ...emptyData(), ...(r.data || {}) } })));
		setRows(base);
		setVisibleSets(Math.min(MAX_SETS, Math.max(DEFAULT_SETS, neededSets(base))));
	}, [date, data.month]); // eslint-disable-line

	const [picker, setPicker] = useState(null); // row index choosing an exercise
	const [managing, setManaging] = useState(false);
	const rowsRef = useRef(rows);
	rowsRef.current = rows;

	function patchWorkouts(updater) {
		setBoot((b) => ({ ...b, month: { ...b.month, workouts: updater(b.month.workouts || []) } }));
	}

	/** Persist one row if it has content (or already exists server-side).
	 *  Only typed values are sent — ghosts are placeholders, never values. */
	function persistRow(idx, nextRows) {
		if (readOnly) return; // archived month / future day is read-only
		const row = nextRows[idx];
		if (!row || (!row.id && !rowHasContent(row))) return; // empty + never saved → nothing to do
		api.putWorkoutRow({ id: row.id || undefined, date, sort: idx, exercise_id: row.exercise_id, data: row.data })
			.then((saved) => {
				if (!row.id && saved && saved.id) {
					setRows((rs) => rs.map((r, i) => (i === idx ? { ...r, id: saved.id } : r)));
					patchWorkouts((w) => [...w, saved]);
				} else if (saved && saved.id) {
					patchWorkouts((w) => w.map((r) => (r.id === saved.id ? saved : r)));
				}
			})
			.catch(notifyFailure);
	}

	function setCell(idx, mutate) {
		setRows((rs) => {
			const next = rs.map((r, i) => (i === idx ? { ...r, data: { ...r.data, sets: r.data.sets.map((s) => [...s]) } } : r));
			mutate(next[idx]);
			return next;
		});
	}

	function onCellBlur(idx) {
		// Defer past the pending state commit so a blur immediately after a
		// keystroke persists the keystroke, not the state before it.
		setTimeout(() => persistRow(idx, rowsRef.current), 0);
	}

	function chooseExercise(idx, exerciseId) {
		if (readOnly) return;
		setPicker(null);
		setRows((rs) => {
			const next = rs.map((r, i) => (i === idx ? { ...r, exercise_id: exerciseId } : r));
			// persist with the updated value (state not yet committed)
			const row = next[idx];
			if (row.id || rowHasContent(row)) {
				api.putWorkoutRow({ id: row.id || undefined, date, sort: idx, exercise_id: row.exercise_id, data: row.data })
					.then((saved) => {
						if (saved && saved.id) {
							if (!row.id) setRows((rs2) => rs2.map((r, i) => (i === idx ? { ...r, id: saved.id } : r)));
							patchWorkouts((w) => (w.some((x) => x.id === saved.id) ? w.map((x) => (x.id === saved.id ? saved : x)) : [...w, saved]));
						}
					})
					.catch(notifyFailure);
			}
			return next;
		});
	}

	async function removeRow(idx) {
		if (readOnly) return;
		const row = rows[idx];
		if (row.id) {
			try { await api.deleteWorkoutRow(row.id); } catch (e) { notifyFailure(); return; }
			patchWorkouts((w) => w.filter((r) => r.id !== row.id));
		}
		setRows((rs) => withOneBlank(rs.filter((_, i) => i !== idx)));
	}

	async function addExercise(name) {
		const row = await api.createExercise(name);
		setBoot((b) => ({
			...b,
			exercises: (b.exercises || []).some((x) => x.id === row.id)
				? b.exercises.map((x) => (x.id === row.id ? row : x))
				: [...(b.exercises || []), row],
		}));
		return row;
	}

	async function retireExercise(id) {
		if (!confirm('Remove this exercise from the master list? Logged workouts keep it.')) return;
		await api.updateExercise(id, { active: 0 }).catch(notifyFailure);
		setBoot((b) => ({ ...b, exercises: (b.exercises || []).filter((x) => x.id !== id) }));
	}

	const exName = (id) => exercises.find((x) => x.id === Number(id))?.name || '—';
	// "Last time" (§4): newest earlier session of the row's exercise — the
	// pre-month seed (exercise_prior) merged with this month's rows before the
	// selected day. Pure lookup, no round trip.
	const ghostsFor = (row) => (row.exercise_id
		? ghostValues(lastSession(row.exercise_id, date, data.workouts, data.exercise_prior))
		: null);

	// A plain render helper, not a component: a component defined inside this
	// one would get a new identity every render and remount the whole strip.
	function dayCell(cell, letter, key) {
		if (!cell) return html`<span key=${key} class="exw-cell exw-blank" aria-hidden="true"></span>`;
		const future = cell.date > today;
		const has = logged.has(cell.date);
		const cls = 'exw-cell'
			+ (cell.isMonday ? ' exw-mon' : '')
			+ (cell.date === date ? ' sel' : '')
			+ (cell.date === today ? ' today' : '')
			+ (future ? ' future' : '');
		return html`
			<button key=${key} type="button" class=${cls} disabled=${future} aria-pressed=${cell.date === date}
				aria-label=${fmtDay(cell.date) + (has ? ', workout logged' : '')}
				onClick=${() => pickDay(cell.date)}>
				${letter && html`<span class="exw-wd">${letter}</span>`}
				<span class=${'exw-dot' + (has ? ' on' : '')}></span>
				<span class="exw-dn">${cell.day}</span>
			</button>`;
	}

	const caret = expanded ? '▴' : '▾';
	const toggleMonth = () => {
		// Folding back without a pick returns to the selected day's week.
		if (expanded) setWeekIdx(weekIndexOf(weeks, date));
		setExpanded((e) => !e);
	};

	return html`
		<div class="ex">
			<div class="ex-head">
				<div>
					${/* Same idiom as the sheet's month label (tap the name to
					     pick): tap the day to unfold the month. */ ''}
					<button type="button" class="ex-date" aria-expanded=${expanded}
						title=${expanded ? 'Hide month' : 'Show month'} onClick=${toggleMonth}>
						${fmtDay(date)}<span class="ex-caret" aria-hidden="true">${caret}</span>
					</button>
					<div class="ex-sub">${date === today ? 'today’s sheet' : date > today ? 'upcoming — nothing to log yet' : 'archived sheet'}</div>
				</div>
				<button class="music-add" onClick=${() => setManaging(true)}>exercises…</button>
			</div>

			<div class=${'exw' + (expanded ? ' open' : '')}>
				${expanded
					? html`<span class="exw-gutter"></span>`
					: html`<button type="button" class="mn-btn exw-arrow" disabled=${wi <= 0}
							title="Previous week" aria-label="Previous week"
							onClick=${() => setWeekIdx(clampWeek(wi - 1, weeks))}>‹</button>`}
				<div class="exw-grid">
					${expanded && WEEK_LETTERS.map((l, i) => html`
						<span key=${'h' + i} class=${'exw-hd' + (i === 0 ? ' exw-mon' : '')}>${l}</span>`)}
					${(expanded ? weeks : [weeks[wi]]).map((week, w) => week.map((cell, i) =>
						dayCell(cell, expanded ? null : WEEK_LETTERS[i], w + '-' + i)))}
				</div>
				${expanded
					? html`<span class="exw-gutter"></span>`
					: html`<button type="button" class="mn-btn exw-arrow" disabled=${wi >= weeks.length - 1}
							title="Next week" aria-label="Next week"
							onClick=${() => setWeekIdx(clampWeek(wi + 1, weeks))}>›</button>`}
			</div>
			<button type="button" class="exw-handle" aria-expanded=${expanded} onClick=${toggleMonth}>
				${expanded ? '▴ hide month' : '▾ show month'}
			</button>

			${rows.map((row, idx) => {
				const g = ghostsFor(row);
				const ghost = (v, label) => ({ placeholder: v || label, class: v ? 'ex-ghosted' : '' });
				return html`
				<div key=${idx} class="ex-row">
					<div class="ex-row-head">
						<button class="ex-pick" onClick=${() => { if (!readOnly) setPicker(idx); }}>
							${row.exercise_id ? exName(row.exercise_id) : html`<span class="ex-ghost">choose exercise…</span>`}
						</button>
						${!readOnly && (row.id || rowHasContent(row)) && html`
							<button class="rt-del" title="Delete row" onClick=${() => removeRow(idx)}>✕</button>`}
					</div>
					<div class="ex-sets" style=${`--ex-cols:${visibleSets + 1}`}>
						${row.data.sets.slice(0, visibleSets).map(([w, r], si) => html`
							<div key=${si} class="ex-set">
								<div class="ex-set-label">set ${si + 1}</div>
								<input inputmode="decimal" ...${ghost(g && g.sets[si][0], 'wt')} value=${w} readonly=${readOnly}
									onInput=${(e) => setCell(idx, (rw) => { rw.data.sets[si][0] = e.target.value; })}
									onBlur=${() => onCellBlur(idx)} />
								<input inputmode="numeric" ...${ghost(g && g.sets[si][1], 'rep')} value=${r} readonly=${readOnly}
									onInput=${(e) => setCell(idx, (rw) => { rw.data.sets[si][1] = e.target.value; })}
									onBlur=${() => onCellBlur(idx)} />
							</div>`)}
						<div class="ex-set ex-cardio">
							<div class="ex-set-label">cardio</div>
							<input inputmode="decimal" ...${ghost(g && g.time, 'time')} value=${row.data.time} readonly=${readOnly}
								onInput=${(e) => setCell(idx, (rw) => { rw.data.time = e.target.value; })}
								onBlur=${() => onCellBlur(idx)} />
							<input inputmode="decimal" ...${ghost(g && g.dist, 'dist')} value=${row.data.dist} readonly=${readOnly}
								onInput=${(e) => setCell(idx, (rw) => { rw.data.dist = e.target.value; })}
								onBlur=${() => onCellBlur(idx)} />
						</div>
					</div>
				</div>`;
			})}

			<div class="ex-controls">
				${!readOnly && html`
					<button class="music-add ex-add-row" onClick=${() => setRows((rs) => [...rs, blankRow(rs.length)])}>+ exercise</button>`}
				${visibleSets < MAX_SETS && html`
					<button class="music-add ex-more-sets" onClick=${() => setVisibleSets((v) => Math.min(MAX_SETS, v + 1))}>+ set</button>`}
			</div>

			${picker != null && html`<${ExercisePicker}
				exercises=${exercises}
				onPick=${(id) => chooseExercise(picker, id)}
				onAdd=${async (name) => { const row = await addExercise(name); chooseExercise(picker, row.id); }}
				onClose=${() => setPicker(null)} />`}

			${managing && html`<${ExerciseManager}
				exercises=${exercises}
				onAdd=${addExercise}
				onRetire=${retireExercise}
				onClose=${() => setManaging(false)} />`}
		</div>`;
}

function ExercisePicker({ exercises, onPick, onAdd, onClose }) {
	const [adding, setAdding] = useState('');
	return html`
		<div class="sheet-overlay" onClick=${onClose}>
			<div class="editor" onClick=${(e) => e.stopPropagation()}>
				<div class="editor-title">Pick exercise</div>
				<div class="ex-list">
					${exercises.map((x) => html`
						<button key=${x.id} class="ex-option" onClick=${() => onPick(x.id)}>${x.name}</button>`)}
				</div>
				<form class="ex-add-form" onSubmit=${(e) => { e.preventDefault(); if (adding.trim()) { onAdd(adding.trim()); setAdding(''); } }}>
					<input placeholder="New exercise (added to master list)" value=${adding} onInput=${(e) => setAdding(e.target.value)} />
					<button type="submit">Add</button>
				</form>
				<div class="editor-actions"><span class="spacer"></span><button type="button" onClick=${onClose}>Cancel</button></div>
			</div>
		</div>`;
}

function ExerciseManager({ exercises, onAdd, onRetire, onClose }) {
	const [adding, setAdding] = useState('');
	return html`
		<div class="sheet-overlay" onClick=${onClose}>
			<div class="editor" onClick=${(e) => e.stopPropagation()}>
				<div class="editor-title">Master exercise list</div>
				${exercises.map((x) => html`
					<div key=${x.id} class="set-device">
						<span>${x.name}</span>
						<button class="set-revoke" onClick=${() => onRetire(x.id)}>remove</button>
					</div>`)}
				<form class="ex-add-form" onSubmit=${(e) => { e.preventDefault(); if (adding.trim()) { onAdd(adding.trim()); setAdding(''); } }}>
					<input placeholder="New exercise" value=${adding} onInput=${(e) => setAdding(e.target.value)} />
					<button type="submit">Add</button>
				</form>
				<div class="editor-actions"><span class="spacer"></span><button type="button" onClick=${onClose}>Done</button></div>
			</div>
		</div>`;
}
