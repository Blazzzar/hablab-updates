import { html } from './h.js';
import { useState, useEffect, useCallback, useRef } from 'preact/hooks';
import { createApi, AuthError } from './api.js';
import { applyTheme } from './theme.js';
import { HabitsView } from './views/habits.js';
import { BlocksView } from './views/blocks.js';
import { MusicView } from './views/music.js';
import { ExerciseView } from './views/exercise.js';
import { StatsView } from './views/stats.js';
import { Workbench } from './workbench.js';
import { SettingsSheet } from './settings.js';
import { monthAbbr, addMonths, todayYMD, maxMonth, minMonth } from './lib/dates.js';

/* Version stamped into the MODULE graph (1.9.4). The shell injects its own
   version via HABLAB_CONFIG, so comparing the two detects the stale-module
   trap that plagued 1.9.0–1.9.3: shell fresh, imported modules served from
   HTTP cache. Mismatch → the header badge shows both and asks for a hard
   reload. Bump this with the plugin version. */
export const APP_VERSION = '1.11.2';


const TABS = [
	{ id: 'habits', label: 'Habits' },
	{ id: 'blocks', label: 'Time Blocks' },
	{ id: 'music', label: 'Practice' },
	{ id: 'exercise', label: 'Exercise' },
	{ id: 'stats', label: 'Stats' },
];

export function App({ config }) {
	const [phase, setPhase] = useState('loading'); // loading | login | ready | error
	const [boot, setBoot] = useState(null);
	const [view, setView] = useState('habits');
	const [settingsOpen, setSettingsOpen] = useState(false);
	const [wbOpen, setWbOpen] = useState(false); // color workbench (gear menu)
	const [saveToast, setSaveToast] = useState(false);
	// Archive lock (§3): months before the current one are read-only. An unlock
	// applies to the viewed month only and is forgotten on navigation (per-browser).
	const [unlockedMonth, setUnlockedMonth] = useState(null);

	const apiRef = useRef(null);
	if (!apiRef.current) {
		apiRef.current = createApi({ ...config, onAuthError: () => setPhase('login') });
	}
	const api = apiRef.current;

	// Failed data writes surface here instead of vanishing silently.
	useEffect(() => {
		let t;
		const show = () => {
			setSaveToast(true);
			clearTimeout(t);
			t = setTimeout(() => setSaveToast(false), 4000);
		};
		window.addEventListener('hablab:save-failed', show);
		return () => { window.removeEventListener('hablab:save-failed', show); clearTimeout(t); };
	}, []);

	// Always-fresh boot for debounced writers (avoids stale-closure clobbers).
	const bootRef = useRef(null);
	bootRef.current = boot;

	const load = useCallback(async () => {
		setPhase('loading');
		try {
			const data = await api.bootstrap();
			applyTheme(data.settings && data.settings.theme_tokens);
			setBoot(data);
			const last = data.settings && data.settings.last_view;
			if (last && last.tracker) setView(last.tracker);
			setPhase('ready');
		} catch (e) {
			if (e instanceof AuthError) setPhase('login');
			else setPhase('error');
		}
	}, [api]);

	useEffect(() => { load(); }, [load]);

	// Persist which tracker I'm looking at (server-side last-state, debounced).
	// last_view is rebuilt when the timer FIRES, not when it's scheduled — a
	// month/song change inside the debounce window must not be clobbered.
	const persistView = useCallback((tracker) => {
		setView(tracker);
		clearTimeout(persistView._t);
		persistView._t = setTimeout(() => {
			const b = bootRef.current;
			if (!b) return;
			const last = { ...b.settings.last_view, tracker };
			b.settings.last_view = last;
			api.putSettings({ last_view: last }).catch(() => {});
		}, 400);
	}, [api]);

	// Archive (§8): browse the months that exist; data is date-keyed so it's
	// just a query. Bounds are enforced here, not only on the arrows, because
	// the native month picker can jump anywhere.
	async function changeMonth(ym) {
		if (!/^\d{4}-\d{2}$/.test(ym)) return;
		const b = bootRef.current;
		if (ym > maxMonth()) return;
		if (ym < minMonth(b && b.first_month, b && b.month && b.month.month)) return;
		try {
			const m = await api.getMonth(ym);
			setUnlockedMonth(null); // navigating away re-locks any unlocked archive
			setBoot((b) => {
				const last = { ...b.settings.last_view, month: ym };
				api.putSettings({ last_view: last }).catch(() => {});
				return { ...b, month: m, settings: { ...b.settings, last_view: last } };
			});
		} catch (e) { /* keep current month on failure */ }
	}

	function stepMonth(delta) {
		changeMonth(addMonths(boot.month.month, delta));
	}

	if (phase === 'login') return html`<${Login} api=${api} onSuccess=${load} />`;
	if (phase === 'loading') return html`<div class="loading">LOADING…</div>`;
	if (phase === 'error') return html`
		<div class="loading">Couldn’t reach the tracker API. <button onClick=${load}>Retry</button></div>`;

	const currentMonth = todayYMD().slice(0, 7);
	const viewMonth = boot.month.month;
	const isArchived = viewMonth < currentMonth;
	const locked = isArchived && unlockedMonth !== viewMonth;
	const atMaxMonth = viewMonth >= maxMonth();
	const floorMonth = minMonth(boot.first_month, viewMonth);
	const atMinMonth = viewMonth <= floorMonth;

	return html`
		${config.mode === 'demo' && html`<div class="demo-ribbon">DEMO</div>`}
		${saveToast && html`<div class="save-toast">Couldn’t save — check your connection and retry.</div>`}
		<div class="sheet-wrap">
			<div class=${'sheet' + (locked ? ' locked' : '')}>
				<${SheetHead} month=${boot.month.month} showNav=${view !== 'music'}
					locked=${locked} isArchived=${isArchived}
					shellVersion=${config.version}
					atMaxMonth=${atMaxMonth} atMinMonth=${atMinMonth} floorMonth=${floorMonth}
					onStep=${stepMonth} onPick=${changeMonth}
					onSettings=${() => setSettingsOpen(true)}
					onWorkbench=${() => setWbOpen(true)}
					onUnlock=${() => setUnlockedMonth(viewMonth)}
					onRelock=${() => setUnlockedMonth(null)} />
				${view === 'habits'
					? html`<${HabitsView} boot=${boot} setBoot=${setBoot} api=${api} config=${config} locked=${locked} />`
					: view === 'blocks'
					? html`<${BlocksView} boot=${boot} setBoot=${setBoot} api=${api} config=${config} locked=${locked} />`
					: view === 'music'
					? html`<${MusicView} boot=${boot} setBoot=${setBoot} api=${api} />`
					: view === 'exercise'
					? html`<${ExerciseView} boot=${boot} setBoot=${setBoot} api=${api} locked=${locked} />`
					: html`<${StatsView} boot=${boot} api=${api} />`}
			</div>
		</div>
		${settingsOpen && html`<${SettingsSheet} api=${api} config=${config} onClose=${() => setSettingsOpen(false)} />`}
		<nav class="tabbar">
			${TABS.map((t) => html`
				<button key=${t.id} class=${view === t.id ? 'active' : ''}
					onClick=${() => persistView(t.id)}>${t.label}</button>
			`)}
		</nav>
		${/* 1.10.0: opened from the gear menu — the palette FAB left the tab bar. */ ''}
		<${Workbench} boot=${boot} setBoot=${setBoot} api=${api} view=${view}
			open=${wbOpen} onClose=${() => setWbOpen(false)} />`;
}

function SheetHead({ month, showNav, locked, isArchived, shellVersion, atMaxMonth, atMinMonth, floorMonth, onStep, onPick, onSettings, onWorkbench, onUnlock, onRelock }) {
	const y = month.split('-')[0];
	const [menuOpen, setMenuOpen] = useState(false);
	// Version lives in the gear menu (1.10.0). `shellVersion` is what the
	// server just rendered; APP_VERSION is what this module graph actually is.
	// Equal → quiet line. Different → the browser is running cached modules,
	// so say so instead of quietly lying about the version.
	const stale = shellVersion && shellVersion !== APP_VERSION;
	// Month picker (1.11.1): the native <input type="month"> used to sit
	// transparently over the month name, but native date inputs won't shrink
	// below their intrinsic width, so on Safari/iOS it overflowed onto BOTH
	// arrows and swallowed their taps. Now the input is inert
	// (pointer-events: none) and the month name is a real button that opens
	// the picker programmatically — showPicker() where supported, else a
	// synthetic click. The arrows are plain back/next again.
	const pickerRef = useRef(null);
	function openPicker() {
		const el = pickerRef.current;
		if (!el) return;
		if (typeof el.showPicker === 'function') {
			try { el.showPicker(); return; } catch (e) { /* fall through */ }
		}
		el.focus();
		el.click();
	}
	return html`
		<div class="sheet-head">
			<span class="year-badge">${y}</span>
			${showNav && html`
				<span class="month-nav">
					<button class="mn-btn" disabled=${atMinMonth}
						title=${atMinMonth ? 'Nothing tracked before this month' : 'Previous month'}
						onClick=${() => onStep(-1)}>‹</button>
					<button type="button" class="mn-label" title="Jump to month" onClick=${openPicker}>${monthAbbr(month)}</button>
					<input ref=${pickerRef} class="mn-picker" type="month" tabindex="-1" aria-hidden="true"
						style="position:absolute;left:32px;right:32px;top:0;bottom:0;width:auto;min-width:0;opacity:0;pointer-events:none;border:0;padding:0;margin:0"
						value=${month} min=${floorMonth} max=${maxMonth()}
						onChange=${(e) => e.target.value && onPick(e.target.value)} />
					<button class="mn-btn" disabled=${atMaxMonth}
						title=${atMaxMonth ? 'Next month is as far ahead as the sheet goes' : 'Next month'}
						onClick=${() => onStep(1)}>›</button>
				</span>`}
			${showNav && locked && html`<span class="locked-tag" title="Archived month — read-only">LOCKED</span>`}
			<span class="head-spacer"></span>
			<div class="gear-wrap">
				<button class="gear-btn" title="Menu" aria-haspopup="true" aria-expanded=${menuOpen} onClick=${() => setMenuOpen((o) => !o)}>
					<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
					<path d="M12.22 2h-.44a2 2 0 0 0-2 2v.18a2 2 0 0 1-1 1.73l-.43.25a2 2 0 0 1-2 0l-.15-.08a2 2 0 0 0-2.73.73l-.22.38a2 2 0 0 0 .73 2.73l.15.1a2 2 0 0 1 1 1.72v.51a2 2 0 0 1-1 1.74l-.15.09a2 2 0 0 0-.73 2.73l.22.38a2 2 0 0 0 2.73.73l.15-.08a2 2 0 0 1 2 0l.43.25a2 2 0 0 1 1 1.73V20a2 2 0 0 0 2 2h.44a2 2 0 0 0 2-2v-.18a2 2 0 0 1 1-1.73l.43-.25a2 2 0 0 1 2 0l.15.08a2 2 0 0 0 2.73-.73l.22-.39a2 2 0 0 0-.73-2.73l-.15-.08a2 2 0 0 1-1-1.74v-.5a2 2 0 0 1 1-1.74l.15-.09a2 2 0 0 0 .73-2.73l-.22-.38a2 2 0 0 0-2.73-.73l-.15.08a2 2 0 0 1-2 0l-.43-.25a2 2 0 0 1-1-1.73V4a2 2 0 0 0-2-2z"/><circle cx="12" cy="12" r="3"/>
				</svg>
				</button>
				${menuOpen && html`
					<div class="gear-menu-backdrop" onClick=${() => setMenuOpen(false)}></div>
					<div class="gear-menu">
						<button type="button" onClick=${() => { setMenuOpen(false); onSettings(); }}>Settings…</button>
						<button type="button" onClick=${() => { setMenuOpen(false); onWorkbench(); }}>Color workbench…</button>
						${showNav && isArchived && (locked
							? html`<button type="button" onClick=${() => { setMenuOpen(false); onUnlock(); }}>Unlock this month</button>`
							: html`<button type="button" onClick=${() => { setMenuOpen(false); onRelock(); }}>Lock this month</button>`)}
						${stale
							? html`<div class="gear-version stale"
									title=${`Stale app: running v${APP_VERSION} but the server has v${shellVersion}. Hard-reload (Cmd+Shift+R) to update.`}
								>v${APP_VERSION} → v${shellVersion} · RELOAD</div>`
							: html`<div class="gear-version">HAB•LAB v${APP_VERSION}</div>`}
					</div>`}
			</div>
		</div>`;
}

function Login({ api, onSuccess }) {
	const [pass, setPass] = useState('');
	const [err, setErr] = useState('');
	const [busy, setBusy] = useState(false);

	async function submit(e) {
		e.preventDefault();
		setBusy(true);
		setErr('');
		try {
			await api.login(pass);
			onSuccess();
		} catch (e2) {
			setErr(e2 instanceof AuthError ? 'Wrong passphrase.' : 'Login failed — try again.');
			setBusy(false);
		}
	}

	return html`
		<div class="login-wrap">
			<form class="login-card" onSubmit=${submit}>
				<h1>HAB•LAB</h1>
				<input type="password" placeholder="Passphrase" autofocus
					value=${pass} onInput=${(e) => setPass(e.target.value)} />
				<button disabled=${busy}>${busy ? 'Checking…' : 'Unlock'}</button>
				${err && html`<div class="login-error">${err}</div>`}
			</form>
		</div>`;
}
