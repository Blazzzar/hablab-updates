# HAB•LAB changelog

## 1.11.2
The hidden month-picker input is now hidden by an inline style as well as the stylesheet, so a browser holding a stale `styles.css` alongside fresh JavaScript can't render it as a visible "2026-08" box beside the month name (seen once on the beta channel). No behavior change.

## 1.11.1
Month arrows are plain back/next again. The month picker was a transparent native `<input type="month">` laid over the month name, and native date inputs won't shrink below their intrinsic width — on Safari/iOS it overflowed onto both `‹ ›` buttons and swallowed their taps, opening the picker instead of stepping. Now the month name is a real button that opens the picker programmatically (`showPicker()` where supported, synthetic click otherwise) and the input is inert (`pointer-events: none`), parked under the name only so the picker anchors there.

## 1.11.0
Exercise navigation rework (Chris's prototype 2). The wrapping row of date chips is gone: under the day heading sits a Monday→Sunday week strip — weekday letter, dot, day number per cell; solid dot = a workout logged that day, open ring = nothing; selected day in the label colour with a 2px ink outline, today's number underlined bold, Mondays shaded like the sheet's boxed Mondays, days after today dimmed and inert (you can't log a future workout — a staged next-month sheet is read-only), out-of-month days blank. `‹ ›` page a week at a time and stop at the viewed month's first/last week; changing months stays with the sheet's month selector. Tapping the day heading (now with a `▾`, the same tap-the-label idiom as the month name) or the quiet `▾ SHOW MONTH` handle unfolds the strip in place into every Monday-start week of the month under an M–S header (gutters blank, no arrows, no overlay — the sheet stays mounted); picking a day there selects it and folds back to its week. The sheet no longer pads to six empty rows: it shows only rows with content plus one blank, `+ EXERCISE` appends another blank, and `+ SET` still reveals sets 4–5. Empty weight/rep/time/dist inputs ghost the previous session of that exercise (newest row dated before the selected day) as italic ~35% placeholders — never values, so an untouched ghost saves nothing; an exercise's first-ever session simply has no ghost. Server: the month payload gains `exercise_prior` — the newest pre-month row per active exercise from one grouped query — which the client merges with the month's own rows, so picking a day needs no round trip; the demo mock mirrors it and seeds ten August workout days. Week math and the "newest candidate" pick live in a new pure `lib/workout.js`, unit-tested under node from `tests.php` alongside new PHP checks for `exercise_prior`.

## 1.10.1
Backward navigation now stops at the earliest month that holds data, so the `‹` arrow can't walk into months that never existed. The floor is computed server-side (`first_data_month()` — MIN across habit entries, weights, time-block entries and workout rows) and shipped in the bootstrap payload; the arrow dims there, the native month picker gets a matching `min`, and `changeMonth()` enforces it so the picker can't jump below the floor either. An empty install floors at the current month, and a view that somehow sits below the floor can still navigate out. Demo mock mirrors the server rule.

## 1.10.0
Sheet-header rework from Chris's markup. Months now read as JAN FEB MAR APRIL MAY JUNE JULY AUG SEPT OCT NOV DEC — in the grid's first-column header (full names overflowed its two-column span and clipped to "VEMBER") and in the month selector, so both match. Forward navigation stops one month past the current one: the next sheet stays reachable for staging habits before tracking starts, but the calendar can't wander into empty future months — the `›` arrow dims at the cap, the native month picker gets a `max`, and `changeMonth()` enforces it too so the picker can't jump the fence. The running version and the color workbench both moved into the gear menu: the palette button is gone from the tab bar (five tabs now), the workbench panel opens from "Color workbench…", and the version sits as a footer line that still flips to an inked `v<old> → v<new> · RELOAD` when the module graph is stale against the served shell.

## 1.9.4
Running version shown right of the month selector — and it's honest: the badge reads `APP_VERSION` from the front-end module graph and compares it with the version the server just rendered into the page shell. Match → quiet `v1.9.4`. Mismatch → an inked `v<old> → v<new> · RELOAD` chip, because that state means the browser is executing cached modules while the shell is current (the trap behind "I updated but nothing changed"). A build gate keeps `APP_VERSION` and the plugin version in lockstep so the tripwire can't cry wolf.

## 1.9.3
Cache fix + month-scoped remove. (1) Root cause of every "update didn't take effect" report: nested module imports (`main.js → ./app.js → ./views/*.js`) carry no `?v=` cache-buster, so browsers kept serving stale JS from HTTP cache after updates — this is why 1.9.2's badge superscripts didn't appear. The service worker now fetches with `cache: 'no-cache'` (forced revalidation, cheap 304s) and `app/.htaccess` applies the same rule for non-SW traffic. ONE final hard reload (Cmd+Shift+R) is needed after this update; after that, updates propagate on a normal reload. (2) Removing a habit is now month-scoped: on the viewed sheet's month, a habit born that month (or later) is hard-deleted as before, but a habit with earlier history is RETIRED instead — `ends_on` set to the last day of the previous month, entries from the viewed month forward deleted — so deleting a July habit from the August sheet no longer touches July. Unit-tested (`remove_plan`), demo mock mirrors the server.

## 1.9.2
Multi-count habits show their daily target as a badge superscript — Brush Teeth ×2 with badge B reads B² (the retired twin-column numbering's look, now meaning "times per day"; a merged twin's leftover trailing digit is folded into the letter so sups don't stack). The habit sheet narrows to 10 columns: `habit_max` seeds at 10 and a one-time migration nudges a stored 12 down to 10 (wider, squarer cells; deliberate API changes stick).

## 1.9.1
Editor dialogs (Edit/Add Habit, time-block categories, exercise pickers, gear menu) now open centered in the viewport instead of bottom-justified — the bottom-sheet placement landed too far from the control that opened them. CSS-only: `.sheet-overlay` centers with safe-area padding; `.editor` gets its full border back and even padding.

## 1.9.0
Multi-count habits: a habit can require several completions per day. Edit Habit gains a "Times per day" field (1–9); `habit_entries.done` is now the day's completion count (schema widened to INT via the version-bump self-heal, `habits.target_count` added), and `SUM(done)` stays continuous with the old two-column era after a merge. Tap cycles the count with wrap (tap at full → 0); confetti fires only on the tap that reaches the target. New CLOCK-FILL dot: 0/N open ring, N/N solid ink dot, partial → open ring plus a clockwise pie wedge (count/target), all in the existing circle theme colours. "Day success" (`done >= target_count`) drives streaks, success-rate stats, and the staleness reminders' last-completed query, so a ×2 habit at 1/2 today is still stale-from-yesterday. New "Merge another column into this habit" action folds a second habit's per-date counts into the survivor (safety backup first) and deletes the absorbed column — the tool for retiring the old B¹/B² twin columns. REMOVE is now a hard delete (habit row + all its entries) so a removed column leaves no ghost on reload. Archive lock: months before the current one are read-only (circles, weights, and habit add/edit/remove disabled) with a quiet LOCKED tag; the gear menu's "Unlock this month" re-enables the viewed archive until you navigate away (per-browser, not persisted). Exercise view slims down: 3 set columns and 6 rows by default, "+ SET" reveals sets 4–5 (auto-shown when a row already has data there) and "add row" appends more.

## 1.8.0
Full identity rename: plugin slug/basename is now `hablab/hablab.php`, and every internal identifier moved off the old name — classes `Hablab_*`, constants `HABLAB_*`, `wp_hablab_*` tables, REST namespace `hablab/v1`, auth header `X-Hablab-Token`, options/hooks/nonces `hablab_*`, SW cache + backup format `hablab-*`, repos `Blazzzar/hablab` + `hablab-updates`. A guarded one-time migration renames the live site's old tables in place (data preserved), carries the passphrase hash over, moves the backups folder, clears old cron events, and deactivates the old plugin entry. Old-format backup files remain importable; device sessions and iPhone PWA installs need a one-time re-login/re-add.

## 1.7.0
Self-hosted GitHub update pipeline (STEMMAXXER/WeIdea recipe): `Hablab_Updater` + `Hablab_Updater_Admin` check the public channel manifest on GitHub Pages and ride WordPress's native update flow — one-click updates, stable/beta tracks (default stable), "Check for updates" / channel-switch / one-click rollback links in the plugin row, `Update URI` header. New `bin/build-zip.sh` (version + changelog gates, php -l) and `bin/publish-channel.sh stable|beta` (updates the `hablab-updates` shelf: manifest + zips, retains last 5, prunes, pushes). Added `readme.txt` + this changelog. This build is the LAST manual zip upload.

## 1.6.0
Renamed to HAB•LAB; app moved from `/tracker` to `/hablab.html` (demo `/hablab-demo.html`), 301 redirects from all legacy URLs. PWA manifest/scope/start_url updated, service worker served from root (`/hablab-sw.js`), admin + email strings renamed ("HAB•LAB nudge: …"), rewrite flush added to the version-bump self-heal.

## 1.5.0
Habit-staleness email reminders (feature 01): daily WP-Cron digest via `wp_mail()`, rules editor (individual or bundled targets, threshold + cooldown) with Send-test and Preview on Settings → Tracker; config + send state in settings rows so they ride along in backups. 45-assertion standalone test harness.

## 1.4.3
Workbench header shows the build number (from HABLAB_CONFIG.version; "dev build" locally).

## 1.4.2
Workbench: horizontal shadow offset slider (shadowX token, −40..+40px).

## 1.4.1
Category headers: badge and/or icon with three states; songs.created_at backfill for pre-1.1 songs.

## 1.4.0
Time-block circles 15% bigger with size slider; full-name + icon category labels; custom tooth/meditation icons; label-box background token; iOS burst/confetti fixes.
