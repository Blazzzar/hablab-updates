# HAB•LAB changelog

## 1.10.0
Sheet-header rework from Chris's markup. Months now read as JAN FEB MAR APRIL MAY JUNE JULY AUG SEPT OCT NOV DEC — in the grid's first-column header (full names overflowed its two-column span and clipped to "VEMBER") and in the month selector, so both match. Forward navigation stops one month past the current one: the next sheet stays reachable for staging habits before tracking starts, but the calendar can't wander into empty future months — the `›` arrow dims at the cap, the native month picker gets a `max`, and `changeMonth()` enforces it too so the picker can't jump the fence. The running version and the color workbench both moved into the gear menu: the palette button is gone from the tab bar (five tabs now), the workbench panel opens from "Color workbench…", and the version sits as a footer line that still flips to an inked `v<old> → v<new> · RELOAD` when the module graph is stale against the served shell.

## 1.9.4
Running version shown right of the month selector — and it's honest: the badge reads `APP_VERSION` from the front-end module graph and compares it with the version the server just rendered into the page shell. Match → quiet `v1.9.4`. Mismatch → an inked `v<old> → v<new> · RELOAD` chip, because that state means the browser is executing cached modules while the shell is current (the trap behind "I updated but nothing changed"). A build gate keeps `APP_VERSION` and the plugin version in lockstep so the tripwire can't cry wolf.

## 1.9.3
Cache fix + month-scoped remove. (1) Root cause of every "update didn't take effect" report: nested module imports (`main.js → ./app.js → ./views/*.js`) carry no `?v=` cache-buster, so browsers kept serving stale JS from HTTP cache after updates — this is why 1.9.2's badge superscripts didn't appear. The service worker now fetches with `cache: 'no-cache'` (forced revalidation, cheap 304s) and `app/.htaccess` applies the same rule for non-SW traffic. ONE final hard reload (Cmd+Shift+R) is needed after this update; after that, updates propagate on a normal reload. (2) Removing a habit is now month-scoped: on the viewed sheet's month, a habit born that month (or later) is hard-deleted as before, but a habit with earlier history is RETIRED instead — `ends_on` set to the last day of the previous month, entries from the viewed month forward deleted — so deleting a July habit from the August sheet no longer touches July. Unit-tested (`remove_plan`), demo mock mirrors the server.

## 1.9.2
Multi-count habits show their daily target as a badge superscript — Brush Teeth ×2 with badge B reads B² (the retired twin-column numbering's look, now meaning "times per day"; a merged twin's leftover trailing digit is folded into the letter so sups don't stack). The habit sheet narrows to 10 columns: `habit_max` seeds at 10 and a one-time migration nudges a stored 12 down to 10 (wider, squarer cells; deliberate API changes stick).

## 1.9.1
Editor dialogs (Edit/Add Habit, time-block categories, exercise pickers, gear menu) now open centered in the viewport instead of bottom-justified — the bottom-sheet placement landed too far from the control that opened them. CSS-only: `.sheet-overlay` centers with safe-area padding; `.editor` gets its full border back and even padding.

## 1.9.0
Multi-count habits: a habit can require several completions per day. Edit Habit gains a "Times per day" field (1–9); `habit_entries.done` is now the day's completion count (schema widened to INT via the version-bump self-heal, `habits.target_count` added), and `SUM(done)` stays continuous with the old two-column era after a merge. Tap cycles the count with wrap (tap at full → 0); confetti fires only on the tap that reaches the target. New CLOCK-FILL dot: 0/N open ring, N/N solid ink dot, partial → open ring plus a clockwise pie wedge (count/target), all in the existing circle theme colours. "Day success" (`done >= target_count`) drives streaks, success-rate stats, and the staleness reminders' last-completed query, so a ×2 habit at 1/2 today is still stale-from-yesterday. New "Merge another column into this habit" action folds a second habit's per-date counts into the survivor (safety backup first) and deletes the absorbed column — the tool for retiring the old B¹/B² twin columns. REMOVE is now a hard delete (habit row + all its entries) so a removed column leaves no ghost on reload. Archive lock: months before the current one are read-only (circles, weights, and habit add/edit/remove disabled) with a quiet LOCKED tag; the gear menu's "Unlock this month" re-enables the viewed archive until you navigate away (per-browser, not persisted). Exercise view slims down: 3 set columns and 6 rows by default, "+ SET" reveals sets 4–5 (auto-shown when a row already has data there) and "add row" appends more.

## 1.8.0
Full identity rename: plugin slug/basename is now `hablab/hablab.php`, and every internal identifier moved off the old name — classes `Hablab_*`, constants `HABLAB_*`, `wp_hablab_*` tables, REST namespace `hablab/v1`, auth header `X-Hablab-Token`, options/hooks/nonces `hablab_*`, SW cache + backup format `hablab-*`, repos `Blazzzar/hablab` + `hablab-updates`. A guarded one-time migration renames the live site's old tables in place (data preserved), carries the passphrase hash over, moves the backups folder, clears old cron events, and deactivates the old plugin entry. Old-format backup files remain importable; device sessions and iPhone PWA installs need a one-time re-login/re-add.

## 1.7.0
Self-hosted GitHub update pipeline (STEMMAXXER/WeIdea recipe): `Hablab_Updater` + `Hablab_Updater_Admin` check the public channel manifest on GitHub Pages and ride WordPress's native update flow — one-click updates, stable/beta tracks (default stable), "Check for updates" / channel-switch / one-click rollback links in the plugin row, `Update URI` header. New `bin/build-zip.sh` (version + changelog gates, php -l) and `bin/publish-channel.sh stable|beta` (updates the `hablab-updates` shelf: manifest + zips, retains last 5, prunes, pushes). Added `readme.txt` + this changelog. This build is the LAST manual zip upload.

## 1.6.0
Renamed to HAB•LAB; app moved from `/tracker` to `/hablab.html` (demo `/hablab-demo.html`), 301 redirects from all legacy URLs. PWA manifest/scope/start_url updated, service worker served from root (`/hablab-sw.js`), admin + email strings renamed ("HAB•LAB nudge: …"), rewrite flush added to the version-bump self-heal.

## 1.5.0
Habit-staleness email reminders (feature 01): daily WP-Cron digest via `wp_mail()`, rules editor (individual or bundled targets, threshold + cooldown) with Send-test and Preview on Settings → Tracker; config + send state in settings rows so they ride along in backups. 45-assertion standalone test harness.

## 1.4.3
Workbench header shows the build number (from HABLAB_CONFIG.version; "dev build" locally).

## 1.4.2
Workbench: horizontal shadow offset slider (shadowX token, −40..+40px).

## 1.4.1
Category headers: badge and/or icon with three states; songs.created_at backfill for pre-1.1 songs.

## 1.4.0
Time-block circles 15% bigger with size slider; full-name + icon category labels; custom tooth/meditation icons; label-box background token; iOS burst/confetti fixes.
