// API layer. Live mode talks to the WP REST API with a device token;
// dev/demo modes run the same interface against in-memory sample data,
// so the UI code never knows the difference.

const TOKEN_KEY = 'hablab_token';

export class AuthError extends Error {}

/* MySQL via wpdb returns every column as a STRING; the mock uses real numbers.
   Comparing "2" === 2 fails silently (live-only bug: selecting the second song
   showed the first). Normalize all id-ish fields at the API boundary so view
   code can trust numbers everywhere. */
const NUMERIC_FIELDS = new Set([
	'id', 'sort', 'active', 'capacity', 'count', 'done', 'target_count', 'blocks_filled', 'blocks_mask', 'revoked',
	'habit_id', 'category_id', 'song_id', 'tracker_id', 'instrument_id', 'exercise_id',
]);

function normalize(value) {
	if (Array.isArray(value)) return value.map(normalize);
	if (value && typeof value === 'object') {
		const out = {};
		for (const [k, v] of Object.entries(value)) {
			if (NUMERIC_FIELDS.has(k) && v != null && v !== '' && isFinite(v)) out[k] = Number(v);
			else if (k === 'data' && typeof v === 'string') {
				try { out[k] = JSON.parse(v); } catch (e) { out[k] = null; }
			} else if (v && typeof v === 'object') out[k] = normalize(v);
			else out[k] = v;
		}
		return out;
	}
	return value;
}

export function createApi(config) {
	if (config && config.mode === 'live') return realApi(config);
	return mockApi(config || { mode: 'dev' });
}

/* ---------------- live adapter ---------------- */

function realApi(config) {
	const base = config.api.replace(/\/$/, '');

	async function call(method, path, body) {
		const headers = { 'Content-Type': 'application/json' };
		const token = localStorage.getItem(TOKEN_KEY);
		if (token) headers['X-Hablab-Token'] = token;
		// Cache-buster on reads: host proxy caches treat our header-token
		// requests as anonymous and may serve one device's stale response to
		// another. A unique URL per read defeats caches that ignore headers.
		let url = base + path;
		if (method === 'GET') {
			url += (url.includes('?') ? '&' : '?') + '_ts=' + Date.now();
		}
		const res = await fetch(url, {
			method,
			headers,
			cache: 'no-store',
			body: body === undefined ? undefined : JSON.stringify(body),
		});
		if (res.status === 401) {
			// Mid-session revocation/expiry: route the app back to login even
			// when the caller swallows the rejection (fire-and-forget writes).
			if (config.onAuthError) config.onAuthError();
			throw new AuthError('unauthorized');
		}
		if (!res.ok) throw new Error('API error ' + res.status);
		return normalize(await res.json());
	}

	return {
		mode: 'live',
		hasToken: () => !!localStorage.getItem(TOKEN_KEY),
		async login(passphrase) {
			const out = await call('POST', '/auth/login', { passphrase, label: deviceLabel() });
			localStorage.setItem(TOKEN_KEY, out.token);
			return true;
		},
		logout() { localStorage.removeItem(TOKEN_KEY); },
		bootstrap: (month) => call('GET', '/bootstrap' + (month ? '?month=' + month : '')),
		getMonth: (month) => call('GET', '/month?month=' + month),
		putSettings: (patch) => call('PUT', '/settings', patch),
		listDevices: () => call('GET', '/devices'),
		revokeDevice: (id) => call('DELETE', '/devices/' + id),
		createHabit: (habit) => call('POST', '/habits', habit),
		updateHabit: (id, patch) => call('PUT', '/habits/' + id, patch),
		deleteHabit: (id) => call('DELETE', '/habits/' + id),
		mergeHabits: (survivorId, absorbedId) => call('POST', '/habits/' + survivorId + '/merge', { from_id: absorbedId }),
		// `done` is the day's completion count now (0..target_count), not a flag.
		putHabitEntry: (date, habitId, done) => call('PUT', '/habit-entries', { date, habit_id: habitId, done }),
		putWeight: (date, lbs) => call('PUT', '/weight', { date, lbs }),
		createCategory: (cat) => call('POST', '/categories', cat),
		updateCategory: (id, patch) => call('PUT', '/categories/' + id, patch),
		deleteCategory: (id) => call('DELETE', '/categories/' + id),
		putTimeblockEntry: (date, categoryId, mask) => call('PUT', '/timeblock-entries', { date, category_id: categoryId, blocks_mask: mask }),
		createSong: (title) => call('POST', '/songs', { title }),
		updateSong: (id, patch) => call('PUT', '/songs/' + id, patch),
		deleteSong: (id) => call('DELETE', '/songs/' + id),
		createTracker: (songId, tracker) => call('POST', '/songs/' + songId + '/trackers', tracker),
		updateTracker: (id, patch) => call('PUT', '/trackers/' + id, patch),
		deleteTracker: (id) => call('DELETE', '/trackers/' + id),
		addPlaythrough: (trackerId) => call('POST', '/trackers/' + trackerId + '/playthroughs'),
		removePlaythrough: (trackerId) => call('DELETE', '/trackers/' + trackerId + '/playthroughs'),
		createInstrument: (name) => call('POST', '/instruments', { name }),
		createExercise: (name) => call('POST', '/exercises', { name }),
		updateExercise: (id, patch) => call('PUT', '/exercises/' + id, patch),
		putWorkoutRow: (row) => call('PUT', '/workout-rows', row),
		deleteWorkoutRow: (id) => call('DELETE', '/workout-rows/' + id),
		getAnalytics: () => call('GET', '/analytics'),
		getExport: () => call('GET', '/export'),
		postImport: (data) => call('POST', '/import', data),
		listBackups: () => call('GET', '/backups'),
	};
}

function deviceLabel() {
	const ua = navigator.userAgent;
	if (/iPhone/.test(ua)) return 'iPhone';
	if (/iPad/.test(ua)) return 'iPad';
	if (/Android/.test(ua)) return 'Android';
	if (/Macintosh/.test(ua)) return 'Mac';
	if (/Windows/.test(ua)) return 'Windows PC';
	return 'Device';
}

/* ---------------- mock adapter (dev + demo) ---------------- */

// Sample data mirrors the July 2026 paper sheets, so dev/demo look real.
// Demo mode additionally seeds music data so every capability shows.
function sampleData(mode) {
	const habits = [
		{ id: 1, full_name: 'Brush Teeth', badge: 'B1', icon: null, target_count: 1, sort: 0, active: 1 },
		{ id: 2, full_name: 'Brush Teeth', badge: 'B2', icon: null, target_count: 1, sort: 1, active: 1 },
		{ id: 3, full_name: 'Floss Teeth', badge: 'FL', icon: null, target_count: 1, sort: 2, active: 1 },
		{ id: 4, full_name: 'Stretch', badge: 'S1', icon: null, target_count: 1, sort: 3, active: 1 },
		{ id: 5, full_name: 'Stretch', badge: 'S2', icon: null, target_count: 1, sort: 4, active: 1 },
		{ id: 6, full_name: 'Exercise', badge: 'EX', icon: null, target_count: 1, sort: 5, active: 1 },
		{ id: 7, full_name: 'Meditate', badge: 'ME', icon: null, target_count: 1, sort: 6, active: 1 },
		{ id: 8, full_name: 'Art Making', badge: 'AM', icon: null, target_count: 1, sort: 7, active: 1 },
		{ id: 9, full_name: 'Read', badge: 'RE', icon: null, target_count: 1, sort: 8, active: 1 },
		{ id: 10, full_name: 'Practice Music', badge: '', icon: 'music', target_count: 1, sort: 9, active: 1 },
	];
	const categories = [
		{ id: 1, label: 'MALL', badge: 'MALL', icon: null, capacity: 16, sort: 0, active: 1 },
		{ id: 2, label: '', badge: '', icon: null, capacity: 10, sort: 1, active: 1 },
		{ id: 3, label: 'RET', badge: 'RET', icon: null, capacity: 6, sort: 2, active: 1 },
		{ id: 4, label: '', badge: '', icon: null, capacity: 6, sort: 3, active: 1 },
		{ id: 5, label: 'MUSIC', badge: 'MUSIC', icon: null, capacity: 6, sort: 4, active: 1 },
	];
	const habit_entries = [];
	for (let d = 1; d <= 7; d++) {
		for (const h of habits) {
			habit_entries.push({ entry_date: `2026-07-0${d}`, habit_id: h.id, done: 1 });
		}
	}
	habit_entries.push({ entry_date: '2026-07-08', habit_id: 6, done: 1 });
	const weights = [
		{ entry_date: '2026-07-01', lbs: '209.80' }, { entry_date: '2026-07-02', lbs: '208.20' },
		{ entry_date: '2026-07-03', lbs: '208.20' }, { entry_date: '2026-07-04', lbs: '209.80' },
		{ entry_date: '2026-07-05', lbs: '211.20' }, { entry_date: '2026-07-06', lbs: '211.80' },
		{ entry_date: '2026-07-07', lbs: '209.80' }, { entry_date: '2026-07-08', lbs: '209.80' },
	];
	const tb_entries = [
		{ entry_date: '2026-07-01', category_id: 1, blocks_filled: 7, blocks_mask: 2 ** 7 - 1 },
		{ entry_date: '2026-07-02', category_id: 1, blocks_filled: 9, blocks_mask: 2 ** 9 - 1 },
		{ entry_date: '2026-07-01', category_id: 3, blocks_filled: 1, blocks_mask: 1 },
	];
	const db = {
		settings: {
			theme_tokens: {
				stroke: '#17263F', text: '#17263F', trend: '#17263F',
				paper: '#6CC7E6', cellBg: '#6CC7E6', mondayBg: '#57B8DA',
				navBg: '#6CC7E6', navActive: '#FFF3B0',
				labelBg: '#6CC7E6', tbDotSize: 13.8,
				circleOutline: '#17263F', circleFill: '#17263F', circleOpen: '#FFFFFF',
				circleStroke: 2, shadow: 24, shadowX: 0, page: '#FFFFFF',
			},
			last_view: { tracker: 'habits', month: '2026-07', songId: null },
			habit_max: 10,
		},
		habits, categories, habit_entries, weights, tb_entries,
		songs: [],
		song_trackers: [],
		playthrough_events: [],
		instruments: [
			{ id: 1, name: 'Rhythm Guitar', sort: 0 }, { id: 2, name: 'Lead Guitar', sort: 1 },
			{ id: 3, name: 'Bass', sort: 2 }, { id: 4, name: 'Drums', sort: 3 },
		],
		exercises: [
			'Walk', 'Run', 'Bike', 'Stretch', 'PT: Reverse Fly', 'PT: Pull Down',
			'PT: External Rotation w/ Press', 'PT: Rotator Cuff',
		].map((name, i) => ({ id: i + 1, name, sort: i, active: 1 })),
		workout_rows: [],
	};
	if (mode === 'demo') {
		db.songs = [{ id: 1, title: 'Seek and Destroy (Metallica)', sort: 0, created_at: '2026-07-02' }];
		db.song_trackers = [
			{ id: 1, song_id: 1, instrument_id: 1, descriptor: 'Rhythm Guitar Run Through', sort: 0 },
			{ id: 2, song_id: 1, instrument_id: 3, descriptor: 'Bass Run Through', sort: 1 },
		];
		let ev = 0;
		db.playthrough_events = [];
		for (const [tracker, day, n] of [[1, 2, 3], [1, 5, 4], [1, 7, 5], [2, 6, 2]]) {
			for (let i = 0; i < n; i++) {
				db.playthrough_events.push({ id: ++ev, tracker_id: tracker, created_at: `2026-07-0${day}T18:0${i}:00.000Z` });
			}
		}
	}
	return db;
}

function mockApi(config) {
	const DEV_KEY = 'hablab_mock_v1';
	// dev mode persists to localStorage so local work survives reloads;
	// demo mode is memory-only and resets on every load.
	let db;
	if (config.mode === 'dev') {
		try { db = JSON.parse(localStorage.getItem(DEV_KEY)) || null; } catch (e) { db = null; }
	}
	if (!db) db = sampleData(config.mode);
	const save = () => {
		if (config.mode === 'dev') localStorage.setItem(DEV_KEY, JSON.stringify(db));
	};
	// Deep-clone every response, like a real server would: the app must never
	// hold references into the mock db (in-place mutations would freeze
	// useMemo deps — the "select shows the wrong song" class of bug).
	const delay = (out) => new Promise((r) => setTimeout(() => r(out == null ? out : JSON.parse(JSON.stringify(out))), 30));

	function monthPayload(month) {
		const like = (month || '2026-07') + '-';
		const inMonth = (e) => e.entry_date.startsWith(like);
		const before = db.weights.filter((w) => w.entry_date < like + '01').sort((a, b) => a.entry_date < b.entry_date ? 1 : -1);
		const ym = month || '2026-07';
		const mStart = ym + '-01';
		const mEnd = ym + '-31';
		return {
			month: ym,
			habits: db.habits.filter((h) => h.active
				&& (!h.starts_on || h.starts_on <= mEnd)
				&& (!h.ends_on || h.ends_on >= mStart)),
			habit_entries: db.habit_entries.filter(inMonth),
			categories: db.categories.filter((c) => c.active),
			tb_entries: db.tb_entries.filter(inMonth),
			weights: db.weights.filter(inMonth).sort((a, b) => a.entry_date > b.entry_date ? 1 : -1),
			prev_weight: before[0] || null,
			workouts: (db.workout_rows || []).filter(inMonth),
		};
	}

	return {
		mode: config.mode,
		hasToken: () => true,
		login: () => delay(true),
		logout() {},
		bootstrap(month) {
			const m = month || db.settings.last_view.month;
			return delay({
				settings: db.settings,
				month: monthPayload(m),
				songs: db.songs,
				instruments: db.instruments,
				exercises: (db.exercises || []).filter((x) => x.active),
				song_trackers: db.song_trackers.map((t) => ({
					...t,
					count: db.playthrough_events.filter((e) => e.tracker_id === t.id).length,
				})),
			});
		},
		getMonth: (month) => delay(monthPayload(month)),
		putSettings(patch) {
			Object.assign(db.settings, patch);
			save();
			return delay(db.settings);
		},
		listDevices: () => delay({ devices: [{ id: 1, label: 'This device (mock)', created_at: '', last_seen: '', revoked: 0 }] }),
		revokeDevice: () => delay({ ok: true }),
		createHabit(habit) {
			const id = 1 + Math.max(0, ...db.habits.map((h) => h.id));
			const sort = habit.sort != null ? habit.sort
				: 1 + Math.max(-1, ...db.habits.filter((h) => h.active && !h.ends_on).map((h) => h.sort));
			const t = new Date();
			const today = `${t.getFullYear()}-${String(t.getMonth() + 1).padStart(2, '0')}-${String(t.getDate()).padStart(2, '0')}`;
			const row = { id, full_name: habit.full_name || '', badge: habit.badge || '', icon: habit.icon || null, target_count: Math.max(1, Math.min(9, Number(habit.target_count) || 1)), sort, active: 1, starts_on: today, ends_on: null };
			db.habits.push(row);
			save();
			return delay(row);
		},
		updateHabit(id, patch) {
			const row = db.habits.find((h) => h.id === id);
			if (row) { Object.assign(row, patch); save(); }
			return delay(row);
		},
		// REMOVE is a hard delete now (§2): the column + all its entries go, so
		// nothing can resurface on reload.
		deleteHabit(id) {
			db.habits = db.habits.filter((h) => h.id !== id);
			db.habit_entries = db.habit_entries.filter((e) => e.habit_id !== id);
			save();
			return delay({ ok: true });
		},
		// Fold `absorbedId`'s per-date counts into `survivorId`, then drop the
		// absorbed column — mirrors the server merge (survivor target stays as set).
		mergeHabits(survivorId, absorbedId) {
			const byDate = {};
			for (const e of db.habit_entries) {
				if (e.habit_id === survivorId || e.habit_id === absorbedId) {
					byDate[e.entry_date] = (byDate[e.entry_date] || 0) + (Number(e.done) || 0);
				}
			}
			db.habit_entries = db.habit_entries.filter((e) => e.habit_id !== survivorId && e.habit_id !== absorbedId);
			for (const [entry_date, done] of Object.entries(byDate)) db.habit_entries.push({ entry_date, habit_id: survivorId, done });
			db.habits = db.habits.filter((h) => h.id !== absorbedId);
			save();
			return delay({ ok: true, merged_dates: Object.keys(byDate).length });
		},
		// `done` is the day's completion COUNT (0..target_count); clamp like the server.
		putHabitEntry(date, habitId, done) {
			const target = Math.max(1, Number((db.habits.find((h) => h.id === habitId) || {}).target_count) || 1);
			const n = Math.max(0, Math.min(target, Math.floor(Number(done) || 0)));
			const hit = db.habit_entries.find((e) => e.entry_date === date && e.habit_id === habitId);
			if (hit) hit.done = n;
			else db.habit_entries.push({ entry_date: date, habit_id: habitId, done: n });
			save();
			return delay({ ok: true, done: n });
		},
		putWeight(date, lbs) {
			db.weights = db.weights.filter((w) => w.entry_date !== date);
			if (lbs != null && lbs !== '') db.weights.push({ entry_date: date, lbs: String(lbs) });
			db.weights.sort((a, b) => (a.entry_date > b.entry_date ? 1 : -1));
			save();
			return delay({ ok: true });
		},
		createCategory(cat) {
			const id = 1 + Math.max(0, ...db.categories.map((c) => c.id));
			const sort = cat.sort != null ? cat.sort
				: 1 + Math.max(-1, ...db.categories.filter((c) => c.active).map((c) => c.sort));
			const row = { id, label: cat.label || '', badge: cat.badge || '', icon: cat.icon || null, capacity: cat.capacity || 6, sort, active: 1 };
			db.categories.push(row);
			save();
			return delay(row);
		},
		updateCategory(id, patch) {
			const row = db.categories.find((c) => c.id === id);
			if (row) { Object.assign(row, patch); save(); }
			return delay(row);
		},
		deleteCategory(id) {
			const row = db.categories.find((c) => c.id === id);
			if (row) { row.active = 0; save(); }
			return delay({ ok: true });
		},
		putTimeblockEntry(date, categoryId, mask) {
			// mask = which dots are filled (bit i = dot i+1); clamp to capacity
			// and derive blocks_filled as the set-bit count, like the server.
			const cap = db.categories.find((c) => c.id === categoryId)?.capacity ?? 48;
			const val = Math.max(0, Math.min(2 ** cap - 1, Math.floor(mask) || 0));
			let count = 0;
			for (let m = val; m > 0; m = Math.floor(m / 2)) count += m % 2;
			const hit = db.tb_entries.find((e) => e.entry_date === date && e.category_id === categoryId);
			if (hit) { hit.blocks_mask = val; hit.blocks_filled = count; }
			else db.tb_entries.push({ entry_date: date, category_id: categoryId, blocks_mask: val, blocks_filled: count });
			save();
			return delay({ ok: true, blocks_mask: val, blocks_filled: count });
		},
		createSong(title) {
			const id = 1 + Math.max(0, ...db.songs.map((s) => s.id));
			const today = new Date();
			const created = `${today.getFullYear()}-${String(today.getMonth() + 1).padStart(2, '0')}-${String(today.getDate()).padStart(2, '0')}`;
			const row = { id, title, sort: db.songs.length, created_at: created };
			db.songs.push(row);
			save();
			return delay(row);
		},
		updateSong(id, patch) {
			const row = db.songs.find((s) => s.id === id);
			if (row) { Object.assign(row, patch); save(); }
			return delay(row);
		},
		deleteSong(id) {
			const gone = db.song_trackers.filter((t) => t.song_id === id).map((t) => t.id);
			db.playthrough_events = db.playthrough_events.filter((e) => !gone.includes(e.tracker_id));
			db.song_trackers = db.song_trackers.filter((t) => t.song_id !== id);
			db.songs = db.songs.filter((s) => s.id !== id);
			save();
			return delay({ ok: true });
		},
		createTracker(songId, tracker) {
			const id = 1 + Math.max(0, ...db.song_trackers.map((t) => t.id));
			const row = { id, song_id: songId, instrument_id: tracker.instrument_id || null, descriptor: tracker.descriptor || '', sort: db.song_trackers.filter((t) => t.song_id === songId).length };
			db.song_trackers.push(row);
			save();
			return delay({ ...row, count: 0 });
		},
		updateTracker(id, patch) {
			const row = db.song_trackers.find((t) => t.id === id);
			if (row) { Object.assign(row, patch); save(); }
			return delay(row);
		},
		deleteTracker(id) {
			db.playthrough_events = db.playthrough_events.filter((e) => e.tracker_id !== id);
			db.song_trackers = db.song_trackers.filter((t) => t.id !== id);
			save();
			return delay({ ok: true });
		},
		addPlaythrough(trackerId) {
			const id = 1 + Math.max(0, ...db.playthrough_events.map((e) => e.id));
			db.playthrough_events.push({ id, tracker_id: trackerId, created_at: new Date().toISOString() });
			save();
			return delay({ ok: true, count: db.playthrough_events.filter((e) => e.tracker_id === trackerId).length });
		},
		removePlaythrough(trackerId) {
			const mine = db.playthrough_events.filter((e) => e.tracker_id === trackerId);
			if (mine.length) {
				const latest = mine[mine.length - 1];
				db.playthrough_events = db.playthrough_events.filter((e) => e !== latest);
			}
			save();
			return delay({ ok: true, count: db.playthrough_events.filter((e) => e.tracker_id === trackerId).length });
		},
		createInstrument(name) {
			const hit = db.instruments.find((i) => i.name.toLowerCase() === name.toLowerCase());
			if (hit) return delay(hit);
			const id = 1 + Math.max(0, ...db.instruments.map((i) => i.id));
			const row = { id, name, sort: db.instruments.length };
			db.instruments.push(row);
			save();
			return delay(row);
		},
		createExercise(name) {
			db.exercises = db.exercises || [];
			const hit = db.exercises.find((x) => x.name.toLowerCase() === name.toLowerCase());
			if (hit) { hit.active = 1; save(); return delay(hit); }
			const id = 1 + Math.max(0, ...db.exercises.map((x) => x.id));
			const row = { id, name, sort: db.exercises.length, active: 1 };
			db.exercises.push(row);
			save();
			return delay(row);
		},
		updateExercise(id, patch) {
			const row = (db.exercises || []).find((x) => x.id === id);
			if (row) { Object.assign(row, patch); save(); }
			return delay(row);
		},
		putWorkoutRow(row) {
			db.workout_rows = db.workout_rows || [];
			let saved;
			if (row.id) {
				saved = db.workout_rows.find((r) => r.id === row.id);
				if (saved) Object.assign(saved, { entry_date: row.date, sort: row.sort || 0, exercise_id: row.exercise_id || null, data: row.data || {} });
			} else {
				saved = { id: 1 + Math.max(0, ...db.workout_rows.map((r) => r.id)), entry_date: row.date, sort: row.sort || 0, exercise_id: row.exercise_id || null, data: row.data || {} };
				db.workout_rows.push(saved);
			}
			save();
			return delay({ ...saved });
		},
		deleteWorkoutRow(id) {
			db.workout_rows = (db.workout_rows || []).filter((r) => r.id !== id);
			save();
			return delay({ ok: true });
		},
		// Export/import speak the SERVER table names (weight_entries, timeblock_*)
		// so files are portable between dev/demo and the live backend.
		getExport() {
			const c = JSON.parse(JSON.stringify(db));
			return delay({
				format: 'hablab-backup', version: 1, exported_at: new Date().toISOString(),
				settings: c.settings,
				habits: c.habits,
				habit_entries: c.habit_entries,
				weight_entries: c.weights,
				timeblock_categories: c.categories,
				timeblock_entries: c.tb_entries,
				instruments: c.instruments,
				songs: c.songs,
				song_trackers: c.song_trackers,
				playthrough_events: c.playthrough_events,
				exercises: c.exercises || [],
				workout_rows: c.workout_rows || [],
			});
		},
		postImport(data) {
			if (!data || data.format !== 'hablab-backup') return Promise.reject(new Error('bad import'));
			const next = sampleData(config.mode);
			if (data.settings) next.settings = data.settings;
			if (data.habits) next.habits = data.habits;
			if (data.habit_entries) next.habit_entries = data.habit_entries;
			if (data.weight_entries) next.weights = data.weight_entries;
			if (data.timeblock_categories) next.categories = data.timeblock_categories;
			if (data.timeblock_entries) next.tb_entries = data.timeblock_entries;
			if (data.instruments) next.instruments = data.instruments;
			if (data.songs) next.songs = data.songs;
			if (data.song_trackers) next.song_trackers = data.song_trackers;
			if (data.playthrough_events) next.playthrough_events = data.playthrough_events;
			if (data.exercises) next.exercises = data.exercises;
			if (data.workout_rows) next.workout_rows = data.workout_rows;
			db = next;
			save();
			return delay({ ok: true });
		},
		listBackups() {
			return delay({ dir: config.mode + ' mode — backups run on the live server only', backups: [] });
		},
		getAnalytics() {
			const today = new Date();
			const todayYMD = `${today.getFullYear()}-${String(today.getMonth() + 1).padStart(2, '0')}-${String(today.getDate()).padStart(2, '0')}`;
			const nextDay = (d) => {
				const dt = new Date(d + 'T12:00:00');
				dt.setDate(dt.getDate() + 1);
				return `${dt.getFullYear()}-${String(dt.getMonth() + 1).padStart(2, '0')}-${String(dt.getDate()).padStart(2, '0')}`;
			};
			const streaks = {};
			const byHabit = {};
			// Day success = the count reached the habit's target (multi-count).
			const targetOf = (id) => Math.max(1, Number((db.habits.find((h) => h.id === Number(id)) || {}).target_count) || 1);
			for (const e of db.habit_entries) {
				if (Number(e.done) >= targetOf(e.habit_id)) (byHabit[e.habit_id] = byHabit[e.habit_id] || []).push(e.entry_date);
			}
			for (const [id, dates] of Object.entries(byHabit)) {
				dates.sort();
				let longest = 0, run = 0, prev = null;
				for (const d of dates) {
					run = prev && nextDay(prev) === d ? run + 1 : 1;
					prev = d;
					if (run > longest) longest = run;
				}
				const last = dates[dates.length - 1];
				const current = (last === todayYMD || nextDay(last) === todayYMD) ? run : 0;
				streaks[id] = { current, longest };
			}
			// Daily completion across history (mirrors the PHP endpoint).
			const doneByDate = {};
			for (const e of db.habit_entries) {
				if (Number(e.done) >= targetOf(e.habit_id)) (doneByDate[e.entry_date] = doneByDate[e.entry_date] || new Set()).add(Number(e.habit_id));
			}
			const daily = [];
			const dates = Object.keys(doneByDate).sort();
			if (dates.length) {
				let d = dates[0];
				let guard = 1100;
				while (d <= todayYMD && guard-- > 0) {
					let active = 0, done = 0;
					for (const h of db.habits) {
						if (!h.active) continue;
						if ((!h.starts_on || h.starts_on <= d) && (!h.ends_on || h.ends_on >= d)) {
							active++;
							if (doneByDate[d] && doneByDate[d].has(Number(h.id))) done++;
						}
					}
					if (active > 0) daily.push({ date: d, done, active });
					d = nextDay(d);
				}
			}
			return delay({
				weights: [...db.weights].sort((a, b) => (a.entry_date > b.entry_date ? 1 : -1)),
				playthroughs: db.playthrough_events.map((e) => ({ tracker_id: e.tracker_id, created_at: e.created_at })),
				streaks,
				daily_completion: daily,
				tb_all: db.tb_entries.filter((e) => Number(e.blocks_filled) > 0)
					.map((e) => ({ entry_date: e.entry_date, category_id: e.category_id, blocks_filled: e.blocks_filled }))
					.sort((a, b) => (a.entry_date > b.entry_date ? 1 : -1)),
				today: todayYMD,
			});
		},
	};
}
