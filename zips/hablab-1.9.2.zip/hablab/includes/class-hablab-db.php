<?php
defined( 'ABSPATH' ) || exit;

class Hablab_DB {

	public static function table( $name ) {
		global $wpdb;
		return $wpdb->prefix . 'hablab_' . $name;
	}

	public static function create_tables() {
		global $wpdb;
		require_once ABSPATH . 'wp-admin/includes/upgrade.php';
		$charset = $wpdb->get_charset_collate();
		$p       = $wpdb->prefix . 'hablab_';

		$sql = "
CREATE TABLE {$p}settings (
  setting_key varchar(64) NOT NULL,
  setting_value longtext,
  updated_at datetime DEFAULT NULL,
  PRIMARY KEY  (setting_key)
) $charset;
CREATE TABLE {$p}habits (
  id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  full_name varchar(190) NOT NULL,
  badge varchar(12) NOT NULL DEFAULT '',
  icon varchar(64) DEFAULT NULL,
  target_count int(11) NOT NULL DEFAULT 1,
  sort int(11) NOT NULL DEFAULT 0,
  active tinyint(1) NOT NULL DEFAULT 1,
  starts_on date DEFAULT NULL,
  ends_on date DEFAULT NULL,
  updated_at datetime DEFAULT NULL,
  PRIMARY KEY  (id)
) $charset;
CREATE TABLE {$p}habit_entries (
  id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  entry_date date NOT NULL,
  habit_id bigint(20) unsigned NOT NULL,
  done int(11) NOT NULL DEFAULT 0,
  updated_at datetime DEFAULT NULL,
  PRIMARY KEY  (id),
  UNIQUE KEY date_habit (entry_date,habit_id),
  KEY habit_id (habit_id)
) $charset;
CREATE TABLE {$p}weight_entries (
  id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  entry_date date NOT NULL,
  lbs decimal(6,2) DEFAULT NULL,
  updated_at datetime DEFAULT NULL,
  PRIMARY KEY  (id),
  UNIQUE KEY entry_date (entry_date)
) $charset;
CREATE TABLE {$p}timeblock_categories (
  id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  label varchar(190) NOT NULL DEFAULT '',
  badge varchar(12) NOT NULL DEFAULT '',
  icon varchar(64) DEFAULT NULL,
  capacity int(11) NOT NULL DEFAULT 6,
  sort int(11) NOT NULL DEFAULT 0,
  active tinyint(1) NOT NULL DEFAULT 1,
  updated_at datetime DEFAULT NULL,
  PRIMARY KEY  (id)
) $charset;
CREATE TABLE {$p}timeblock_entries (
  id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  entry_date date NOT NULL,
  category_id bigint(20) unsigned NOT NULL,
  blocks_filled int(11) NOT NULL DEFAULT 0,
  blocks_mask bigint(20) unsigned NOT NULL DEFAULT 0,
  updated_at datetime DEFAULT NULL,
  PRIMARY KEY  (id),
  UNIQUE KEY date_category (entry_date,category_id),
  KEY category_id (category_id)
) $charset;
CREATE TABLE {$p}instruments (
  id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  name varchar(190) NOT NULL,
  sort int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY  (id),
  UNIQUE KEY name (name)
) $charset;
CREATE TABLE {$p}songs (
  id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  title varchar(190) NOT NULL,
  sort int(11) NOT NULL DEFAULT 0,
  created_at date DEFAULT NULL,
  updated_at datetime DEFAULT NULL,
  PRIMARY KEY  (id)
) $charset;
CREATE TABLE {$p}exercises (
  id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  name varchar(190) NOT NULL,
  sort int(11) NOT NULL DEFAULT 0,
  active tinyint(1) NOT NULL DEFAULT 1,
  PRIMARY KEY  (id),
  UNIQUE KEY name (name)
) $charset;
CREATE TABLE {$p}workout_rows (
  id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  entry_date date NOT NULL,
  sort int(11) NOT NULL DEFAULT 0,
  exercise_id bigint(20) unsigned DEFAULT NULL,
  data longtext,
  updated_at datetime DEFAULT NULL,
  PRIMARY KEY  (id),
  KEY entry_date (entry_date)
) $charset;
CREATE TABLE {$p}song_trackers (
  id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  song_id bigint(20) unsigned NOT NULL,
  instrument_id bigint(20) unsigned DEFAULT NULL,
  descriptor varchar(190) NOT NULL DEFAULT '',
  sort int(11) NOT NULL DEFAULT 0,
  updated_at datetime DEFAULT NULL,
  PRIMARY KEY  (id),
  KEY song_id (song_id)
) $charset;
CREATE TABLE {$p}playthrough_events (
  id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  tracker_id bigint(20) unsigned NOT NULL,
  created_at datetime NOT NULL,
  PRIMARY KEY  (id),
  KEY tracker_id (tracker_id),
  KEY created_at (created_at)
) $charset;
CREATE TABLE {$p}devices (
  id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  token_hash char(64) NOT NULL,
  label varchar(190) NOT NULL DEFAULT '',
  created_at datetime NOT NULL,
  last_seen datetime DEFAULT NULL,
  revoked tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY  (id),
  UNIQUE KEY token_hash (token_hash)
) $charset;
";
		dbDelta( $sql );
		self::backfill_timeblock_masks();
		self::backfill_song_dates();
	}

	/**
	 * Dots used to fill cumulatively, so old rows carry only a count; give
	 * them the equivalent "first n dots" bitmask. Also repairs rows restored
	 * from a pre-mask backup (import calls this too).
	 */
	public static function backfill_timeblock_masks() {
		global $wpdb;
		$table = self::table( 'timeblock_entries' );
		$wpdb->query( "UPDATE $table SET blocks_mask = (1 << blocks_filled) - 1 WHERE blocks_mask = 0 AND blocks_filled > 0" );
	}

	/**
	 * Songs created before the created_at column have no "added" date; the
	 * best available proxy is their first logged play-through, falling back
	 * to updated_at. Idempotent — only touches NULL rows.
	 */
	public static function backfill_song_dates() {
		global $wpdb;
		$songs    = self::table( 'songs' );
		$trackers = self::table( 'song_trackers' );
		$events   = self::table( 'playthrough_events' );
		$wpdb->query(
			"UPDATE $songs s SET s.created_at = COALESCE(
				(SELECT DATE(MIN(e.created_at)) FROM $events e
				 JOIN $trackers t ON e.tracker_id = t.id WHERE t.song_id = s.id),
				DATE(s.updated_at)
			) WHERE s.created_at IS NULL"
		);
	}

	/** True when a settings row exists, even if its stored JSON decodes to null. */
	public static function setting_exists( $key ) {
		global $wpdb;
		$table = self::table( 'settings' );
		return (bool) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM $table WHERE setting_key = %s", $key ) );
	}

	/** Default settings + seed rows, inserted only when missing. */
	public static function seed_defaults() {
		if ( ! self::setting_exists( 'theme_tokens' ) ) {
			self::put_setting( 'theme_tokens', array(
				'stroke'        => '#17263F', // box outlines / grid strokes
				'text'          => '#17263F', // text, icons, tallies
				'trend'         => '#17263F', // ↑ ↓ │ marks
				'paper'         => '#6CC7E6', // tracker background
				'cellBg'        => '#6CC7E6', // selectable-circle box background
				'mondayBg'      => '#57B8DA', // M/date cell background
				'navBg'         => '#6CC7E6', // tab bar strip
				'navActive'     => '#FFF3B0', // active tab button
				'labelBg'       => '#6CC7E6', // habit/category label header boxes
				'tbDotSize'     => 13.8,      // time-block circle size (px)
				'circleOutline' => '#17263F',
				'circleFill'    => '#17263F',
				'circleOpen'    => '#FFFFFF', // open-circle interior
				'circleStroke'  => 2,          // px, grows inward
				'shadow'        => 24,         // sheet drop shadow, desktop/tablet
				'shadowX'       => 0,          // shadow horizontal offset (− left / + right)
				'page'          => '#FFFFFF',
			) );
		}
		if ( ! self::setting_exists( 'last_view' ) ) {
			self::put_setting( 'last_view', array(
				'tracker' => 'habits',
				'month'   => gmdate( 'Y-m' ),
				'songId'  => null,
			) );
		}
		if ( ! self::setting_exists( 'habit_max' ) ) {
			self::put_setting( 'habit_max', 10 );
		}

		global $wpdb;
		$instruments = self::table( 'instruments' );
		if ( 0 === (int) $wpdb->get_var( "SELECT COUNT(*) FROM $instruments" ) ) {
			$seed = array( 'Rhythm Guitar', 'Lead Guitar', 'Bass', 'Drums' );
			foreach ( $seed as $i => $name ) {
				$wpdb->insert( $instruments, array( 'name' => $name, 'sort' => $i ) );
			}
		}

		$exercises = self::table( 'exercises' );
		if ( 0 === (int) $wpdb->get_var( "SELECT COUNT(*) FROM $exercises" ) ) {
			$seed = array( 'Walk', 'Run', 'Bike', 'Stretch', 'PT: Reverse Fly', 'PT: Pull Down', 'PT: External Rotation w/ Press', 'PT: Rotator Cuff' );
			foreach ( $seed as $i => $name ) {
				$wpdb->insert( $exercises, array( 'name' => $name, 'sort' => $i ) );
			}
		}
	}

	public static function get_setting( $key ) {
		global $wpdb;
		$table = self::table( 'settings' );
		$row   = $wpdb->get_var( $wpdb->prepare( "SELECT setting_value FROM $table WHERE setting_key = %s", $key ) );
		return null === $row ? null : json_decode( (string) $row, true );
	}

	public static function put_setting( $key, $value ) {
		global $wpdb;
		$wpdb->replace( self::table( 'settings' ), array(
			'setting_key'   => $key,
			'setting_value' => wp_json_encode( $value ),
			'updated_at'    => current_time( 'mysql', true ),
		) );
	}

	public static function all_settings() {
		global $wpdb;
		$table = self::table( 'settings' );
		$rows  = $wpdb->get_results( "SELECT setting_key, setting_value FROM $table", ARRAY_A );
		$out   = array();
		foreach ( (array) $rows as $r ) {
			$out[ $r['setting_key'] ] = json_decode( (string) $r['setting_value'], true );
		}
		return $out;
	}
}
