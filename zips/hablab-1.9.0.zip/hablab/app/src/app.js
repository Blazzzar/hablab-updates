import { html } from './h.js';
import { useState, useEffect, useCallback, useRef } from 'preact/hooks';
import { createApi, AuthError } from './api.js';
import { applyTheme } from './theme.js';
import { HabitsView } from './views/habits.js';
import { BlocksView } from './views/blocks.js';
import { MusicView } from './views/music.js';
import { ExerciseView } from './views/exercise.js';
import { StatsView } from './views/stats.js';
import { Workbench } from './workbench.js';
import { SettingsSheet } from './settings.js';
import { monthName, todayYMD } from './lib/dates.js';

const TABS = [
	{ id: 'habits', label: 'Habits' },
	{ id: 'blocks', label: 'Time Blocks' },
	{ id: 'music', label: 'Practice' },
	{ id: 'exercise', label: 'Exercise' },
	{ id: 'stats', label: 'Stats' },
];

export function App({ config }) {
	const [phase, setPhase] = useState('loading'); // loading | login | ready | error
	const [boot, setBoot] = useState(null);
	const [view, setView] = useState('habits');
	const [settingsOpen, setSettingsOpen] = useState(false);
	const [saveToast, setSaveToast] = useState(false);
	// Archive lock (§3): months before the current one are read-only. An unlock
	// applies to the viewed month only and is forgotten on navigation (per-browser).
	const [unlockedMonth, setUnlockedMonth] = useState(null);

	const apiRef = useRef(null);
	if (!apiRef.current) {
		apiRef.current = createApi({ ...config, onAuthError: () => setPhase('login') });
	}
	const api = apiRef.current;

	// Failed data writes surface here instead of vanishing silently.
	useEffect(() => {
		let t;
		const show = () => {
			setSaveToast(true);
			clearTimeout(t);
			t = setTimeout(() => setSaveToast(false), 4000);
		};
		window.addEventListener('hablab:save-failed', show);
		return () => { window.removeEventListener('hablab:save-failed', show); clearTimeout(t); };
	}, []);

	// Always-fresh boot for debounced writers (avoids stale-closure clobbers).
	const bootRef = useRef(null);
	bootRef.current = boot;

	const load = useCallback(async () => {
		setPhase('loading');
		try {
			const data = await api.bootstrap();
			applyTheme(data.settings && data.settings.theme_tokens);
			setBoot(data);
			const last = data.settings && data.settings.last_view;
			if (last && last.tracker) setView(last.tracker);
			setPhase('ready');
		} catch (e) {
			if (e instanceof AuthError) setPhase('login');
			else setPhase('error');
		}
	}, [api]);

	useEffect(() => { load(); }, [load]);

	// Persist which tracker I'm looking at (server-side last-state, debounced).
	// last_view is rebuilt when the timer FIRES, not when it's scheduled — a
	// month/song change inside the debounce window must not be clobbered.
	const persistView = useCallback((tracker) => {
		setView(tracker);
		clearTimeout(persistView._t);
		persistView._t = setTimeout(() => {
			const b = bootRef.current;
			if (!b) return;
			const last = { ...b.settings.last_view, tracker };
			b.settings.last_view = last;
			api.putSettings({ last_view: last }).catch(() => {});
		}, 400);
	}, [api]);

	// Archive (§8): browse any month; data is date-keyed so it's just a query.
	async function changeMonth(ym) {
		if (!/^\d{4}-\d{2}$/.test(ym)) return;
		try {
			const m = await api.getMonth(ym);
			setUnlockedMonth(null); // navigating away re-locks any unlocked archive
			setBoot((b) => {
				const last = { ...b.settings.last_view, month: ym };
				api.putSettings({ last_view: last }).catch(() => {});
				return { ...b, month: m, settings: { ...b.settings, last_view: last } };
			});
		} catch (e) { /* keep current month on failure */ }
	}

	function stepMonth(delta) {
		const [y, m] = boot.month.month.split('-').map(Number);
		const d = new Date(y, m - 1 + delta, 1);
		changeMonth(`${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`);
	}

	if (phase === 'login') return html`<${Login} api=${api} onSuccess=${load} />`;
	if (phase === 'loading') return html`<div class="loading">LOADING…</div>`;
	if (phase === 'error') return html`
		<div class="loading">Couldn’t reach the tracker API. <button onClick=${load}>Retry</button></div>`;

	const currentMonth = todayYMD().slice(0, 7);
	const viewMonth = boot.month.month;
	const isArchived = viewMonth < currentMonth;
	const locked = isArchived && unlockedMonth !== viewMonth;

	return html`
		${config.mode === 'demo' && html`<div class="demo-ribbon">DEMO</div>`}
		${saveToast && html`<div class="save-toast">Couldn’t save — check your connection and retry.</div>`}
		<div class="sheet-wrap">
			<div class=${'sheet' + (locked ? ' locked' : '')}>
				<${SheetHead} month=${boot.month.month} showNav=${view !== 'music'}
					locked=${locked} isArchived=${isArchived}
					onStep=${stepMonth} onPick=${changeMonth}
					onSettings=${() => setSettingsOpen(true)}
					onUnlock=${() => setUnlockedMonth(viewMonth)}
					onRelock=${() => setUnlockedMonth(null)} />
				${view === 'habits'
					? html`<${HabitsView} boot=${boot} setBoot=${setBoot} api=${api} config=${config} locked=${locked} />`
					: view === 'blocks'
					? html`<${BlocksView} boot=${boot} setBoot=${setBoot} api=${api} config=${config} locked=${locked} />`
					: view === 'music'
					? html`<${MusicView} boot=${boot} setBoot=${setBoot} api=${api} />`
					: view === 'exercise'
					? html`<${ExerciseView} boot=${boot} setBoot=${setBoot} api=${api} locked=${locked} />`
					: html`<${StatsView} boot=${boot} api=${api} />`}
			</div>
		</div>
		${settingsOpen && html`<${SettingsSheet} api=${api} config=${config} onClose=${() => setSettingsOpen(false)} />`}
		<nav class="tabbar">
			${TABS.map((t) => html`
				<button key=${t.id} class=${view === t.id ? 'active' : ''}
					onClick=${() => persistView(t.id)}>${t.label}</button>
			`)}
			<${Workbench} boot=${boot} setBoot=${setBoot} api=${api} view=${view} />
		</nav>`;
}

function SheetHead({ month, showNav, locked, isArchived, onStep, onPick, onSettings, onUnlock, onRelock }) {
	const y = month.split('-')[0];
	const [menuOpen, setMenuOpen] = useState(false);
	return html`
		<div class="sheet-head">
			<span class="year-badge">${y}</span>
			${showNav && html`
				<span class="month-nav">
					<button class="mn-btn" title="Previous month" onClick=${() => onStep(-1)}>‹</button>
					<label class="mn-label" title="Jump to month">
						${monthName(month)}
						<input type="month" value=${month} onChange=${(e) => e.target.value && onPick(e.target.value)} />
					</label>
					<button class="mn-btn" title="Next month" onClick=${() => onStep(1)}>›</button>
				</span>`}
			${showNav && locked && html`<span class="locked-tag" title="Archived month — read-only">LOCKED</span>`}
			<span class="head-spacer"></span>
			<div class="gear-wrap">
				<button class="gear-btn" title="Menu" aria-haspopup="true" aria-expanded=${menuOpen} onClick=${() => setMenuOpen((o) => !o)}>
					<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
					<path d="M12.22 2h-.44a2 2 0 0 0-2 2v.18a2 2 0 0 1-1 1.73l-.43.25a2 2 0 0 1-2 0l-.15-.08a2 2 0 0 0-2.73.73l-.22.38a2 2 0 0 0 .73 2.73l.15.1a2 2 0 0 1 1 1.72v.51a2 2 0 0 1-1 1.74l-.15.09a2 2 0 0 0-.73 2.73l.22.38a2 2 0 0 0 2.73.73l.15-.08a2 2 0 0 1 2 0l.43.25a2 2 0 0 1 1 1.73V20a2 2 0 0 0 2 2h.44a2 2 0 0 0 2-2v-.18a2 2 0 0 1 1-1.73l.43-.25a2 2 0 0 1 2 0l.15.08a2 2 0 0 0 2.73-.73l.22-.39a2 2 0 0 0-.73-2.73l-.15-.08a2 2 0 0 1-1-1.74v-.5a2 2 0 0 1 1-1.74l.15-.09a2 2 0 0 0 .73-2.73l-.22-.38a2 2 0 0 0-2.73-.73l-.15.08a2 2 0 0 1-2 0l-.43-.25a2 2 0 0 1-1-1.73V4a2 2 0 0 0-2-2z"/><circle cx="12" cy="12" r="3"/>
				</svg>
				</button>
				${menuOpen && html`
					<div class="gear-menu-backdrop" onClick=${() => setMenuOpen(false)}></div>
					<div class="gear-menu">
						<button type="button" onClick=${() => { setMenuOpen(false); onSettings(); }}>Settings…</button>
						${showNav && isArchived && (locked
							? html`<button type="button" onClick=${() => { setMenuOpen(false); onUnlock(); }}>Unlock this month</button>`
							: html`<button type="button" onClick=${() => { setMenuOpen(false); onRelock(); }}>Lock this month</button>`)}
					</div>`}
			</div>
		</div>`;
}

function Login({ api, onSuccess }) {
	const [pass, setPass] = useState('');
	const [err, setErr] = useState('');
	const [busy, setBusy] = useState(false);

	async function submit(e) {
		e.preventDefault();
		setBusy(true);
		setErr('');
		try {
			await api.login(pass);
			onSuccess();
		} catch (e2) {
			setErr(e2 instanceof AuthError ? 'Wrong passphrase.' : 'Login failed — try again.');
			setBusy(false);
		}
	}

	return html`
		<div class="login-wrap">
			<form class="login-card" onSubmit=${submit}>
				<h1>HAB•LAB</h1>
				<input type="password" placeholder="Passphrase" autofocus
					value=${pass} onInput=${(e) => setPass(e.target.value)} />
				<button disabled=${busy}>${busy ? 'Checking…' : 'Unlock'}</button>
				${err && html`<div class="login-error">${err}</div>`}
			</form>
		</div>`;
}
