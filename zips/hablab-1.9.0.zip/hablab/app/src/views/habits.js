import { html } from '../h.js';
import { useState, useMemo } from 'preact/hooks';
import { monthDays, monthName } from '../lib/dates.js';
import { autoBadge, renumberDuplicates, splitSeqBadge } from '../lib/badges.js';
import { Icon, useIcons, searchIcons } from '../lib/icons.js';
import { notifyFailure } from '../lib/notify.js';
import { burstFrom, colorSweep, confettiRain } from '../lib/burst.js';
import { strokeFor } from '../theme.js';

/** A habit only exists between the day it was added and the day it was
 *  removed — outside that range it isn't scored and can't be toggled. */
export function habitActiveOn(h, date) {
	return (!h.starts_on || date >= h.starts_on) && (!h.ends_on || date <= h.ends_on);
}

/* Open circles keep a fixed OUTER radius; thicker strokes eat inward (§3.3). */
const R_OUTER = 9;

/* Clock-fill wedge for a partial multi-count day: a pie slice sweeping from 12
   o'clock clockwise across count/target of the face (viewBox 24, R=8, center
   12,12), filled in the ink colour and sitting inside the open ring. */
function arcPath(frac) {
	const a = frac * 2 * Math.PI - Math.PI / 2;
	const x = 12 + 8 * Math.cos(a), y = 12 + 8 * Math.sin(a);
	return `M 12 12 L 12 4 A 8 8 0 ${frac > 0.5 ? 1 : 0} 1 ${x} ${y} Z`;
}

/** A habit's daily target — how many completions make the day a success. */
export function habitTarget(h) {
	return Math.max(1, Number(h && h.target_count) || 1);
}

/* One habit cell. `count` = the day's completion count, `target` = the daily
   goal. 0/N → open ring; N/N → solid ink dot; partial → open ring plus a
   clock-fill wedge. A target-1 habit stays byte-for-byte the old on/off dot. */
export function Dot({ count = 0, target = 1, strokeW, onTap, date }) {
	const sw = Math.min(Math.max(Number(strokeW) || 2, 0.5), R_OUTER);
	const c = Math.max(0, Number(count) || 0);
	const t = Math.max(1, Number(target) || 1);
	const done = c >= t;
	const partial = c > 0 && c < t;
	return html`
		<button class="dot" data-date=${date} onClick=${(e) => onTap(e)}
			aria-pressed=${done} aria-label=${t > 1 ? `${Math.min(c, t)} of ${t}` : undefined}>
			<svg viewBox="0 0 24 24">
				${done
					? html`<circle cx="12" cy="12" r=${R_OUTER} fill="var(--circle-fill)" />`
					: html`<g>
							<circle cx="12" cy="12" r=${R_OUTER - sw / 2} fill="var(--circle-open)"
								stroke="var(--circle-outline)" stroke-width=${sw} />
							${partial ? html`<path d=${arcPath(c / t)} fill="var(--circle-fill)" />` : ''}
						</g>`}
			</svg>
		</button>`;
}

export function BadgeLabel({ habit, iconSeq }) {
	// Duplicate icon habits get the same superscript numbering as duplicate
	// text badges (B¹ B² → ♪¹ ♪²); iconSeq is derived at render, never stored.
	if (habit.icon) return html`<span class="badge-text">
		<${Icon} name=${habit.icon} size=${16} />${iconSeq ? html`<sup>${iconSeq}</sup>` : ''}
	</span>`;
	const seq = splitSeqBadge(habit.badge);
	if (seq) return html`<span class="badge-text">${seq.letter}<sup>${seq.seq}</sup></span>`;
	return html`<span class="badge-text">${habit.badge || autoBadge(habit.full_name)}</span>`;
}

/** Column-order sequence numbers for habits sharing the same icon (≥2). */
export function iconSeqMap(habits) {
	const byIcon = new Map();
	for (const h of habits) {
		if (!h.icon) continue;
		if (!byIcon.has(h.icon)) byIcon.set(h.icon, []);
		byIcon.get(h.icon).push(h.id);
	}
	const seq = new Map();
	for (const ids of byIcon.values()) {
		if (ids.length < 2) continue;
		ids.forEach((id, i) => seq.set(id, i + 1));
	}
	return seq;
}

export function HabitsView({ boot, setBoot, api, config, locked }) {
	useIcons(config.base);
	const data = boot.month;
	const days = useMemo(() => monthDays(data.month), [data.month]);
	const strokeW = strokeFor(boot.settings.theme_tokens, 'habits');
	const habitMax = Number(boot.settings.habit_max) || 12;
	const habits = data.habits;
	const spares = Math.max(0, habitMax - habits.length);

	const [editor, setEditor] = useState(null); // {habit} | {new: true}
	const [weightEdit, setWeightEdit] = useState(null); // date being edited

	// Per-day completion COUNT (0..target); the dot renders a clock-fill from it.
	const countMap = useMemo(() => {
		const m = new Map();
		for (const e of data.habit_entries) m.set(e.entry_date + '|' + e.habit_id, Number(e.done) || 0);
		return m;
	}, [data.habit_entries]);

	const weightMap = useMemo(() => {
		const m = new Map();
		for (const w of data.weights) if (w.lbs != null) m.set(w.entry_date, Number(w.lbs));
		return m;
	}, [data.weights]);

	// Trend (§4.3): compare to the most recent prior entry; ties/first/blank → │.
	const trend = useMemo(() => {
		const t = new Map();
		let prev = data.prev_weight ? Number(data.prev_weight.lbs) : null;
		for (const d of days) {
			const w = weightMap.get(d.date);
			if (w == null) { t.set(d.date, '│'); continue; }
			t.set(d.date, prev == null || w === prev ? '│' : w > prev ? '↑' : '↓');
			prev = w;
		}
		return t;
	}, [days, weightMap, data.prev_weight]);

	function patchMonth(patch) {
		setBoot((b) => ({ ...b, month: { ...b.month, ...patch } }));
	}

	// Tap = one completion event; tapping at full wraps back to 0 (cycle).
	// Confetti fires only on the tap that REACHES the target (the old completing
	// tap); the wrap-to-0 tap fires nothing.
	function tapHabit(date, h, sparkEl) {
		if (locked) return;
		const target = habitTarget(h);
		const key = date + '|' + h.id;
		const cur = countMap.get(key) || 0;
		const next = cur >= target ? 0 : cur + 1;
		const reached = next === target; // completing tap (target ≥ 1 ⇒ next > 0)
		if (reached && sparkEl) burstFrom(sparkEl);
		const rest = data.habit_entries.filter((e) => !(e.entry_date === date && e.habit_id === h.id));
		const entries = [...rest, { entry_date: date, habit_id: h.id, done: next }];
		// Perfect day! A rainbow wave sweeps left→right across the day's circles,
		// then confetti rains — only when this completing tap also brings every
		// active habit to its target.
		if (reached) {
			const active = habits.filter((hh) => habitActiveOn(hh, date));
			const allDone = active.length > 0 && active.every((hh) => {
				const e = entries.find((x) => x.habit_id === hh.id && x.entry_date === date);
				return e && Number(e.done) >= habitTarget(hh);
			});
			if (allDone) {
				setTimeout(() => {
					// after the re-render, so the tapped dot is already filled
					const dots = [...document.querySelectorAll(`.dot[data-date="${date}"]`)];
					const wave = colorSweep(dots);
					setTimeout(confettiRain, Math.max(250, wave - 150));
				}, 120);
			}
		}
		patchMonth({ habit_entries: entries });
		api.putHabitEntry(date, h.id, next).catch(notifyFailure);
	}

	function saveWeight(date, raw, badInput) {
		setWeightEdit(null);
		// Browser-invalid text ("12..5", locale commas) reads as '' — that is
		// NOT an intentional clear; never delete an entry over it.
		if (badInput) return;
		const val = raw === '' ? null : Number(raw);
		if (val != null && (!isFinite(val) || val <= 0)) return;
		const rest = data.weights.filter((w) => w.entry_date !== date);
		patchMonth({ weights: val == null ? rest : [...rest, { entry_date: date, lbs: String(val) }].sort((a, b) => (a.entry_date > b.entry_date ? 1 : -1)) });
		api.putWeight(date, val).catch(notifyFailure);
	}

	async function saveHabit(form) {
		try {
			const isNew = !form.id;
			const saved = isNew
				? await api.createHabit({ full_name: form.full_name, badge: form.badge, icon: form.icon, target_count: form.target_count })
				: await api.updateHabit(form.id, { full_name: form.full_name, badge: form.badge, icon: form.icon, target_count: form.target_count });
			let list = isNew ? [...habits, saved] : habits.map((h) => (h.id === form.id ? { ...h, ...saved } : h));
			// Duplicate renumbering (§4.2) — persist any badge changes it produces.
			const updates = [];
			for (const c of renumberDuplicates(list)) {
				list = list.map((h) => (h.id === c.id ? { ...h, badge: c.badge } : h));
				updates.push(api.updateHabit(c.id, { badge: c.badge }));
			}
			Promise.all(updates).catch(notifyFailure);
			patchMonth({ habits: list });
			setEditor(null);
		} catch (e) {
			notifyFailure(); // editor stays open; nothing was applied locally
		}
	}

	async function removeHabit(id) {
		try {
			await api.deleteHabit(id);
			// Hard delete (§2): drop the column AND its entries locally so nothing
			// can resurface on reload — no ghost badge/icon, no stale circles.
			patchMonth({
				habits: habits.filter((h) => h.id !== id),
				habit_entries: data.habit_entries.filter((e) => e.habit_id !== id),
			});
			setEditor(null);
		} catch (e) {
			notifyFailure();
		}
	}

	// Column merge (history migration): fold another habit into this one on the
	// server (safety backup + per-date SUM), then re-pull the month so the
	// folded history and dropped column land exactly as stored.
	async function mergeHabit(survivorId, absorbedId) {
		try {
			await api.mergeHabits(survivorId, absorbedId);
			const m = await api.getMonth(data.month);
			setBoot((b) => ({ ...b, month: m }));
			setEditor(null);
		} catch (e) {
			notifyFailure();
		}
	}

	const cols = habits.length + spares;

	return html`
		<div class="grid-scroll">
		<div class="habit-grid" style=${`--habit-cols:${cols}`}>
			<div class="hg-head hg-month">${monthName(data.month)}</div>
			<div class="hg-head hg-lbs-head">LBS</div>
			<div class="hg-head hg-trend-head"></div>
			${(() => { const seqs = iconSeqMap(habits); return habits.map((h) => html`
				<button key=${h.id} class="hg-head hg-badge" title=${h.full_name}
					onClick=${() => { if (!locked) setEditor({ habit: h }); }}>
					<${BadgeLabel} habit=${h} iconSeq=${seqs.get(h.id)} />
				</button>`); })()}
			${Array.from({ length: spares }, (_, i) => html`
				<button key=${'sp' + i} class="hg-head hg-badge hg-spare" title="Add habit"
					onClick=${() => { if (!locked) setEditor({ new: true }); }}></button>`)}

			${days.map((d) => html`
				<div class=${'hg-wd' + (d.isMonday ? ' hg-mon' : '')}>${d.wd}</div>
				<div class=${'hg-dn' + (d.isMonday ? ' hg-mon' : '')}>${d.day}</div>
				<button class="hg-lbs" onClick=${() => { if (!locked) setWeightEdit(d.date); }}>
					${weightEdit === d.date
						? html`<input class="lbs-input" type="number" inputmode="decimal" step="0.1"
								value=${weightMap.get(d.date) ?? ''} autofocus
								onBlur=${(e) => saveWeight(d.date, e.target.value, e.target.validity && e.target.validity.badInput)}
								onKeyDown=${(e) => { if (e.key === 'Enter') e.target.blur(); }} />`
						: html`<span class="lbs-num">${weightMap.get(d.date)?.toFixed(1) ?? ''}</span>`}
				</button>
				<div class="hg-trend" data-t=${trend.get(d.date)}>${trend.get(d.date)}</div>
				${habits.map((h) => habitActiveOn(h, d.date) ? html`
					<div key=${h.id} class="hg-cell">
						<${Dot} count=${countMap.get(d.date + '|' + h.id) || 0} target=${habitTarget(h)} strokeW=${strokeW} date=${d.date}
							onTap=${(e) => tapHabit(d.date, h, e && e.currentTarget)} />
					</div>` : html`
					<div key=${h.id} class="hg-cell hg-cell-off" title="not tracked on this date"></div>`)}
				${Array.from({ length: spares }, (_, i) => html`<div key=${'sp' + i} class="hg-cell hg-cell-spare"></div>`)}
			`)}
		</div>
		</div>
		${editor && html`<${HabitEditor}
			habit=${editor.habit}
			badgeLen=${2}
			withTarget=${true}
			onSave=${saveHabit}
			onRemove=${editor.habit ? () => removeHabit(editor.habit.id) : null}
			onMerge=${editor.habit ? (absorbedId) => mergeHabit(editor.habit.id, absorbedId) : null}
			mergeCandidates=${editor.habit ? habits.filter((h) => h.id !== editor.habit.id) : []}
			onClose=${() => setEditor(null)} />`}
	`;
}

/* Bottom-sheet editor for one header box: name → auto badge, or an icon.
   Shared by habits (2-letter badges) and time-block categories (4-letter + capacity). */
export function HabitEditor({ habit, badgeLen = 2, onSave, onRemove, onClose, title = 'habit', withCapacity = false, withTarget = false, onMerge = null, mergeCandidates = [], iconAndText = false, hideBadge = false }) {
	const [name, setName] = useState(habit?.full_name || '');
	const [badge, setBadge] = useState(habit?.badge || '');
	const [badgeTouched, setBadgeTouched] = useState(!!habit?.badge);
	const [icon, setIcon] = useState(habit?.icon || null);
	const [capacity, setCapacity] = useState(habit?.capacity ?? 6);
	const [target, setTarget] = useState(habit?.target_count ?? 1);
	const [pickerOpen, setPickerOpen] = useState(false);
	const [query, setQuery] = useState('');

	function onNameInput(e) {
		const v = e.target.value;
		setName(v);
		if (!badgeTouched) setBadge(autoBadge(v, badgeLen));
	}

	function submit(e) {
		e.preventDefault();
		if (!name.trim() && !icon && !withCapacity) return;
		const out = {
			id: habit?.id,
			full_name: name.trim(),
			// iconAndText mode (categories): icon and badge coexist; an empty
			// badge WITH an icon means "icon only" — don't auto-fill it.
			badge: hideBadge ? '' : (icon && !iconAndText ? '' : (badge.trim() || (icon ? '' : autoBadge(name, badgeLen)))),
			icon,
		};
		if (withCapacity) out.capacity = Math.max(1, Math.min(48, Number(capacity) || 6));
		if (withTarget) out.target_count = Math.max(1, Math.min(9, Number(target) || 1));
		onSave(out);
	}

	return html`
		<div class="sheet-overlay" onClick=${onClose}>
			<form class="editor" onClick=${(e) => e.stopPropagation()} onSubmit=${submit}>
				<div class="editor-title">${habit ? 'Edit ' + title : 'New ' + title}</div>
				<label class="editor-field">
					<span>Name</span>
					<input value=${name} onInput=${onNameInput} placeholder="Exercise" autofocus=${!habit} />
				</label>
				<div class="editor-row">
					${!hideBadge && html`<label class="editor-field editor-badge">
						<span>Badge</span>
						<input value=${badge} maxlength=${badgeLen === 2 ? 3 : 7} disabled=${!!icon && !iconAndText}
							placeholder=${icon && !iconAndText ? '—' : 'EX'}
							onInput=${(e) => { setBadgeTouched(true); setBadge(e.target.value.toUpperCase()); }} />
					</label>`}
					<label class="editor-field">
						<span>Icon</span>
						<button type="button" class="icon-btn" onClick=${() => setPickerOpen(!pickerOpen)}>
							${icon ? html`<${Icon} name=${icon} size=${18} /> ${icon}` : 'choose…'}
						</button>
					</label>
					${icon && html`<button type="button" class="icon-clear" onClick=${() => setIcon(null)}>✕ no icon</button>`}
				</div>
				${withCapacity && html`
					<label class="editor-field editor-badge">
						<span>Blocks / day (× 30 min)</span>
						<input type="number" inputmode="numeric" min="1" max="48" value=${capacity}
							onInput=${(e) => setCapacity(e.target.value)} />
					</label>`}
				${withTarget && html`
					<label class="editor-field editor-badge">
						<span>Times per day</span>
						<input type="number" inputmode="numeric" min="1" max="9" value=${target}
							onInput=${(e) => setTarget(e.target.value)} />
					</label>`}
				${pickerOpen && html`
					<div class="icon-picker">
						<input placeholder="Search icons…" value=${query} onInput=${(e) => setQuery(e.target.value)} />
						<div class="icon-grid">
							${searchIcons(query).map((n) => html`
								<button type="button" key=${n} class=${n === icon ? 'sel' : ''} title=${n}
									onClick=${() => { setIcon(n); setPickerOpen(false); }}>
									<${Icon} name=${n} size=${20} />
								</button>`)}
						</div>
					</div>`}
				${onMerge && mergeCandidates.length > 0 && html`<${MergeControl} candidates=${mergeCandidates} onMerge=${onMerge} />`}
				<div class="editor-actions">
					${onRemove && html`<button type="button" class="danger" onClick=${onRemove}>Remove</button>`}
					<span class="spacer"></span>
					<button type="button" onClick=${onClose}>Cancel</button>
					<button type="submit" class="primary">Save</button>
				</div>
			</form>
		</div>`;
}

/* “Merge another column into this habit” (history migration). Picks a second
   habit to absorb; the server sums each date's counts into the survivor and
   deletes the absorbed column (safety backup written first). */
function MergeControl({ candidates, onMerge }) {
	const [open, setOpen] = useState(false);
	const [pick, setPick] = useState('');
	const label = (h) => h.full_name || h.badge || (h.icon || ('#' + h.id));
	if (!open) {
		return html`<button type="button" class="merge-open" onClick=${() => setOpen(true)}>Merge another column into this habit…</button>`;
	}
	return html`
		<div class="merge-box">
			<div class="merge-note">Fold another column's history into this one (per-day counts add up), then delete that column. A safety backup is written first.</div>
			<select class="merge-select" value=${pick} onChange=${(e) => setPick(e.target.value)}>
				<option value="">Choose a column to absorb…</option>
				${candidates.map((h) => html`<option key=${h.id} value=${h.id}>${label(h)}</option>`)}
			</select>
			<div class="merge-actions">
				<button type="button" onClick=${() => { setOpen(false); setPick(''); }}>Cancel</button>
				<button type="button" class="danger" disabled=${!pick}
					onClick=${() => { if (pick && confirm('Merge this column in and delete the absorbed one? A safety backup is written first.')) onMerge(Number(pick)); }}>Merge & delete</button>
			</div>
		</div>`;
}
