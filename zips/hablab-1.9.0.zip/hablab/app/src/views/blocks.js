import { html } from '../h.js';
import { useState, useMemo } from 'preact/hooks';
import { monthDays, monthName } from '../lib/dates.js';
import { autoBadge } from '../lib/badges.js';
import { Icon, useIcons } from '../lib/icons.js';
import { HabitEditor } from './habits.js';
import { notifyFailure } from '../lib/notify.js';
import { burstFrom } from '../lib/burst.js';
import { strokeFor } from '../theme.js';

/* One dot = 30 minutes (§5.1). Dots per day render in two rows like the
   paper: 16 → 8+8, 10 → 5+5, 6 → 3+3. Each dot toggles independently —
   tapping the 5th never backfills 1–4. Which dots are filled lives in
   blocks_mask (bit i = dot i+1); blocks_filled stays the set-bit count so
   daily/monthly totals and stats keep reading it unchanged. Arithmetic, not
   bitwise — JS bitwise ops are 32-bit and capacity can reach 48. */

const bitOn = (mask, i) => Math.floor(mask / 2 ** i) % 2 === 1;
const countBits = (mask) => { let c = 0; for (let m = mask; m > 0; m = Math.floor(m / 2)) c += m % 2; return c; };
/* Rows written before the mask existed (or restored from an old backup) only
   carry the cumulative count — read those as "first n dots". */
const maskOf = (e) => e.blocks_mask != null ? Number(e.blocks_mask) : 2 ** Number(e.blocks_filled || 0) - 1;

const R_OUTER = 9; // same inward-stroke geometry as habit dots, smaller render size

function BlockDot({ filled, strokeW }) {
	const sw = Math.min(Math.max(Number(strokeW) || 2, 0.5), R_OUTER);
	return html`
		<svg viewBox="0 0 24 24" class="tb-dot">
			${filled
				? html`<circle cx="12" cy="12" r=${R_OUTER} fill="var(--circle-fill)" />`
				: html`<circle cx="12" cy="12" r=${R_OUTER - sw / 2} fill="var(--circle-open)"
						stroke="var(--circle-outline)" stroke-width=${sw} />`}
		</svg>`;
}

function fmtHours(blocks) {
	if (!blocks) return '';
	const h = blocks * 0.5;
	return Number.isInteger(h) ? String(h) : h.toFixed(1);
}

export function BlocksView({ boot, setBoot, api, config, locked }) {
	useIcons(config.base);
	const data = boot.month;
	const days = useMemo(() => monthDays(data.month), [data.month]);
	const strokeW = strokeFor(boot.settings.theme_tokens, 'blocks');
	const cats = data.categories;
	const [editor, setEditor] = useState(null); // {cat} | {new:true}

	const maskMap = useMemo(() => {
		const m = new Map();
		for (const e of data.tb_entries) m.set(e.entry_date + '|' + e.category_id, maskOf(e));
		return m;
	}, [data.tb_entries]);

	const monthTotals = useMemo(() => {
		const t = new Map();
		for (const e of data.tb_entries) {
			t.set(e.category_id, (t.get(e.category_id) || 0) + Number(e.blocks_filled));
		}
		return t;
	}, [data.tb_entries]);

	function patchMonth(patch) {
		setBoot((b) => ({ ...b, month: { ...b.month, ...patch } }));
	}

	// Tap block i (1-based): toggle just that dot — nothing backfills.
	function tap(date, cat, i, sparkEl) {
		if (locked) return; // archived month is read-only
		const key = date + '|' + cat.id;
		const cur = maskMap.get(key) || 0;
		const bit = 2 ** (i - 1);
		const filling = !bitOn(cur, i - 1);
		const next = filling ? cur + bit : cur - bit;
		if (filling && sparkEl) burstFrom(sparkEl); // filling, not clearing
		const rest = data.tb_entries.filter((e) => !(e.entry_date === date && e.category_id === cat.id));
		patchMonth({ tb_entries: [...rest, { entry_date: date, category_id: cat.id, blocks_mask: next, blocks_filled: countBits(next) }] });
		api.putTimeblockEntry(date, cat.id, next).catch(notifyFailure);
	}

	async function saveCategory(form) {
		try {
			const isNew = !form.id;
			// Header shows badge (≤7 chars) and/or icon — three states: badge
			// only, icon only, icon + badge (icon first). Name stays the full
			// reference label (tooltip + stats fallback).
			const payload = { label: form.full_name, badge: form.badge, icon: form.icon, capacity: form.capacity };
			const saved = isNew ? await api.createCategory(payload) : await api.updateCategory(form.id, payload);
			const list = isNew ? [...cats, saved] : cats.map((c) => (c.id === form.id ? { ...c, ...saved } : c));
			patchMonth({ categories: list });
			setEditor(null);
		} catch (e) {
			notifyFailure();
		}
	}

	async function removeCategory(id) {
		try {
			await api.deleteCategory(id);
			patchMonth({
				categories: cats.filter((c) => c.id !== id),
				tb_entries: data.tb_entries.filter((e) => e.category_id !== id),
			});
			setEditor(null);
		} catch (e) {
			notifyFailure();
		}
	}

	// grid: wd | day | per category: [dots][total]
	const dotCols = (cap) => Math.ceil(cap / 2);
	const template = ['26px', '30px']
		.concat(cats.flatMap((c) => [`minmax(${dotCols(c.capacity) * 16 + 8}px, ${dotCols(c.capacity)}fr)`, '38px']))
		.join(' ');

	// Three states: badge only / icon only / icon + badge (icon first).
	// With neither set, fall back to the full label so nothing renders blank.
	function catLabel(c) {
		const text = c.badge || (c.icon ? '' : c.label) || '';
		return html`
			${c.icon ? html`<${Icon} name=${c.icon} size=${16} />` : ''}
			${text ? html`<span class="tb-cat-text">${text}</span>` : ''}`;
	}

	return html`
		<div class="grid-scroll">
		<div class="tb-grid" style=${`grid-template-columns:${template}`}>
			<div class="hg-head hg-month">${monthName(data.month)}</div>
			${cats.map((c) => html`
				<button key=${c.id} class="hg-head tb-cat-head" style="grid-column: span 2"
					title=${c.label || 'Unnamed category'} onClick=${() => { if (!locked) setEditor({ cat: c }); }}>
					${catLabel(c)}
				</button>`)}

			${days.map((d) => html`
				<div class=${'hg-wd' + (d.isMonday ? ' hg-mon' : '')}>${d.wd}</div>
				<div class=${'hg-dn' + (d.isMonday ? ' hg-mon' : '')}>${d.day}</div>
				${cats.map((c) => {
					const mask = maskMap.get(d.date + '|' + c.id) || 0;
					const perRow = dotCols(c.capacity);
					return html`
						<div key=${c.id} class="tb-cell" style=${`--tb-per-row:${perRow}`}>
							${Array.from({ length: c.capacity }, (_, i) => html`
								<button key=${i} class="tb-tap" onClick=${(e) => tap(d.date, c, i + 1, e.currentTarget)}>
									<${BlockDot} filled=${bitOn(mask, i)} strokeW=${strokeW} />
								</button>`)}
						</div>
						<div class="tb-total">${fmtHours(countBits(mask))}</div>`;
				})}
			`)}

			<div class="tb-foot hg-wd" style="grid-column: 1 / span 2">Σ h</div>
			${cats.map((c) => html`
				<div key=${c.id} class="tb-foot tb-foot-total" style="grid-column: span 2">
					${fmtHours(monthTotals.get(c.id) || 0) || '0'}
				</div>`)}
		</div>
		</div>
		${editor && html`<${HabitEditor}
			habit=${editor.cat ? { id: editor.cat.id, full_name: editor.cat.label, badge: editor.cat.badge, icon: editor.cat.icon, capacity: editor.cat.capacity } : null}
			badgeLen=${4} title="category" withCapacity=${true} iconAndText=${true}
			onSave=${saveCategory}
			onRemove=${editor.cat ? () => removeCategory(editor.cat.id) : null}
			onClose=${() => setEditor(null)} />`}
	`;
}
