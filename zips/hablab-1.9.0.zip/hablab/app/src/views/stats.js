import { html } from '../h.js';
import { useState, useEffect, useMemo } from 'preact/hooks';
import { monthDays, monthName, todayYMD } from '../lib/dates.js';
import { autoBadge } from '../lib/badges.js';
import { BarList, LineChart, CalHeatmap } from '../lib/charts.js';
import { habitActiveOn, habitTarget } from './habits.js';

const pct = (x) => (isFinite(x) ? Math.round(x * 100) + '%' : '—');

// Streak milestones: the highest earned badge rides along with the streak.
const MILESTONES = [[100, '👑'], [30, '🏆'], [7, '⭐']];
const milestone = (streak) => (MILESTONES.find(([n]) => streak >= n) || [0, ''])[1];

const ymd = (dt) => `${dt.getFullYear()}-${String(dt.getMonth() + 1).padStart(2, '0')}-${String(dt.getDate()).padStart(2, '0')}`;
const nextDayStr = (d) => { const dt = new Date(d + 'T12:00:00'); dt.setDate(dt.getDate() + 1); return ymd(dt); };
const weekKey = (d) => { const dt = new Date(d + 'T12:00:00'); dt.setDate(dt.getDate() - ((dt.getDay() + 6) % 7)); return ymd(dt); };
const prevYMOf = (ym) => { const [y, m] = ym.split('-').map(Number); const d = new Date(y, m - 2, 1); return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`; };
const eventYMD = (createdAt) => {
	const raw = String(createdAt).replace(' ', 'T');
	return ymd(new Date(/[zZ]|[+-]\d\d:?\d\d$/.test(raw) ? raw : raw + 'Z'));
};
const delta = (cur, prv, unit = '', digits = 1) => {
	if (!isFinite(cur) || !isFinite(prv)) return '—';
	const d = cur - prv;
	if (Math.abs(d) < 0.05) return '＝';
	return (d > 0 ? '▲ +' : '▼ −') + Math.abs(d).toFixed(digits).replace(/\.0$/, '') + unit;
};

export function StatsView({ boot, api }) {
	const data = boot.month;
	const [an, setAn] = useState(null); // {weights, playthroughs, streaks, daily_completion, tb_all, today}
	useEffect(() => { api.getAnalytics().then(setAn).catch(() => setAn({ error: true })); }, [api]);

	// Previous month's payload for the month-over-month comparison card.
	const prevYM = prevYMOf(data.month);
	const [prev, setPrev] = useState(null);
	useEffect(() => { setPrev(null); api.getMonth(prevYM).then(setPrev).catch(() => {}); }, [api, prevYM]);

	const days = useMemo(() => monthDays(data.month), [data.month]);
	const today = todayYMD();
	// Only score days that have happened (current month) — past months score fully.
	const elapsed = days.filter((d) => d.date <= today);
	const scoreDays = elapsed.length ? elapsed : days;

	/* ---- habits ---- */
	const habits = data.habits;
	// A day counts for a habit only when the completion count reached its target
	// (multi-count "day success"); a target-1 habit is unchanged.
	const targetById = useMemo(() => new Map(habits.map((h) => [h.id, habitTarget(h)])), [habits]);
	const doneSet = useMemo(() => {
		const s = new Set();
		for (const e of data.habit_entries) if (Number(e.done) >= (targetById.get(e.habit_id) || 1)) s.add(e.entry_date + '|' + e.habit_id);
		return s;
	}, [data.habit_entries, targetById]);

	// A habit is only scored on days it existed (§ mid-month adds): the
	// denominator is its active days, never the whole month.
	const habitStats = habits.map((h) => {
		const activeDays = scoreDays.filter((d) => habitActiveOn(h, d.date));
		const done = activeDays.filter((d) => doneSet.has(d.date + '|' + h.id)).length;
		const st = an && an.streaks ? an.streaks[h.id] : null;
		return { habit: h, done, possible: activeDays.length, rate: activeDays.length ? done / activeDays.length : NaN, streak: st };
	});
	const totalPossible = habitStats.reduce((a, s) => a + s.possible, 0);
	const overallRate = totalPossible
		? habitStats.reduce((a, s) => a + s.done, 0) / totalPossible : 0;

	const dayFrac = useMemo(() => {
		const m = new Map();
		for (const d of days) {
			if (d.date > today) { m.set(d.date, null); continue; }
			const active = habits.filter((h) => habitActiveOn(h, d.date));
			m.set(d.date, active.length
				? active.filter((h) => doneSet.has(d.date + '|' + h.id)).length / active.length
				: null);
		}
		return m;
	}, [days, habits, doneSet, today]);
	const perfectDays = scoreDays.filter((d) => dayFrac.get(d.date) === 1).length;

	/* ---- day-of-week patterns ---- */
	const dowStats = useMemo(() => {
		const acc = Array.from({ length: 7 }, () => ({ done: 0, possible: 0 }));
		for (const d of scoreDays) {
			const dow = new Date(d.date + 'T12:00:00').getDay();
			const active = habits.filter((h) => habitActiveOn(h, d.date));
			acc[dow].possible += active.length;
			acc[dow].done += active.filter((h) => doneSet.has(d.date + '|' + h.id)).length;
		}
		return acc;
	}, [scoreDays, habits, doneSet]);

	/* ---- weight ---- */
	const weightSeries = useMemo(() => {
		if (!an || !an.weights || !an.weights.length) return null;
		const pts = an.weights.map((w, i) => ({ x: i, y: Number(w.lbs), title: `${w.entry_date}: ${Number(w.lbs).toFixed(1)} lbs` }));
		const ma = pts.map((p, i) => {
			const win = pts.slice(Math.max(0, i - 6), i + 1);
			return { x: p.x, y: win.reduce((a, q) => a + q.y, 0) / win.length };
		});
		const lab = [];
		const step = Math.max(1, Math.floor(pts.length / 5));
		for (let i = 0; i < pts.length; i += step) {
			lab.push({ x: i, text: an.weights[i].entry_date.slice(5).replace('-', '/') });
		}
		return { pts, ma, lab, latest: pts[pts.length - 1].y };
	}, [an]);

	/* ---- time blocks ---- */
	const cats = data.categories;
	const tb = useMemo(() => {
		const byCat = new Map();
		let blocks = 0;
		for (const e of data.tb_entries) {
			byCat.set(e.category_id, (byCat.get(e.category_id) || 0) + Number(e.blocks_filled));
			blocks += Number(e.blocks_filled);
		}
		const capacity = cats.reduce((a, c) => a + c.capacity, 0) * scoreDays.length;
		return { byCat, hours: blocks / 2, avg: blocks / 2 / scoreDays.length, fill: capacity ? blocks / capacity : 0 };
	}, [data.tb_entries, cats, scoreDays.length]);

	/* ---- music ---- */
	const music = useMemo(() => {
		if (!an || !an.playthroughs) return null;
		const trackers = boot.song_trackers || [];
		const bySong = new Map(), byInst = new Map(), byWeek = new Map();
		for (const ev of an.playthroughs) {
			const t = trackers.find((x) => x.id === Number(ev.tracker_id));
			if (!t) continue;
			bySong.set(t.song_id, (bySong.get(t.song_id) || 0) + 1);
			byInst.set(t.instrument_id, (byInst.get(t.instrument_id) || 0) + 1);
			// Server timestamps are UTC without a zone marker; parse as UTC so
			// weekly buckets don't shift by the viewer's offset.
			const raw = String(ev.created_at).replace(' ', 'T');
			const d = new Date(/[zZ]|[+-]\d\d:?\d\d$/.test(raw) ? raw : raw + 'Z');
			const monday = new Date(d);
			monday.setDate(d.getDate() - ((d.getDay() + 6) % 7));
			const key = `${monday.getFullYear()}-${String(monday.getMonth() + 1).padStart(2, '0')}-${String(monday.getDate()).padStart(2, '0')}`;
			byWeek.set(key, (byWeek.get(key) || 0) + 1);
		}
		const top = [...bySong.entries()].sort((a, b) => b[1] - a[1])[0];
		return {
			total: an.playthroughs.length,
			bySong, byInst,
			weeks: [...byWeek.entries()].sort((a, b) => (a[0] > b[0] ? 1 : -1)),
			topSong: top ? boot.songs.find((s) => s.id === top[0]) : null,
			topCount: top ? top[1] : 0,
		};
	}, [an, boot.song_trackers, boot.songs]);

	const badge = (h) => h.icon ? (h.full_name || h.icon) : (h.badge || autoBadge(h.full_name));

	/* ---- (4) month-over-month: fair compare, first N elapsed days of each ---- */
	const mom = useMemo(() => {
		if (!prev || !prev.habits) return null;
		const n = scoreDays.length;
		const slice = (payload) => {
			const sliceDays = monthDays(payload.month).slice(0, n);
			if (!sliceDays.length) return null;
			const cutoff = sliceDays[sliceDays.length - 1].date;
			const tmap = new Map((payload.habits || []).map((h) => [h.id, habitTarget(h)]));
			const done = new Set(payload.habit_entries.filter((e) => Number(e.done) >= (tmap.get(e.habit_id) || 1)).map((e) => e.entry_date + '|' + e.habit_id));
			let poss = 0, dn = 0;
			for (const d of sliceDays) {
				for (const h of payload.habits) {
					if (habitActiveOn(h, d.date)) { poss++; if (done.has(d.date + '|' + h.id)) dn++; }
				}
			}
			const blocks = payload.tb_entries.filter((e) => e.entry_date <= cutoff).reduce((a, e) => a + Number(e.blocks_filled), 0);
			const workouts = new Set((payload.workouts || []).filter((r) => r.entry_date <= cutoff).map((r) => r.entry_date)).size;
			const plays = an && an.playthroughs
				? an.playthroughs.filter((ev) => { const d = eventYMD(ev.created_at); return d.startsWith(payload.month) && d <= cutoff; }).length
				: null;
			return { rate: poss ? dn / poss : NaN, hours: blocks / 2, workouts, plays };
		};
		const cur = slice(data);
		const prv = slice(prev);
		if (!cur || !prv) return null;
		return { n, cur, prv };
	}, [prev, data, an, scoreDays.length]);

	/* ---- (3) consistency: completion × consolidation (runs beat scatter) ---- */
	const consistency = useMemo(() => {
		const rows = habitStats.filter((s) => s.possible > 0).map((s) => {
			const activeDays = scoreDays.filter((d) => habitActiveOn(s.habit, d.date));
			let run = 0, maxRun = 0;
			for (const d of activeDays) {
				run = doneSet.has(d.date + '|' + s.habit.id) ? run + 1 : 0;
				if (run > maxRun) maxRun = run;
			}
			const score = s.done ? (s.done / s.possible) * (maxRun / s.done) : 0;
			return { ...s, score, maxRun };
		});
		if (!rows.length) return null;
		const sortedRows = [...rows].sort((a, b) => b.score - a.score);
		return { rows, best: sortedRows[0], worst: sortedRows[sortedRows.length - 1] };
	}, [habitStats, scoreDays, doneSet]);

	/* ---- (8) perfect-day streak across all history ---- */
	const perfect = useMemo(() => {
		const dc = an && an.daily_completion;
		if (!dc || !dc.length) return null;
		const isPerfect = dc.map((x) => Number(x.active) > 0 && Number(x.done) === Number(x.active));
		let longest = 0, run = 0;
		for (const p of isPerfect) { run = p ? run + 1 : 0; if (run > longest) longest = run; }
		// current: run ending today, or yesterday if today isn't perfect yet
		let end = dc.length - 1;
		if (!isPerfect[end] && dc[end].date === today) end--;
		let current = 0;
		for (let i = end; i >= 0 && isPerfect[i]; i--) current++;
		return { current, longest };
	}, [an, today]);

	/* ---- (1) weight ↔ habit-completion correlation ---- */
	const wcorr = useMemo(() => {
		const dc = an && an.daily_completion, ws = an && an.weights;
		if (!dc || !ws || ws.length < 2 || !dc.length) return null;
		const frac = new Map(dc.map((x) => [x.date, Number(x.done) / Number(x.active)]));
		const pairs = [];
		for (let i = 1; i < ws.length; i++) {
			const d1 = ws[i - 1].entry_date, d2 = ws[i].entry_date;
			const gap = Math.round((new Date(d2 + 'T12:00:00') - new Date(d1 + 'T12:00:00')) / 86400000);
			if (gap < 1 || gap > 7) continue;
			let sum = 0, nn = 0, d = d1;
			while (d < d2) { if (frac.has(d)) { sum += frac.get(d); nn++; } d = nextDayStr(d); }
			if (!nn) continue;
			pairs.push({ comp: sum / nn, slope: (Number(ws[i].lbs) - Number(ws[i - 1].lbs)) / gap });
		}
		if (pairs.length < 8) return { insufficient: true, have: pairs.length };
		const n = pairs.length;
		const mx = pairs.reduce((a, p) => a + p.comp, 0) / n;
		const my = pairs.reduce((a, p) => a + p.slope, 0) / n;
		let cov = 0, sx = 0, sy = 0;
		for (const p of pairs) { cov += (p.comp - mx) * (p.slope - my); sx += (p.comp - mx) ** 2; sy += (p.slope - my) ** 2; }
		const r = sx && sy ? cov / Math.sqrt(sx * sy) : 0;
		const hi = pairs.filter((p) => p.comp >= 0.8), lo = pairs.filter((p) => p.comp < 0.8);
		const avg = (arr) => (arr.length ? arr.reduce((a, p) => a + p.slope, 0) / arr.length : NaN);
		return { r, n, hiAvg: avg(hi), loAvg: avg(lo), hiN: hi.length, loN: lo.length };
	}, [an]);

	/* ---- (6) time-block records + weekly trend ---- */
	const tbRecords = useMemo(() => {
		const tba = an && an.tb_all;
		if (!tba || !tba.length) return null;
		const bestDay = new Map(), weekByCat = new Map(), weekTotals = new Map();
		for (const e of tba) {
			const cid = Number(e.category_id), b = Number(e.blocks_filled);
			if (!bestDay.has(cid) || b > bestDay.get(cid).blocks) bestDay.set(cid, { date: e.entry_date, blocks: b });
			const wk = weekKey(e.entry_date);
			const wkc = wk + '|' + cid;
			weekByCat.set(wkc, (weekByCat.get(wkc) || 0) + b);
			weekTotals.set(wk, (weekTotals.get(wk) || 0) + b);
		}
		const bestWeek = new Map();
		for (const [wkc, blocks] of weekByCat) {
			const [wk, cid] = wkc.split('|');
			const c = Number(cid);
			if (!bestWeek.has(c) || blocks > bestWeek.get(c).blocks) bestWeek.set(c, { week: wk, blocks });
		}
		const weeks = [...weekTotals.entries()].sort((a, b) => (a[0] > b[0] ? 1 : -1)).slice(-10);
		return { bestDay, bestWeek, weeks };
	}, [an]);

	return html`
		<div class="stats">
			<div class="stat-tiles">
				<div class="stat-tile"><div class="stat-num">${pct(overallRate)}</div><div class="stat-cap">habits · ${monthName(data.month)}</div></div>
				<div class="stat-tile"><div class="stat-num">${perfectDays}</div><div class="stat-cap">perfect days</div></div>
				<div class="stat-tile" title=${perfect ? `longest ever: ${perfect.longest}` : ''}>
					<div class=${'stat-num' + (perfect && milestone(perfect.current) ? ' milestone-num' : '')}>
						${perfect ? perfect.current : '—'}${perfect && perfect.current > 0 ? '🔥' : ''} ${perfect ? milestone(perfect.current) : ''}
					</div>
					<div class="stat-cap">perfect streak${perfect ? ` · best ${perfect.longest}` : ''}</div>
				</div>
				<div class="stat-tile"><div class="stat-num">${weightSeries ? weightSeries.latest.toFixed(1) : '—'}</div><div class="stat-cap">last weigh-in</div></div>
				<div class="stat-tile"><div class="stat-num">${tb.hours}</div><div class="stat-cap">block hours</div></div>
			</div>

			${mom && html`
				<div class="stat-card">
					<h3>This month vs last <span class="mom-note">(first ${mom.n} days of each)</span></h3>
					${[
						['Habits', pct(mom.cur.rate), pct(mom.prv.rate), delta(mom.cur.rate * 100, mom.prv.rate * 100, '%', 0)],
						['Block hours', mom.cur.hours, mom.prv.hours, delta(mom.cur.hours, mom.prv.hours, ' h')],
						['Play-throughs', mom.cur.plays ?? '—', mom.prv.plays ?? '—', delta(mom.cur.plays, mom.prv.plays, '', 0)],
						['Workouts', mom.cur.workouts, mom.prv.workouts, delta(mom.cur.workouts, mom.prv.workouts, '', 0)],
					].map(([label, cur, prv, d]) => html`
						<div class="mom-row" key=${label}>
							<span class="mom-label">${label}</span>
							<span class="mom-prev">${prv}</span>
							<span class="mom-arrow">→</span>
							<span class="mom-cur">${cur}</span>
							<span class="mom-delta">${d}</span>
						</div>`)}
				</div>`}

			<div class="stat-card">
				<h3>Habit completion & streaks</h3>
				${habitStats.length ? html`<${BarList} rows=${habitStats.map((s) => ({
					label: badge(s.habit),
					value: isFinite(s.rate) ? s.rate : 0,
					display: `${pct(s.rate)}${s.streak ? ` · ${s.streak.current}🔥 / ${s.streak.longest} best ${milestone(s.streak.current)}` : ''}`.trim(),
					cls: s.streak && milestone(s.streak.current) ? 'milestone' : '',
					title: `${s.habit.full_name || badge(s.habit)}: ${s.done}/${s.possible} days` +
						(s.streak ? ` — current streak ${s.streak.current}, longest ${s.streak.longest}` : '') +
						(s.streak && milestone(s.streak.current) ? ` — ${MILESTONES.find(([n]) => s.streak.current >= n)[0]}-day milestone!` : ''),
				}))} max=${1} />` : html`<div class="chart-empty">no habits yet</div>`}
			</div>

			${consistency && html`
				<div class="stat-card">
					<h3>Consistency <span class="mom-note">(completion × streakiness — runs beat scatter)</span></h3>
					<${BarList} rows=${consistency.rows.map((s) => ({
						label: badge(s.habit),
						value: s.score,
						display: pct(s.score),
						title: `${s.habit.full_name || badge(s.habit)}: ${pct(s.rate)} completion, longest run ${s.maxRun} of ${s.done} done days`,
					}))} max=${1} />
					${consistency.rows.length > 1 && html`
						<div class="stat-inline consistency-callout">
							<span>most consistent: <strong>${badge(consistency.best.habit)}</strong></span>
							<span>most fragile: <strong>${badge(consistency.worst.habit)}</strong></span>
						</div>`}
				</div>`}

			<div class="stat-card">
				<h3>Perfect-day heatmap</h3>
				<${CalHeatmap} days=${days} frac=${dayFrac} />
			</div>

			<div class="stat-card">
				<h3>Weight</h3>
				${weightSeries ? html`
					<div class="chart-legend"><span class="lg-solid">daily</span><span class="lg-dashed">7-day avg</span></div>
					<${LineChart}
						series=${[{ points: weightSeries.pts }, { points: weightSeries.ma, dashed: true }]}
						labels=${weightSeries.lab} fmt=${(v) => v.toFixed(1)} />`
					: html`<div class="chart-empty">no weigh-ins yet</div>`}
			</div>

			<div class="stat-card">
				<h3>Weight ↔ habits</h3>
				${!wcorr ? html`<div class="chart-empty">needs weigh-ins + habit history</div>`
				: wcorr.insufficient ? html`<div class="chart-empty">keep logging — ${wcorr.have}/8 paired weigh-in stretches so far</div>`
				: html`
					<div class="stat-inline">
						<span>${
							wcorr.r <= -0.3 ? 'Better habit days tend to precede weight LOSS' :
							wcorr.r >= 0.3 ? 'Better habit days tend to precede weight GAIN' :
							'No clear link yet between habits and weight'
						} <span class="mom-note">(r = ${wcorr.r.toFixed(2)}, ${wcorr.n} stretches)</span></span>
					</div>
					<${BarList} rows=${[
						{ label: '≥80% days', value: Math.abs(wcorr.hiAvg), display: `${wcorr.hiAvg >= 0 ? '+' : '−'}${Math.abs(wcorr.hiAvg).toFixed(2)} lbs/day (${wcorr.hiN})` },
						{ label: '<80% days', value: Math.abs(wcorr.loAvg), display: `${wcorr.loAvg >= 0 ? '+' : '−'}${Math.abs(wcorr.loAvg).toFixed(2)} lbs/day (${wcorr.loN})` },
					].filter((r) => isFinite(r.value))} />`}
			</div>

			<div class="stat-card">
				<h3>Time blocks · ${monthName(data.month)}</h3>
				<div class="stat-inline">
					<span>${tb.hours} h total</span>
					<span>${tb.avg.toFixed(1)} h/day</span>
					<span>${pct(tb.fill)} fill rate</span>
				</div>
				<${BarList} rows=${cats.map((c) => ({
					label: c.badge || c.label || '—',
					value: (tb.byCat.get(c.id) || 0) / 2,
					display: `${(tb.byCat.get(c.id) || 0) / 2} h`,
				}))} />
			</div>

			${tbRecords && html`
				<div class="stat-card">
					<h3>Time-block records</h3>
					${cats.filter((c) => tbRecords.bestDay.has(Number(c.id))).map((c) => html`
						<div class="mom-row" key=${c.id}>
							<span class="mom-label">${c.badge || c.label || '—'}</span>
							<span class="tbr">best day ${tbRecords.bestDay.get(Number(c.id)).blocks / 2} h
								<span class="mom-note">(${tbRecords.bestDay.get(Number(c.id)).date.slice(5).replace('-', '/')})</span></span>
							<span class="tbr">best week ${(tbRecords.bestWeek.get(Number(c.id))?.blocks || 0) / 2} h
								<span class="mom-note">(wk ${(tbRecords.bestWeek.get(Number(c.id))?.week || '').slice(5).replace('-', '/')})</span></span>
						</div>`)}
					${tbRecords.weeks.length > 1 && html`
						<h4>hours per week</h4>
						<${LineChart}
							series=${[{ points: tbRecords.weeks.map(([wk, blocks], i) => ({ x: i, y: blocks / 2, title: `wk ${wk.slice(5).replace('-', '/')}: ${blocks / 2} h` })) }]}
							labels=${tbRecords.weeks.map(([wk], i) => ({ x: i, text: wk.slice(5).replace('-', '/') }))}
							fmt=${(v) => v.toFixed(0)} />`}
				</div>`}

			<div class="stat-card">
				<h3>Music practice</h3>
				${music && music.total ? html`
					${music.topSong && html`<div class="stat-inline"><span>most practiced: <strong>${music.topSong.title}</strong> (${music.topCount})</span></div>`}
					<h4>by song</h4>
					<${BarList} rows=${boot.songs.filter((s) => music.bySong.get(s.id)).map((s) => ({
						label: s.title.length > 18 ? s.title.slice(0, 17) + '…' : s.title,
						value: music.bySong.get(s.id) || 0,
					}))} />
					<h4>by instrument</h4>
					<${BarList} rows=${boot.instruments.filter((i) => music.byInst.get(i.id)).map((i) => ({
						label: i.name,
						value: music.byInst.get(i.id) || 0,
					}))} />
					<h4>per week</h4>
					<${BarList} rows=${music.weeks.map(([wk, n]) => ({
						label: 'wk ' + wk.slice(5).replace('-', '/'),
						value: n,
					}))} />`
					: html`<div class="chart-empty">no play-throughs yet</div>`}
			</div>

			<div class="stat-card">
				<h3>Day-of-week patterns</h3>
				<${BarList} rows=${['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].map((name, i) => ({
					label: name,
					value: dowStats[i].possible ? dowStats[i].done / dowStats[i].possible : 0,
					display: pct(dowStats[i].possible ? dowStats[i].done / dowStats[i].possible : NaN),
				}))} max=${1} />
			</div>
		</div>`;
}
