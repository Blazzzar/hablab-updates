=== HAB•LAB ===
Contributors: chrisjennings
Requires at least: 5.8
Tested up to: 6.8
Requires PHP: 7.4
Stable tag: 1.9.0
License: GPL-2.0-or-later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Personal habit / time-block / music-practice tracker PWA at /hablab.html. Private single-admin plugin — not for wp.org distribution.

== Description ==

HAB•LAB serves a passphrase-gated tracker PWA at
`/hablab.html` (public sandbox at `/hablab-demo.html`), with custom tables,
a REST API, daily JSON backups, staleness reminder emails, and a
self-hosted GitHub update channel (stable/beta tracks, one-click rollback).

== Installation ==

1. Upload the release zip via Plugins → Add New → Upload Plugin
   ("Replace current with uploaded" when a build is already installed);
   Activate. This manual upload is only ever needed once — after that,
   new builds appear as normal WordPress plugin updates (one click).
2. Settings → HAB•LAB: set the passphrase; configure Reminders.
3. The plugin row on the Plugins screen gains "Check for updates",
   "Switch to beta/stable channel", and (when available) "Roll back to X".

== Changelog ==

See CHANGELOG.md in the plugin folder, or the version's entry on the
update channel's View-details screen.
