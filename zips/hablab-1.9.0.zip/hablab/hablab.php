<?php
/**
 * Plugin Name: HAB•LAB
 * Description: Personal habit / time-block / music-practice tracker PWA at /hablab.html (demo at /hablab-demo.html).
 * Version: 1.9.0
 * Author: Chris Jennings
 * License: GPL-2.0-or-later
 * Requires at least: 5.8
 * Requires PHP: 7.4
 * Update URI: https://blazzzar.github.io/hablab-updates/hablab.json
 */

defined( 'ABSPATH' ) || exit;

define( 'HABLAB_VERSION', '1.9.0' );
define( 'HABLAB_PLUGIN_FILE', __FILE__ );
define( 'HABLAB_DIR', plugin_dir_path( __FILE__ ) );
define( 'HABLAB_URL', plugin_dir_url( __FILE__ ) );

require_once HABLAB_DIR . 'includes/class-hablab-db.php';
require_once HABLAB_DIR . 'includes/class-hablab-auth.php';
require_once HABLAB_DIR . 'includes/class-hablab-rest.php';
require_once HABLAB_DIR . 'includes/class-hablab-admin.php';
require_once HABLAB_DIR . 'includes/class-hablab-backups.php';
require_once HABLAB_DIR . 'includes/class-hablab-reminders.php';
// Self-hosted GitHub update channel (STEMMAXXER/WeIdea pipeline — one-click
// updates, stable/beta tracks, check-now, and rollback links).
require_once HABLAB_DIR . 'includes/class-hablab-updater.php';
require_once HABLAB_DIR . 'includes/class-hablab-updater-admin.php';

Hablab_Backups::init();
Hablab_Reminders::init();
Hablab_Updater::instance();
Hablab_Updater_Admin::init();

register_activation_hook( __FILE__, function () {
	hablab_migrate_legacy();
	Hablab_DB::create_tables();
	Hablab_DB::seed_defaults();
	hablab_add_rewrites();
	flush_rewrite_rules();
	Hablab_Backups::schedule();
	Hablab_Reminders::schedule();
} );

register_deactivation_hook( __FILE__, function () {
	flush_rewrite_rules();
	Hablab_Backups::unschedule();
	Hablab_Reminders::unschedule();
} );

function hablab_add_rewrites() {
	add_rewrite_rule( '^hablab\.html$', 'index.php?hablab=app', 'top' );
	add_rewrite_rule( '^hablab-demo\.html$', 'index.php?hablab=demo', 'top' );
	add_rewrite_rule( '^hablab-sw\.js$', 'index.php?hablab=sw', 'top' );
	add_rewrite_rule( '^hablab\.webmanifest$', 'index.php?hablab=manifest', 'top' );
	// Legacy /tracker URLs 301 to the new home (old bookmarks + installed PWAs).
	add_rewrite_rule( '^tracker/?$', 'index.php?hablab=legacy-app', 'top' );
	add_rewrite_rule( '^tracker/demo/?$', 'index.php?hablab=legacy-demo', 'top' );
	add_rewrite_rule( '^tracker/sw\.js$', 'index.php?hablab=legacy-sw', 'top' );
	add_rewrite_rule( '^tracker/manifest\.webmanifest$', 'index.php?hablab=legacy-manifest', 'top' );
}
add_action( 'init', 'hablab_add_rewrites' );

add_filter( 'query_vars', function ( $vars ) {
	$vars[] = 'hablab';
	return $vars;
} );

add_action( 'template_redirect', function () {
	$mode = get_query_var( 'hablab' );
	if ( ! $mode ) {
		return;
	}
	if ( 0 === strpos( $mode, 'legacy-' ) ) {
		$map = array(
			'legacy-app'      => '/hablab.html',
			'legacy-demo'     => '/hablab-demo.html',
			'legacy-sw'       => '/hablab-sw.js',
			'legacy-manifest' => '/hablab.webmanifest',
		);
		wp_safe_redirect( home_url( isset( $map[ $mode ] ) ? $map[ $mode ] : '/hablab.html' ), 301 );
		exit;
	}
	if ( 'sw' === $mode ) {
		$file = HABLAB_DIR . 'app/sw.js';
		if ( ! is_readable( $file ) ) {
			status_header( 404 );
			exit;
		}
		header( 'Content-Type: text/javascript; charset=utf-8' );
		// Served from the site root (/hablab-sw.js), so the default max scope
		// "/" already covers the /hablab.html shell — no Service-Worker-Allowed
		// header needed.
		header( 'Cache-Control: no-cache' );
		// Cache version derives from the plugin version — one source of truth.
		echo str_replace( '__HABLAB_VERSION__', HABLAB_VERSION, file_get_contents( $file ) );
		exit;
	}
	if ( 'manifest' === $mode ) {
		$file = HABLAB_DIR . 'app/manifest.webmanifest';
		if ( ! is_readable( $file ) ) {
			status_header( 404 );
			exit;
		}
		header( 'Content-Type: application/manifest+json; charset=utf-8' );
		readfile( $file );
		exit;
	}
	// app | demo
	include HABLAB_DIR . 'includes/template-app.php';
	exit;
} );

add_action( 'rest_api_init', function () {
	( new Hablab_REST() )->register_routes();
} );

// Our auth token travels in a header, so host/proxy page caches see every
// request as anonymous and will happily cache data responses (observed live:
// x-cache-enabled). Forbid caching on everything in our namespace.
add_filter( 'rest_post_dispatch', function ( $response, $server, $request ) {
	if ( 0 === strpos( $request->get_route(), '/hablab/' ) && $response instanceof WP_REST_Response ) {
		$response->header( 'Cache-Control', 'no-store, no-cache, must-revalidate, max-age=0' );
	}
	return $response;
}, 10, 3 );

/**
 * One-time takeover from the plugin's pre-1.8.0 identity ("seej-tracker").
 * THIS FUNCTION IS THE ONLY PLACE THE OLD NAME MAY APPEAR IN CODE — it is
 * what removes that identity from the live site. Renames the old tables
 * (data + indexes preserved), carries the passphrase hash over, clears the
 * old cron hooks, renames the backups folder so retention history
 * continues, and deactivates the old plugin entry so two copies never run
 * at once. Every step is guarded — safe to run repeatedly.
 */
function hablab_migrate_legacy() {
	global $wpdb;

	// Tables: <prefix>seej_* → <prefix>hablab_*.
	$old_prefix = $wpdb->prefix . 'seej_';
	$like       = $wpdb->esc_like( $old_prefix ) . '%';
	$old_tables = $wpdb->get_col( $wpdb->prepare( 'SHOW TABLES LIKE %s', $like ) );
	foreach ( (array) $old_tables as $old ) {
		$new    = $wpdb->prefix . 'hablab_' . substr( $old, strlen( $old_prefix ) );
		$exists = $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $wpdb->esc_like( $new ) ) );
		if ( ! $exists ) {
			$wpdb->query( "RENAME TABLE `{$old}` TO `{$new}`" );
		}
	}

	// Passphrase hash lives in wp_options (not our tables) — carry it over.
	$old_hash = get_option( 'seej_tracker_passphrase_hash' );
	if ( $old_hash && ! get_option( Hablab_Auth::OPTION_HASH ) ) {
		update_option( Hablab_Auth::OPTION_HASH, $old_hash );
	}
	delete_option( 'seej_tracker_passphrase_hash' );
	delete_option( 'seej_tracker_db_version' );

	// Old cron events (the new hooks are scheduled by our callers).
	wp_clear_scheduled_hook( 'seej_tracker_daily_backup' );
	wp_clear_scheduled_hook( 'seej_tracker_daily_reminders' );

	// Backups folder rename keeps the retention history.
	$uploads = wp_upload_dir();
	$old_dir = trailingslashit( $uploads['basedir'] ) . 'seej-tracker-backups';
	$new_dir = trailingslashit( $uploads['basedir'] ) . 'hablab-backups';
	if ( is_dir( $old_dir ) && ! is_dir( $new_dir ) ) {
		@rename( $old_dir, $new_dir );
	}

	// Retire the old plugin entry (different slug = WP sees two plugins).
	if ( ! function_exists( 'deactivate_plugins' ) && is_readable( ABSPATH . 'wp-admin/includes/plugin.php' ) ) {
		require_once ABSPATH . 'wp-admin/includes/plugin.php';
	}
	if ( function_exists( 'is_plugin_active' ) && is_plugin_active( 'seej-tracker/seej-tracker.php' ) ) {
		deactivate_plugins( 'seej-tracker/seej-tracker.php', true );
	}
}

// Upgrade path: run the legacy takeover, then re-run dbDelta when the
// schema version changes. Also self-heals the reminders cron and flushes
// rewrites so URL/identity changes take effect on file-copy deploys too.
add_action( 'plugins_loaded', function () {
	if ( get_option( 'hablab_db_version' ) !== HABLAB_VERSION ) {
		hablab_migrate_legacy();
		Hablab_DB::create_tables();
		Hablab_DB::seed_defaults();
		Hablab_Reminders::schedule();
		flush_rewrite_rules();
		update_option( 'hablab_db_version', HABLAB_VERSION );
	}
} );
